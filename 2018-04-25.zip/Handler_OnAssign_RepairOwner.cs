﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    /*
     * Message = Assign
     * Primary Entity = mvh_repairmodule
     * Filtering Attributes = 
     * Execution Order = 1
     * Unsecure = 
     * Secure = 
    */

    public class Handler_OnAssign_RepairOwner : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_OnAssign_RepairOwner()
        {
        }

        public Handler_OnAssign_RepairOwner(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_OnAssign_RepairOwner(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth >= 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "assign":
                        primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "ownerid");
                        string owner = primaryentity.Value("ownerid");

                        // Find stage 1 history records where the current owner is admin
                        StringBuilder xml = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");
                        xml.Append("<entity name=\"mvh_stagehistory\">");
                        xml.Append("<attribute name=\"mvh_stagehistoryid\" />");
                        xml.Append("<filter type=\"and\">");
                        xml.Append("<condition attribute=\"owneridname\" operator=\"like\" value=\"%admin%\" />");
                        xml.AppendFormat("<condition attribute=\"mvh_repairid\" operator=\"eq\" uitype=\"mvh_repairmodule\" value=\"{0}\" />", context.PrimaryEntityId.ToString());
                        xml.Append("<condition attribute=\"mvh_stage\" operator=\"eq\" value=\"1\" />");
                        xml.Append("</filter>");
                        xml.Append("</entity>");
                        xml.Append("</fetch>");

                        if (primaryentity.FetchEntityCollection(xml.ToString()))
                        {
                            XRMHelper mvh_stagehistory = new XRMHelper(service, "mvh_stagehistory");

                            foreach (Entity ent in primaryentity.Results.Entities)
                            {
                                mvh_stagehistory.schema.Id = ent.Id;
                                mvh_stagehistory.SetOwner(owner);
                            }
                        }
                        break;
                }
            }
        }
    }
}

