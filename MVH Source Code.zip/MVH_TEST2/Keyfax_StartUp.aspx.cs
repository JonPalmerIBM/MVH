﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ServiceReference1;

public partial class Keyfax_StartUp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //D365EntityHelper xrm = new D365EntityHelper();
        //xrm.WhoAmI();
        //Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", xrm.Value("domainname"))));
        //Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", User.Identity.Name)));
        //return;

        if (Request["id"] != null && Request["entityname"] != null)
        {
            // Build return URL
            string ReturnURL = string.Format("{0}?propertyid={1}&id={2}&entityname={3}", ConfigurationManager.AppSettings["keyfax.returnurl"],
                Convert.ToString(Request["propertyid"]).Replace("{", string.Empty).Replace("}", string.Empty),
                Convert.ToString(Request["id"]).Replace("{", string.Empty).Replace("}", string.Empty), 
                Convert.ToString(Request["entityname"]));

            if (Request["ownerid"] != null)
            {
                ReturnURL += "&ownerid=" + Request["ownerid"].Replace("{", string.Empty).Replace("}", string.Empty);
            }

            // Add placeholders for Keyfax to insert status, company code and session GUID
            ReturnURL += "&status={0}&co={1}&guid={2}";

            // Build startup XML
            StringBuilder startupXML = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");

            startupXML.AppendFormat("<KeyfaxData test=\"{0}\">", ConfigurationManager.AppSettings["keyfax.test"]);
            startupXML.Append("<Startup>");
            startupXML.AppendFormat("<OriginatingSystem>{0}</OriginatingSystem>", ConfigurationManager.AppSettings["keyfax.originatingsystem"]);
            startupXML.AppendFormat("<Mode>{0}</Mode>", ConfigurationManager.AppSettings["keyfax.mode"]);
            startupXML.AppendFormat("<Company>{0}</Company>", ConfigurationManager.AppSettings["keyfax.company"]);
            startupXML.AppendFormat("<UserName>{0}</UserName>", ConfigurationManager.AppSettings["keyfax.username"]);
            startupXML.AppendFormat("<Password>{0}</Password>", ConfigurationManager.AppSettings["keyfax.password"]);
            startupXML.AppendFormat("<ReturnURL><![CDATA[{0}]]></ReturnURL>", ReturnURL);
            startupXML.AppendFormat("<ScriptSet/>");
            startupXML.Append("<CallerDetails>");
            startupXML.Append("<CallerID/>");
            startupXML.Append("<Caller/>");
            startupXML.Append("<Title/>");
            startupXML.Append("<FirstName/>");
            startupXML.Append("<LastName/>");
            startupXML.Append("</CallerDetails>");
            startupXML.Append("<PropertyID/>");
            startupXML.Append("<Property>");
            startupXML.Append("<AddressLine1/>");
            startupXML.Append("<AddressLine2/>");
            startupXML.Append("<AddressLine3/>");
            startupXML.Append("<AddressLine4/>");
            startupXML.Append("<AddressLine5/>");
            startupXML.Append("<City/>");
            startupXML.Append("<County/>");
            startupXML.Append("<Postcode/>");
            startupXML.Append("</Property>");
            startupXML.Append("</Startup>");
            startupXML.Append("</KeyfaxData>");

            // Call Startup web service method and redirect to Launch URL that it returns
            KeyfaxWSSoapClient keyfax = new KeyfaxWSSoapClient();
            WSStartupGuid startup;

            startup = keyfax.Startup(startupXML.ToString());

            if (!string.IsNullOrEmpty(startup.LaunchUrl))
            {
                Response.Redirect(startup.LaunchUrl);
            }
            else
            {
                Content.Controls.Add(new LiteralControl(string.Format("<p>Error: {0}</p>", startup.ErrorText)));
                Ok.Visible = true;
            }
        }
        else
        {
            // Error, querystring should contain correct parameters
            Content.Controls.Add(new LiteralControl(string.Format("<p>Error: Incorrect number of parameters in {0}</p>", Request.Url.OriginalString)));
        }
    }

    protected void Ok_Click(object sender, EventArgs e)
    {
        Response.Write(string.Format("<script>top.location='{0}';parent.location='{0}';</script>",
            string.Format("{0}?etn={1}&pagetype=entityrecord&id={2}",
            ConfigurationManager.AppSettings["keyfax.redirecturl"], Request["entityname"], Request["id"])));
    }
}