﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Swordfish_Documents : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Redirect("http://mvh-edmapp/swordfishtest/asp/explorer/tiffex.asp?target=undefined");

        // Response.Write(Request.Url.PathAndQuery);
    }
}