﻿function mvh_severityrating_OnChange()
{
    RecalculateOverallRating();
}

function mvh_likelihoodrating_OnChange()
{
    RecalculateOverallRating();
}

function RecalculateOverallRating() 
{
    var mvh_severityrating = Xrm.Page.getAttribute('mvh_severityrating').getValue();
    var mvh_likelihoodrating = Xrm.Page.getAttribute('mvh_likelihoodrating').getValue();
    var mvh_overallrating = 0;

    if (mvh_severityrating != null && mvh_likelihoodrating != null)
    {
        mvh_overallrating = (mvh_severityrating * mvh_likelihoodrating);
    }

    Xrm.Page.getAttribute('mvh_overallrating').setValue(mvh_overallrating);
    Xrm.Page.getAttribute('mvh_overallrating').setSubmitMode('always');
}

