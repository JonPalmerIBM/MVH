﻿function KeyFaxRibbonClick() {
    // Launch keyfax start up page with entity type name and ID
    var keyfaxUrl = 'http://mvhcrmdev:8091/Keyfax_StartUp.aspx';

    keyfaxUrl += '?propertyid=' + Xrm.Page.data.entity.getId();
    keyfaxUrl += '&id=' + Xrm.Page.data.entity.getId();
    keyfaxUrl += '&entityname=' + Xrm.Page.data.entity.getEntityName();

    window.location.href = keyfaxUrl;
}

function GetKeyfaxURL()
{
    return 'http://mvhcrmdev:8091/Keyfax_StartUp.aspx';
}

function Form_RibbonClick()
{
    // Launch keyfax start up page with entity type name and ID
    var keyfaxUrl = GetKeyfaxURL();

    keyfaxUrl += '?id=' + Xrm.Page.data.entity.getId();
    keyfaxUrl += '&entityname=' + Xrm.Page.data.entity.getEntityName();

    window.location.href = keyfaxUrl;
}

function View_RibbonClick()
{
    window.location.href = GetKeyfaxURL();
}

function RibbonClick(ssrsname)
{
    window.location.href = 'http://mvhcrmdev:8091/Keyfax_StartUp.aspx';

    // window.open(formUrl);

    // window.location.href = 'https://demo.keyfax.biz/InterView/Main/Main.aspx?co=DemoLive&amp;guid=68c2d835-d9df-4ce9-9960-93a0aa3e6d61';
}

function RibbonClick2()
{
    // Display page context

    var pagecontext = 'Letter = ' + ssrsname + '\n';
    pagecontext += 'Entity = ' + Xrm.Page.data.entity.getEntityName() + '\n';
    pagecontext += 'ID = ' + Xrm.Page.data.entity.getId() + '\n';
    pagecontext += 'User = ' + Xrm.Page.context.getUserId() + '\n';
    pagecontext += 'Organisation = ' + Xrm.Page.context.getOrgUniqueName() + '\n';
    alert(pagecontext);

    // Build a URL and open it

    var url = 'https://www.google.co.uk/search?q=';
    url += Xrm.Page.context.getOrgUniqueName();
    window.open(url);
}

function OnLoad() {
    Xrm.Page.getControl("mvh_jptestid_template").addPreSearch(
     function () {
         Xrm.Page.getControl("mvh_jptestid_template").addCustomFilter('<filter type="and"><condition attribute="mvh_template" operator="eq" value="1"/></filter>');
     });
}

