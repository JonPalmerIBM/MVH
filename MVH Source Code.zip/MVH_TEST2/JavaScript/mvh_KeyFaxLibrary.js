﻿function GetKeyFaxURL()
{
    return 'http://mvhcrmdev:8091/Keyfax_StartUp.aspx';
}

function KeyFaxRibbonClick()
{
    // Launch keyfax start up page with entity type name and ID
    var keyfaxUrl = GetKeyFaxURL();

    keyfaxUrl += '?propertyid=' + Xrm.Page.data.entity.getId();
    keyfaxUrl += '&id=' + Xrm.Page.data.entity.getId();
    keyfaxUrl += '&entityname=' + Xrm.Page.data.entity.getEntityName();

    window.location.href = keyfaxUrl;
}

function Tenancy_KeyFaxRibbonClick()
{
    var propertyid = Xrm.Page.getAttribute("mvh_address").getValue();

    if (propertyid != null)
    {
        // Launch keyfax start up page with entity type name and ID
        var keyfaxUrl = GetKeyFaxURL();

        keyfaxUrl += '?propertyid=' + propertyid[0].id;
        keyfaxUrl += '&id=' + Xrm.Page.data.entity.getId();
        keyfaxUrl += '&entityname=' + Xrm.Page.data.entity.getEntityName();

        window.location.href = keyfaxUrl;
    }
    else
    {
        alert('Please select a property.');
    }
}