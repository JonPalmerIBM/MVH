﻿function SSRS2PDF(reportname, parameter_names, parameter_values)
{
    if (parameter_names == undefined)
        parameter_names = new Array();
    if (parameter_values == undefined)
        parameter_values = new Array();

    var url = 'http://mvhcrmdev:8091/Swordfish_SSRS2PDF.aspx';

    url += '?reportname=' + reportname;
    url += '&regardingobjectid=' + Xrm.Page.data.entity.getId();
    url += '&regardingobjecttypename=' + Xrm.Page.data.entity.getEntityName();

    if (parameter_names.length > 0 && parameter_names.length == parameter_values.length)
    {
        var i;
        for (i = 1; i <= parameter_names.length; i++)
            url += '&' + parameter_names[i - 1] + '=' + parameter_values[i - 1];
    }

    window.open(url, '_blank', 'location=no,scrollbars=yes,status=yes');
}

function mvh_shortlist_OfferLetter()
{
    SSRS2PDF('rptOfferLetter',
        ['ShortlistID'],
        [Xrm.Page.data.entity.getId()]);
}
