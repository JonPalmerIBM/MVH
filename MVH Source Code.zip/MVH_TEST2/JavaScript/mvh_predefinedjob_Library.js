﻿function FormOnLoad()
{
    // Approved Contractor filter
    Xrm.Page.getControl("mvh_contractor").addPreSearch(
        function () {
            Xrm.Page.getControl("mvh_contractor").addCustomFilter(
            '<filter type="and">' +
            '<condition attribute="accountclassificationcode" operator="eq" value="1"/>' +
            '</filter>');
        });

    // Set default contractor on create form
    if (Xrm.Page.ui.getFormType() == 1)
        Xrm.Page.getAttribute('mvh_contractor').setValue([{
            id: '15B80504-1ECA-E711-810E-005056BD092E',
            name: 'MVH PROPERTY SERVICES',
            entityType: 'account'
        }]);

    PopulateExpenseCodes(true);
}

function PopulateExpenseCodes(setoriginalvalue)
{
    var mvh_expensecode = Xrm.Page.getControl('mvh_expensecode');
    var selectedcostcentrecode = Xrm.Page.getAttribute('mvh_costcentrecode').getValue();
    var selectedexpensecode = Xrm.Page.getAttribute('mvh_expensecode').getValue();

    mvh_expensecode.clearOptions();

    if (selectedcostcentrecode != null)
    {
        // Get expense code values linked to this cost centre code
        var url = Xrm.Page.context.getClientUrl() + '/api/data/v8.0/';
        url += 'mvh_expensecoderelationships?$select=mvh_expensecode&$filter=mvh_parentcostcentrecode eq ' + selectedcostcentrecode;

        var req = new XMLHttpRequest();
        req.open('GET', url, true);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    var optionvalue;
                    var optiontext;

                    // Populate expense code values
                    for (var i = 0; i < results.value.length; i++)
                    {
                        optionvalue = results.value[i]["mvh_expensecode"];
                        optiontext = results.value[i]["mvh_expensecode@OData.Community.Display.V1.FormattedValue"];
                        mvh_expensecode.addOption({ text: optiontext, value: optionvalue });
                    }

                    // Set the original value back in
                    if (setoriginalvalue)
                        Xrm.Page.getAttribute('mvh_expensecode').setValue(selectedexpensecode);
                }
            }
        };

        req.send();
    }
}

function GenerateCostCode()
{
    var mvh_costcentrecode = Xrm.Page.getAttribute('mvh_costcentrecode').getText();
    var mvh_expensecode = Xrm.Page.getAttribute('mvh_expensecode').getText();
    var mvh_projectcode = Xrm.Page.getAttribute('mvh_projectcode').getText();
    var mvh_locationcode = Xrm.Page.getAttribute('mvh_locationcostcodes').getText();

    var mvh_costcode = '';

    if (mvh_costcentrecode != null && mvh_expensecode != null && mvh_projectcode != null && mvh_locationcode != null)
    {
        mvh_costcode = mvh_costcentrecode + mvh_expensecode + mvh_projectcode + mvh_locationcode;
    }

    Xrm.Page.getAttribute('mvh_costcode').setValue(mvh_costcode);
}

function mvh_costcentrecode_OnChange()
{
    PopulateExpenseCodes(false);
    Xrm.Page.getAttribute('mvh_costcode').setValue('');
}

function mvh_expensecode_OnChange()
{
    GenerateCostCode();
}

function mvh_projectcode_OnChange()
{
    GenerateCostCode();
}

function mvh_locationcode_OnChange()
{
    GenerateCostCode();
}