﻿function FormOnLoad()
{
    // Approved Contractor filter
    Xrm.Page.getControl("mvh_accountid").addPreSearch(
        function() {
            Xrm.Page.getControl("mvh_accountid").addCustomFilter(
            '<filter type="and">' +
            '<condition attribute="accountclassificationcode" operator="eq" value="1"/>' +
            '</filter>');
        });

    // Set default contractor on create form
    if (Xrm.Page.ui.getFormType() == 1)
        Xrm.Page.getAttribute('mvh_accountid').setValue([{ 
            id: '15B80504-1ECA-E711-810E-005056BD092E', 
            name: 'MVH PROPERTY SERVICES', 
            entityType: 'account'
        }]);

    PopulateExpenseCodes(true);

    mvh_inspection_OnChange();
    mvh_scheme_OnChange();
    mvh_predefinedjobid_OnChange();

    if (Xrm.Page.ui.getFormType() == 2)
    {
        Xrm.Page.getControl('mvh_createdon').setDisabled(true);
    }

    mvh_inspector_systemuserid_OnChange();

    // Apply minimum value?
    if (Xrm.Page.ui.getFormType() == 2)
    {
        var minimumvalue = 35;
        var mvh_totalcommittedcost = Xrm.Page.getAttribute('mvh_totalcommittedcost').getValue();
        if (mvh_totalcommittedcost == null)
            mvh_totalcommittedcost = 0;

        if (mvh_totalcommittedcost < minimumvalue)
        {
            Xrm.Page.ui.setFormNotification("Do you need to apply the minimum value?", "ERROR", "applyminvalue");
        }
    }

    ShowCurrentStage();

    if (Xrm.Page.ui.getFormType() != 1)
    {
        Xrm.Page.getControl('mvh_scheme').setDisabled(true);
    }
}

function FormOnSave(context)
{
    Xrm.Page.getAttribute('mvh_costcode').setSubmitMode('always');

    if (Xrm.Page.getAttribute('mvh_createdon').getValue() == null)
    {
        Xrm.Page.getAttribute('mvh_createdon').setValue(new Date());
    }
    else
    {
        var now = new Date();
        var preventsave = false;
        var mvh_createdon = Xrm.Page.getAttribute('mvh_createdon').getValue();
        var mvh_physicalcompleteddate = Xrm.Page.getAttribute("mvh_physicalcompleteddate").getValue();
        var mvh_abandoneddate = Xrm.Page.getAttribute("mvh_abandoneddate").getValue();

        if (mvh_createdon > now)
        {
            preventsave = true;
            Xrm.Utility.alertDialog('Created On date cannot be in the future.', function () { });
        }

        if (mvh_physicalcompleteddate != null)
        {
            if (mvh_physicalcompleteddate < mvh_createdon)
            {
                preventsave = true;
                Xrm.Utility.alertDialog('Completed date cannot be before the Created On date.', function () { });
            }
        }

        if (mvh_abandoneddate != null) {
            if (mvh_abandoneddate < mvh_createdon) {
                preventsave = true;
                Xrm.Utility.alertDialog('Abandoned date cannot be before the Created On date.', function () { });
            }
        }

        if (preventsave)
        {
            var saveEvent = context.getEventArgs();
            saveEvent.preventDefault();
        }
    }
}

function PopulateExpenseCodes(setoriginalvalue)
{
    var mvh_expensecode = Xrm.Page.getControl('mvh_expensecode');
    var selectedcostcentrecode = Xrm.Page.getAttribute('mvh_costcentrecode').getValue();
    var selectedexpensecode = Xrm.Page.getAttribute('mvh_expensecode').getValue();

    mvh_expensecode.clearOptions();

    if (selectedcostcentrecode != null)
    {
        // Get expense code values linked to this cost centre code
        var url = Xrm.Page.context.getClientUrl() + '/api/data/v8.0/';
        url += 'mvh_expensecoderelationships?$select=mvh_expensecode&$filter=mvh_parentcostcentrecode eq ' + selectedcostcentrecode;

        var req = new XMLHttpRequest();
        req.open('GET', url, true);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    var optionvalue;
                    var optiontext;

                    // Populate expense code values
                    for (var i = 0; i < results.value.length; i++)
                    {
                        optionvalue = results.value[i]["mvh_expensecode"];
                        optiontext = results.value[i]["mvh_expensecode@OData.Community.Display.V1.FormattedValue"];
                        mvh_expensecode.addOption({ text: optiontext, value: optionvalue });
                    }

                    // Set the original value back in
                    if (setoriginalvalue)
                        Xrm.Page.getAttribute('mvh_expensecode').setValue(selectedexpensecode);
                }
            }
        };

        req.send();
    }
}

function GenerateCostCode()
{
    var mvh_costcentrecode = Xrm.Page.getAttribute('mvh_costcentrecode').getText();
    var mvh_expensecode = Xrm.Page.getAttribute('mvh_expensecode').getText();
    var mvh_projectcode = Xrm.Page.getAttribute('mvh_projectcode').getText();
    var mvh_locationcode = Xrm.Page.getAttribute('mvh_locationcostcode').getText();

    var mvh_costcode = '';

    if (mvh_costcentrecode != null && mvh_expensecode != null && mvh_projectcode != null && mvh_locationcode != null)
    {
        mvh_costcode = mvh_costcentrecode + mvh_expensecode + mvh_projectcode + mvh_locationcode;
    }

    Xrm.Page.getAttribute('mvh_costcode').setValue(mvh_costcode);
}

function mvh_costcentrecode_OnChange()
{
    PopulateExpenseCodes(false);
    Xrm.Page.getAttribute('mvh_costcode').setValue('');
}

function mvh_expensecode_OnChange()
{
    GenerateCostCode();
}

function mvh_projectcode_OnChange()
{
    GenerateCostCode();
}

function mvh_locationcode_OnChange()
{
    GenerateCostCode();
}

function mvh_inspection_OnChange()
{
    var id = "inspection_notification";

    if (Xrm.Page.getAttribute('mvh_inspection').getValue())
    {
        Xrm.Page.ui.setFormNotification("This is an inspection record.", "INFO", id);
    }
    else
    {
        Xrm.Page.ui.clearFormNotification(id);
    }
}

function mvh_scheme_OnChange()
{
    var id = "scheme_notification";

    if (Xrm.Page.getAttribute('mvh_scheme').getValue()) {
        Xrm.Page.ui.setFormNotification("This is a scheme record.", "INFO", id);
    }
    else {
        Xrm.Page.ui.clearFormNotification(id);
    }

    id = "schemetemplate_notification";

    if (Xrm.Page.getAttribute('mvh_schemetemplate_repairid').getValue() != null) {
        Xrm.Page.ui.setFormNotification("This repair is part of a scheme.", "INFO", id);
    }
    else {
        Xrm.Page.ui.clearFormNotification(id);
    }
}

function mvh_predefinedjobid_OnChange()
{
    var id = "sor_notification";
    var mvh_predefinedjobid = Xrm.Page.getAttribute('mvh_predefinedjobid').getValue();

    if (mvh_predefinedjobid != null) {
        var url = Xrm.Page.context.getClientUrl() + '/api/data/v8.0/';
        url += 'mvh_predefinedjobs(' + mvh_predefinedjobid[0].id.replace('{', '').replace('}', '') + ')';
        url += '?$select=mvh_programmedworksprompt';

        var req = new XMLHttpRequest();
        req.open('GET', url, true);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var result = JSON.parse(this.response);
                    if (result["mvh_programmedworksprompt"] != null) {
                        Xrm.Page.ui.setFormNotification(result["mvh_programmedworksprompt"], "INFO", id);
                    }
                }
            }
        };

        req.send();
    }
    else {
        Xrm.Page.ui.clearFormNotification(id);
    }
}

function mvh_inspector_systemuserid_OnChange()
{
    var mvh_inspector_systemuserid = Xrm.Page.getAttribute('mvh_inspector_systemuserid').getValue();

    if (mvh_inspector_systemuserid != null)
    {
        Xrm.Page.getControl("mvh_appointmentslotid").removePreSearch(mvh_inspector_systemuserid_CustomFilter);
        Xrm.Page.getControl("mvh_appointmentslotid").addPreSearch(mvh_inspector_systemuserid_CustomFilter);
    }
}

function mvh_inspector_systemuserid_CustomFilter()
{
    var mvh_inspector_systemuserid = Xrm.Page.getAttribute('mvh_inspector_systemuserid').getValue();

    Xrm.Page.getControl("mvh_appointmentslotid").addCustomFilter(
        '<filter type="and">' +
        '<filter type="or">' +
          '<condition attribute="mvh_date" operator="next-x-months" value="6" />' +
          '<condition attribute="mvh_date" operator="today" />' +
        '</filter>' +
        '<condition attribute="mvh_repairmoduleid" operator="null" />' +
        '<condition attribute="mvh_inspector_systemuserid" operator="eq" uitype="systemuser" value="' + mvh_inspector_systemuserid[0].id +
        '" />' +
        '</filter>');
}

function SchemePropertyLookup()
{
    if (!Xrm.Page.data.entity.getIsDirty())
    {
        var url = 'http://mvhcrmdev:8091/SchemePropertyLookup.aspx';

        url += '?id=' + Xrm.Page.data.entity.getId();

        window.showModalDialog(url, '', 'dialogHeight:600px;dialogWidth:500px;center:yes;resizable:no;scroll:yes;status:no;');

        Xrm.Page.data.refresh();
    }
    else
    {
        alert('Please save the record before adding scheme properties.');
    }
}

function CreateStageHistory(nextstage)
{
    var id = Xrm.Page.data.entity.getId().replace('{', '').replace('}', '');
    var stagehistory = {};

    stagehistory["mvh_Repairid@odata.bind"] = "/mvh_repairmodules(" + id + ")";
    stagehistory["mvh_stage"] = nextstage;
    stagehistory["mvh_datechanged"] = new Date();

    var url = Xrm.Page.context.getClientUrl() + '/api/data/v8.0/';
    url += 'mvh_stagehistories';

    var req = new XMLHttpRequest();
    req.open('POST', url, true);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status != 204)
            {
                alert(JSON.parse(this.response).error.message);
            }
        }
    };

    req.send(JSON.stringify(stagehistory));
}

function CanMoveToStage(nextstage)
{
    if (Xrm.Page.data.entity.getIsDirty())
    {
        Xrm.Utility.alertDialog('Please save this record first.', function() { });
        return false;
    }

    if (Xrm.Page.getAttribute('mvh_pending').getValue()) {
        Xrm.Utility.alertDialog('This repair is pending approval.', function () { });
        return false;
    }

    var canmove = true;
    var mvh_stage = Xrm.Page.getAttribute('mvh_stage').getValue();
    var mvh_stageText = Xrm.Page.getAttribute('mvh_stage').getText();

    if (nextstage == mvh_stage)
    {
        Xrm.Utility.alertDialog('This repair is already at stage ' + nextstage + '.', function() { });
        return false;
    }

    switch (nextstage)
    {
        case 2:
            switch (mvh_stage)
            {
                case 2:
                case 30:
                case 50:
                case 81:
                case 99:
                    canmove = false;
                    break;
            }
            break;
        case 3:
            switch (mvh_stage)
            {
                case 3:
                case 30:
                case 50:
                case 81:
                case 99:
                    canmove = false;
                    break;
            }
            break;
        case 50:
            switch (mvh_stage)
            {
                case 1:
                case 30:
                case 50:
                case 81:
                case 99:
                    canmove = false;
                    break;
            }
            break;
        case 81:
            switch (mvh_stage)
            {
                case 1:
                case 50:
                case 81:
                case 99:
                    canmove = false;
                    break;
            }
            break;
    }

    if (!canmove)
    {
        Xrm.Utility.alertDialog('Cannot move to stage ' + nextstage + ' when the repair is at stage ' + mvh_stage + '.', function() { });
    }

    return canmove;
}

function PrintTicket()
{
    if (!CanMoveToStage(2))
        return;

    CreateStageHistory(2);
    // TODO: run SSRS report to generate ticket
    Xrm.Page.data.refresh();
    Xrm.Page.ui.setFormNotification('Stage: 02 - Ticket Printed', "INFO", '_ShowCurrentStage');
}

function SendToOpti()
{
    if (!CanMoveToStage(3))
        return;

    var id = Xrm.Page.data.entity.getId().replace('{', '').replace('}', '');
    var url = Xrm.Page.context.getClientUrl() + '/api/data/v8.0/';

    url += 'mvh_stagehistories';
    url += '?$select=mvh_stage';
    url += '&$filter=_mvh_repairid_value eq ' + id;
    url += ' and mvh_stage eq 3';

    var req = new XMLHttpRequest();
    req.open('GET', url, true);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                if (results.value.length == 0) {
                    CreateStageHistory(3);
                    Xrm.Page.data.refresh();
                    Xrm.Page.ui.setFormNotification('Repair sent to Opti.', "INFO", '_SendToOpti');
                    Xrm.Page.ui.setFormNotification('Stage: 03 - Ticket Passed to Opti', "INFO", '_ShowCurrentStage');
                }
                else
                {
                    Xrm.Utility.alertDialog('This repair has already been sent to Opti.', function () { });
                }
            }
        }
    };

    req.send();
}

function CompleteRepair()
{
    if (!CanMoveToStage(81))
        return;

    Xrm.Utility.confirmDialog('Complete this repair?',
        function () {
            // Yes
            CreateStageHistory(81);
            Xrm.Page.data.refresh();
            Xrm.Page.ui.setFormNotification('Repair completed.', "INFO", '_CompleteRepair');
            Xrm.Page.ui.setFormNotification('Stage: 81 - Fully Phys Complete', "INFO", '_ShowCurrentStage');
        },
        function () {
            // No

        });
}

function AbandonRepair()
{
    if (!CanMoveToStage(50))
        return;

    Xrm.Utility.confirmDialog('Abandon this repair?',
        function ()
        {
            // Yes
            CreateStageHistory(50);
            Xrm.Page.data.refresh();
            Xrm.Page.ui.setFormNotification('Repair abandoned.', "INFO", '_AbandonRepair');
            Xrm.Page.ui.setFormNotification('Stage: 50 - Fully Abandoned', "INFO", '_ShowCurrentStage');
        },
        function ()
        {
            // No

        });
}

function ShowCurrentStage()
{
    var id = Xrm.Page.data.entity.getId().replace('{', '').replace('}', '');
    var mvh_stageText = Xrm.Page.getAttribute('mvh_stage').getText();

    if (Xrm.Page.ui.getFormType() != 1)
    {
        var url = Xrm.Page.context.getClientUrl() + '/api/data/v8.0/';

        url += 'mvh_stagehistories';
        url += '?$select=mvh_stage';
        url += '&$filter=_mvh_repairid_value eq ' + id;
        url += '&$top=1';
        url += '&$orderby=createdon desc';

        var req = new XMLHttpRequest();
        req.open('GET', url, true);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    if (result["mvh_stage"] != null)
                    {
                        if (results["mvh_stage"] != 1)
                            Xrm.Page.getControl('mvh_createdon').setDisabled(true);
                        mvh_stageText = result["mvh_stage@OData.Community.Display.V1.FormattedValue"];
                    }
                }
            }
        };

        req.send();
    }

    Xrm.Page.ui.setFormNotification('Stage: ' + mvh_stageText, "INFO", '_ShowCurrentStage');
}

