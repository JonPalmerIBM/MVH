﻿function SetWordTemplate(template) {
    var url = 'http://mvhcrmdev:8091/WordTemplate.aspx';

    url += '?template=' + template;
    url += '&regardingobjectid=' + Xrm.Page.data.entity.getId();
    url += '&regardingobjecttypename=' + Xrm.Page.data.entity.getEntityName();

    window.location.href = url;
    // window.open(url, '_blank', 'location=no,scrollbars=yes,status=yes');
}

function WordTemplate_Case_StructuralAltDeclined() {
    SetWordTemplate('Structural Alt - Declined');
}
