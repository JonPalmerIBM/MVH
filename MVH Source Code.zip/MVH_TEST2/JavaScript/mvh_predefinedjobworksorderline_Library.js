﻿function mvh_sorvalue_OnChange() {
    RecalculateLineValue();
}

function mvh_qty_OnChange() {
    RecalculateLineValue();
}

function RecalculateLineValue() {
    var mvh_sorvalue = Xrm.Page.getAttribute('mvh_sorvalue').getValue();
    var mvh_qty = Xrm.Page.getAttribute('mvh_qty').getValue();
    var mvh_linevalue = 0;

    if (mvh_sorvalue != null && mvh_qty != null) {
        mvh_linevalue = (mvh_sorvalue * mvh_qty);
    }

    Xrm.Page.getAttribute('mvh_linevalue').setValue(mvh_linevalue);
    Xrm.Page.getAttribute('mvh_linevalue').setSubmitMode('always');
}

function SetRecordName() {
    var mvh_sor = Xrm.Page.getAttribute('mvh_sor').getValue();

    if (mvh_sor != null) {
        Xrm.Page.getAttribute('mvh_name').setValue(mvh_sor[0].name);
    }

    if (mvh_sor != null) {
        var url = Xrm.Page.context.getClientUrl() + '/api/data/v8.0/';
        url += 'mvh_sors(' + mvh_sor[0].id.replace('{', '').replace('}', '') + ')';
        url += '?$select=mvh_value';

        var req = new XMLHttpRequest();
        req.open('GET', url, true);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var result = JSON.parse(this.response);
                    if (result["mvh_value"] != null) {
                        Xrm.Page.getAttribute('mvh_sorvalue').setValue(result["mvh_value"]);
                    }
                }
            }
        };

        req.send();
    }
    else {
        Xrm.Page.getAttribute('mvh_sorvalue').setValue(0);
    }
}