﻿function FormOnLoad()
{
    // Default to today's date on a create form
    if (Xrm.Page.ui.getFormType() == 1)
    {
        Xrm.Page.getAttribute('mvh_datechanged').setValue(Date.now());
    }

    GetCurrentStage();
}

function FormOnSave(context)
{

}

function mvh_stage_OnChange()
{
    if (Xrm.Page.getAttribute('mvh_stage').getValue() == null)
        Xrm.Page.getAttribute('mvh_name').setValue(null);
    else
        Xrm.Page.getAttribute('mvh_name').setValue(Xrm.Page.getAttribute('mvh_stage').getText());
}

function GetCurrentStage()
{
    var id = Xrm.Page.getAttribute('mvh_repairid').getValue()[0].id.replace('{', '').replace('}', '');
    var url = Xrm.Page.context.getClientUrl() + '/api/data/v8.0/';

    url += 'mvh_repairmodules(' + id + ')';
    url += '?$select=mvh_stage,mvh_pending';

    var req = new XMLHttpRequest();
    req.open('GET', url, true);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var result = JSON.parse(this.response);
                if (result["mvh_stage"] != null)
                {
                    var currentstage = result["mvh_stage"];
                    if (result["mvh_pending"] == true)
                        currentstage = 900;
                    SetStageValues(currentstage, result["mvh_stage@OData.Community.Display.V1.FormattedValue"]);
                }
            }
        }
    };

    req.send();
}

function SetStageValues(currentstage, desc)
{
    var mvh_stage = Xrm.Page.getControl('mvh_stage');
    var notification = 'Current stage is ' + desc + '.';

    // Check if user can override stage
    var superuserroleid = '8A9FF8EA-17E0-E711-810F-005056BD092E';
    var roles = Xrm.Page.context.getUserRoles();
    for (var i = 0; i < roles.length; i++)
    {
        if (roles[i].toUpperCase() == superuserroleid)
        {
            // Not a valid stage so no options will be removed
            currentstage = 0;
        }
    }

    switch (currentstage)
    {
        case 1:
            mvh_stage.removeOption(1);
            mvh_stage.removeOption(6);
            mvh_stage.removeOption(11);
            mvh_stage.removeOption(15);
            mvh_stage.removeOption(30);
            mvh_stage.removeOption(50);
            mvh_stage.removeOption(81);
            mvh_stage.removeOption(99);
            break;
        case 2:
            mvh_stage.removeOption(2);
            mvh_stage.removeOption(1);
            mvh_stage.removeOption(99);
            break;
        case 3:
            mvh_stage.removeOption(3);
            mvh_stage.removeOption(1);
            mvh_stage.removeOption(99);
            break;
        case 6:
            mvh_stage.removeOption(6);
            mvh_stage.removeOption(1);
            mvh_stage.removeOption(99);
            break;
        case 11:
            mvh_stage.removeOption(11);
            mvh_stage.removeOption(1);
            mvh_stage.removeOption(99);
            break;
        case 15:
            mvh_stage.removeOption(15);
            mvh_stage.removeOption(1);
            mvh_stage.removeOption(99);
            break;
        case 30:
            mvh_stage.removeOption(30);
            mvh_stage.removeOption(1);
            mvh_stage.removeOption(2);
            mvh_stage.removeOption(3);
            mvh_stage.removeOption(6);
            mvh_stage.removeOption(11);
            mvh_stage.removeOption(15);
            mvh_stage.removeOption(50);
            mvh_stage.removeOption(99);
            break;
        case 81:
            mvh_stage.removeOption(81);
            mvh_stage.removeOption(1);
            mvh_stage.removeOption(2);
            mvh_stage.removeOption(3);
            mvh_stage.removeOption(6);
            mvh_stage.removeOption(11);
            mvh_stage.removeOption(15);
            mvh_stage.removeOption(30);
            mvh_stage.removeOption(50);
            break;
        case 50:
        case 99:
            // Remove all options so record cannot be saved
            mvh_stage.clearOptions();
            notification += ' This repair cannot be moved to another stage.';
            break;
        case 900:
            // Remove all options so record cannot be saved
            mvh_stage.clearOptions();
            notification += ' This repair is pending approval and cannot be moved to another stage.';
            break;
        default:
            // Do not remove any options so this user can select any stage
            notification += ' Your permissions allow you to move this repair to any other stage.';
            break;
    }

    Xrm.Page.ui.setFormNotification(notification, "INFO", "currentstage");
}