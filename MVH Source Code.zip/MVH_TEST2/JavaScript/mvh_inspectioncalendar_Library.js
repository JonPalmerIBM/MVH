﻿function FormOnLoad()
{

}

function FormOnSave(context)
{
    var mvh_date = Xrm.Page.getAttribute('mvh_date').getValue();

    if (mvh_date.getDay() != 1)
    {
        Xrm.Page.ui.setFormNotification("Week commencing date must be a Monday.", "ERROR", "weekcommencing");
        var saveEvent = context.getEventArgs();
        saveEvent.preventDefault();
    }

    if (mvh_date != null)
        Xrm.Page.getAttribute('mvh_name').setValue('W/C ' + mvh_date.toString().substring(0, 15));

    if (Xrm.Page.getAttribute('mvh_amslots').getValue() == null)
        Xrm.Page.getAttribute('mvh_amslots').setValue(0)
    if (Xrm.Page.getAttribute('mvh_pmslots').getValue() == null)
        Xrm.Page.getAttribute('mvh_pmslots').setValue(0)
    if (Xrm.Page.getAttribute('mvh_tueam').getValue() == null)
        Xrm.Page.getAttribute('mvh_tueam').setValue(0)
    if (Xrm.Page.getAttribute('mvh_tuepm').getValue() == null)
        Xrm.Page.getAttribute('mvh_tuepm').setValue(0)
    if (Xrm.Page.getAttribute('mvh_wedam').getValue() == null)
        Xrm.Page.getAttribute('mvh_wedam').setValue(0)
    if (Xrm.Page.getAttribute('mvh_wedpm').getValue() == null)
        Xrm.Page.getAttribute('mvh_wedpm').setValue(0)
    if (Xrm.Page.getAttribute('mvh_thuam').getValue() == null)
        Xrm.Page.getAttribute('mvh_thuam').setValue(0)
    if (Xrm.Page.getAttribute('mvh_thupm').getValue() == null)
        Xrm.Page.getAttribute('mvh_thupm').setValue(0)
    if (Xrm.Page.getAttribute('mvh_friam').getValue() == null)
        Xrm.Page.getAttribute('mvh_friam').setValue(0)
    if (Xrm.Page.getAttribute('mvh_fripm').getValue() == null)
        Xrm.Page.getAttribute('mvh_fripm').setValue(0)
}
