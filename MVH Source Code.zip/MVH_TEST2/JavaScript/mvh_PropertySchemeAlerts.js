﻿function PropertySchemeAlerts()
{
    var id = Xrm.Page.data.entity.getId().replace('{', '').replace('}', '');
    var url = Xrm.Page.context.getClientUrl() + '/api/data/v8.0/';

    url += 'mvh_repairmodules';
    url += '?$select=mvh_description';
    url += '&$filter=_mvh_propertyid_value eq ' + id;
    url += ' and _mvh_schemetemplate_repairid_value ne null and mvh_physicalcompleteddate eq null and statecode eq 0';

    var req = new XMLHttpRequest();
    req.open('GET', url, true);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                for (var i = results.value.length; i >= 1; i--)
                {
                    var of = '';
                    if (results.value.length > 1)
                        of = " (" + i.toString() + " of " + results.value.length.toString() + ")";
                    Xrm.Page.ui.setFormNotification("Active scheme alert" + of + ": " + results.value[i - 1]["mvh_description"], "INFO", "activeschemealert" + i.toString());
                }
            }
        }
    };

    req.send();
}