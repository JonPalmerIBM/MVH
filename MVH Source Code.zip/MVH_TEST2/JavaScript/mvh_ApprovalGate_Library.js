﻿function FormOnLoad()
{
    Xrm.Page.getControl('mvh_repairvalue').setDisabled(true);
    CheckIfCanApprove();
}

function FormOnSave()
{
    if (Xrm.Page.ui.getFormType() == 1)
    {
        var mvh_name = Xrm.Page.getAttribute('mvh_name').getValue();
        var mvh_reason = Xrm.Page.getAttribute('mvh_reason').getText();

        Xrm.Page.getAttribute('mvh_name').setValue(mvh_name + ' - ' + mvh_reason);
    }
}

function mvh_approved_OnChange()
{
    var mvh_approved = Xrm.Page.getAttribute('mvh_approved').getValue();

    if (mvh_approved)
    {
        Xrm.Page.getAttribute('mvh_systemuserid').setValue([{
            id: Xrm.Page.context.getUserId(),
            name: Xrm.Page.context.getUserName(),
            entityType: 'systemuser'
        }]);
    }
    else
    {
        Xrm.Page.getAttribute('mvh_systemuserid').setValue(null);
    }
}

function CheckIfCanApprove()
{
    var id = Xrm.Page.context.getUserId().replace('{', '').replace('}', '');
    var url = Xrm.Page.context.getClientUrl() + '/api/data/v8.0/';

    url += 'systemusers(' + id + ')';
    url += '?$select=mvh_repairspendinglimit';

    var req = new XMLHttpRequest();
    req.open('GET', url, true);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                var spendinglimit = 0;
                if (results["mvh_repairspendinglimit"] != null)
                    spendinglimit = results["mvh_repairspendinglimit"];
                var repairvalue = Xrm.Page.getAttribute('mvh_repairvalue').getValue();
                if (repairvalue == null)
                    repairvalue = 0;
                if (spendinglimit < repairvalue) {
                    Xrm.Page.getControl('mvh_approved').setDisabled(true);
                    Xrm.Page.ui.setFormNotification("You cannot approve this repair.", "ERROR", "_approverepair");
                }
            }
        }
    };

    req.send();
}