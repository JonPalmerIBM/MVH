﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Xrm.Sdk;

public partial class SchemePropertyLookup : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            lblFound.Visible = false;
            Results.Visible = false;
            btnOk.Enabled = false;
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Results.Visible = false;
        chkResults.Items.Clear();

        if (txtSearch.Text != string.Empty)
        {
            D365EntityHelper xrm = new D365EntityHelper("mvh_properties");
            StringBuilder xml = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\" count=\"500\">");

            xml.Append("<entity name=\"mvh_properties\">");
            xml.Append("<attribute name=\"mvh_name\" />");
            xml.Append("<order attribute=\"mvh_name\" descending=\"false\" />");
            xml.Append("<filter type=\"and\">");
            xml.Append("<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />");
            xml.Append("<filter type=\"or\">");
            xml.AppendFormat("<condition attribute=\"mvh_name\" operator=\"like\" value=\"%{0}%\" />", txtSearch.Text);
            xml.AppendFormat("<condition attribute=\"mvh_postcode\" operator=\"like\" value=\"%{0}%\" />", txtSearch.Text);
            xml.Append("</filter>");
            xml.Append("</filter>");
            xml.Append("</entity>");
            xml.Append("</fetch>");

            if (xrm.FetchEntityCollection(xml.ToString()))
            {
                foreach (Entity ent in xrm.Results.Entities)
                {
                    xrm.Retrieve(ent);
                    chkResults.Items.Add(new ListItem(xrm.Value("mvh_name"), ent.Id.ToString()));
                }
                Results.Visible = true;
            }

            Response.Write(xrm.Message);
        }

        if (chkResults.Items.Count > 0)
            btnOk.Enabled = true;
        else
            btnOk.Enabled = false;

        lblFound.Visible = true;
        lblFound.Text = string.Format("Found: {0}", chkResults.Items.Count.ToString());
    }

    protected void btnOk_Click(object sender, EventArgs e)
    {
        D365EntityHelper scheme = new D365EntityHelper("mvh_schemeproperty");

        foreach (ListItem item in chkResults.Items)
        {
            if (item.Selected)
            {
                scheme.InitialiseSchema();
                scheme.AddLookup("mvh_scheme", "mvh_repairmodule", Request.QueryString["id"]);
                scheme.AddLookup("mvh_property", "mvh_properties", item.Value);
                // Set owner
                if (Request["ownerid"] != null)
                {
                    scheme.AddLookup("mvh_ownerid", "systemuser", Request.QueryString["ownerid"].Replace("{", string.Empty).Replace("}", string.Empty));
                }
                scheme.Create();
                if (Request["ownerid"] != null)
                {
                    scheme.SetOwner(Request.QueryString["ownerid"].Replace("{", string.Empty).Replace("}", string.Empty));
                }
            }
        }

        ClientScript.RegisterStartupScript(typeof(Page), "closePage", "window.close();", true);
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }

    protected void lnkSelectAll_Click(object sender, EventArgs e)
    {
        foreach (ListItem item in chkResults.Items)
        {
            item.Selected = true;
        }
    }

    protected void lnkSelectNone_Click(object sender, EventArgs e)
    {
        chkResults.ClearSelection();
    }

    protected void chkSelect_CheckedChanged(object sender, EventArgs e)
    {
        foreach (ListItem item in chkResults.Items)
        {
            item.Selected = chkSelect.Checked;
        }
    }
}