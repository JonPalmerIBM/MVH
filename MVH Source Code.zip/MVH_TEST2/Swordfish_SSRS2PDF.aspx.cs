﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using System.Xml;

public partial class Swordfish_SSRS2PDF : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["reportname"] != null && Request.QueryString["regardingobjectid"] != null && Request.QueryString["regardingobjecttypename"] != null)
            {
                // Unique filename
                string reportname = Request.QueryString["reportname"];
                Guid id = Guid.NewGuid();
                string PDFdoc = string.Format("{0}{1}_{2}.PDF", ConfigurationManager.AppSettings["swordfish.pollingfolder"], reportname.Replace("/", "_").Replace("\\", "_"), id.ToString());
                string XMLdoc = string.Format("{0}{1}_{2}.XML", ConfigurationManager.AppSettings["swordfish.pollingfolder"], reportname.Replace("/", "_").Replace("\\", "_"), id.ToString());

                // Set report parameters
                string ignore = "reportname,regardingobjectid,regardingobjecttypename";
                List<ReportParameter> parameters = new List<ReportParameter>();

                foreach (string s in Request.QueryString)
                {
                    if (!ignore.Contains(s.ToLower()))
                        parameters.Add(new ReportParameter(s, Request.QueryString[s]));
                }

                // Generate PDF document
                try
                {
                    rptCRM.ProcessingMode = ProcessingMode.Remote;
                    ServerReport serverReport = rptCRM.ServerReport;

                    serverReport.ReportServerUrl = new Uri(ConfigurationManager.AppSettings["swordfish.reportserverurl"]);
                    serverReport.ReportPath = string.Format("{0}{1}", ConfigurationManager.AppSettings["swordfish.reportpath"], reportname);

                    rptCRM.ServerReport.SetParameters(parameters);

                    // Output PDF to browser
                    Warning[] warnings;
                    string[] streamids;
                    string mimeType, encoding, extension;

                    byte[] bytes = rptCRM.ServerReport.Render("PDF", null, out mimeType, out encoding, out extension, out streamids, out warnings);

                    // Save the PDF document
                    System.IO.File.WriteAllBytes(PDFdoc, bytes);

                    // Save the XML document
                    string xml = SwordfishIndexingXML(reportname);
                    System.IO.File.WriteAllText(XMLdoc, xml);

                    // Correspondence history
                    CorrespondenceHistory hist = new CorrespondenceHistory();
                    hist.Create(Request.QueryString["reportname"], "1", Request.QueryString["regardingobjecttypename"], Request.QueryString["regardingobjectid"]);

                    // Output the PDF document to the browser
                    Response.Buffer = true;
                    Response.Clear();
                    Response.ContentType = mimeType;
                    Response.AddHeader("content-disposition", "inline; filename=" + PDFdoc);
                    Response.BinaryWrite(bytes);
                    Response.Flush();
                    Response.End();
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
        }
        else
        {

        }
    }

    string SwordfishIndexingXML(string FileName)
    {
        StringBuilder xml = new StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\" ?>");

        string IndexedDate = DateTime.UtcNow.ToString("s");
        string IndexedBy = User.Identity.Name;

        // Retrieve metadata for this document
        SwordfishMetadata swordfish = new SwordfishMetadata(FileName, Request.QueryString);

        xml.AppendFormat("<Metadata>");

        xml.AppendFormat("<SystemMetadata>");
        xml.AppendFormat("<ScannedBy>{0}</ScannedBy>", IndexedBy);
        xml.AppendFormat("<GenerationDate>{0}</GenerationDate>", IndexedDate);
        xml.AppendFormat("<IndexedBy>{0}</IndexedBy>", IndexedBy);
        xml.AppendFormat("<IndexedOn>{0}</IndexedOn>", IndexedDate);
        xml.AppendFormat("<FileName>{0}</FileName>", FileName);

        xml.AppendFormat("<ScanInfo>");
            xml.AppendFormat("<NumberOfPagesScanned>1</NumberOfPagesScanned>");
            xml.AppendFormat("<IpAddress>UNKNOWN</IpAddress>");
            xml.AppendFormat("<MachineName>UNKNOWN</MachineName>");
            xml.AppendFormat("<NumberOfBlankPages>0</NumberOfBlankPages>");
            xml.AppendFormat("<Resolution>UNKNOWN</Resolution>");
            xml.AppendFormat("<NumberOfColourPages>0</NumberOfColourPages>");
            xml.AppendFormat("<NumberOfBlackAndWhitePages>0</NumberOfBlackAndWhitePages>");
            xml.AppendFormat("<BatchPageSize>UNKNOWN</BatchPageSize>");
            xml.AppendFormat("<BatchName>0</BatchName>");
            xml.AppendFormat("<ImageManipulations>UNKNOWN</ImageManipulations>");
            xml.AppendFormat("<ScanStationId>UNKNOWN</ScanStationId>");
            xml.AppendFormat("<NumberOfPagesSentToDocumentManagement>0</NumberOfPagesSentToDocumentManagement>");
            xml.AppendFormat("<SingleSided>UNKNOWN</SingleSided>");
            xml.AppendFormat("<DoubleSided>UNKNOWN</DoubleSided>");
            xml.AppendFormat("<QualityVerified>UNKNOWN</QualityVerified>");
            xml.AppendFormat("<QualityVerifiedBy>UNKNOWN</QualityVerifiedBy>");
            xml.AppendFormat("<QualityVerifiedOn>{0}</QualityVerifiedOn>", IndexedDate);
        xml.AppendFormat("</ScanInfo>");

        xml.AppendFormat("</SystemMetadata>");

        xml.AppendFormat("<UserDefinedMetadata DocumentDescription=\"{0}\">", swordfish.DocumentDescription);
            xml.AppendFormat("<LetCat>{0}</LetCat>", swordfish.LetCat);
            xml.AppendFormat("<LetSubCat>{0}</LetSubCat>", swordfish.LetSubCat);
            xml.AppendFormat("<Reviewdate>{0}</Reviewdate>", IndexedDate);
            xml.AppendFormat("<Reference>{0}</Reference>", swordfish.PersonContact.Reference);
            xml.AppendFormat("<Initial>{0}</Initial>", swordfish.PersonContact.Initial);
            xml.AppendFormat("<Surname>{0}</Surname>", swordfish.PersonContact.Surname);
            xml.AppendFormat("<HouseNumber>{0}</HouseNumber>", swordfish.PersonContact.HouseNumber);
            xml.AppendFormat("<AddressLine1>{0}</AddressLine1>", swordfish.PersonContact.AddressLine1);
            xml.AppendFormat("<AddressLine2>{0}</AddressLine2>", swordfish.PersonContact.AddressLine2);
            xml.AppendFormat("<Postcode>{0}</Postcode>", swordfish.PersonContact.Postcode);
            xml.AppendFormat("<DOB>{0}</DOB>", swordfish.PersonContact.DOB);
        xml.AppendFormat("</UserDefinedMetadata>");

        xml.AppendFormat("</MetaData>");

        return xml.ToString();
    }
}