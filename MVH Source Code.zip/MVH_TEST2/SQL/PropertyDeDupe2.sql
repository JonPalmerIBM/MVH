-- All properties NOT linked to a tenancy, but are linked to something else

SELECT mvh_propertyreference, mvh_name, mvh_propertiesid FROM mvh_propertiesbase WHERE statecode = 0 AND statuscode = 1 AND mvh_propertiesid IN 
(
SELECT mvh_propertyid AS 'PropertyID' FROM incidentbase WHERE mvh_propertyid IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_propertyid AS 'PropertyID' FROM mvh_advertisedpropertybase WHERE mvh_propertyid IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_tenantaddress AS 'PropertyID' FROM mvh_asb_base WHERE mvh_tenantaddress IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_perpertratoraddresstenant AS 'PropertyID' FROM mvh_asb_base WHERE mvh_perpertratoraddresstenant IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_address AS 'PropertyID' FROM mvh_generalnotesbase WHERE mvh_address IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_perpetratoraddress AS 'PropertyID' FROM mvh_incidentreportbase WHERE mvh_perpetratoraddress IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_address AS 'PropertyID' FROM mvh_prospectivepropertybase WHERE mvh_address IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_propertyid AS 'PropertyID' FROM mvh_ptvbase WHERE mvh_propertyid IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_propertyid AS 'PropertyID' FROM mvh_signupvisitbase WHERE mvh_propertyid IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_property AS 'PropertyID' FROM mvh_verificationvisitbase WHERE mvh_property IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_property AS 'PropertyID' FROM mvh_viewingvisitbase WHERE mvh_property IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_propertyid AS 'PropertyID' FROM mvh_voidhistorybase WHERE mvh_propertyid IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_address AS 'PropertyID' FROM mvh_warningbase WHERE mvh_address IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT new_property_detail AS 'PropertyID' FROM mvh_warningbase WHERE new_property_detail IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
) 

-- 11,382 property records, of which 6,346 are not linked to a tenancy, so the remaining 5,036 are linked.
-- All properties NOT linked to a tenancy
/*
SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE statecode = 0 AND statuscode = 1 AND mvh_propertiesid NOT IN 
	(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasicbase))
*/

-- 11,544 tenancy records linked to a property, of which 5,033 are distinct
-- SELECT DISTINCT a.mvh_propertyreference FROM mvh_propertiesbase a INNER JOIN mvh_tenancybasicbase b ON a.mvh_propertiesid = b.mvh_address WHERE a.statecode = 0 AND a.statuscode = 1 

-- Every property record duplicated, 2 of each - 11,382 property records, 5691 distinct property reference numbers
-- SELECT mvh_propertyreference,COUNT(*) AS 'countof' FROM mvh_propertiesbase WHERE statecode = 0 AND statuscode = 1 GROUP BY mvh_propertyreference HAVING COUNT(*) = 2 ORDER BY mvh_propertyreference
-- SELECT DISTINCT mvh_propertyreference FROM mvh_propertiesbase ORDER BY mvh_propertyreference
-- SELECT mvh_propertyreference FROM mvh_propertiesbase ORDER BY mvh_propertyreference

-- SELECT DISTINCT mvh_address FROM mvh_tenancybasicbase

-- Properties not linked to tenancy so made inactive, but potentially not duplicates
/*
SELECT mvh_propertyreference FROM (
SELECT mvh_propertyreference, COUNT(mvh_propertyreference) AS 'count'
FROM mvh_propertiesbase 
WHERE statecode = '1' AND statuscode = '2' 
GROUP BY mvh_propertyreference 
HAVING COUNT(mvh_propertyreference) > 1) AS a  
ORDER BY mvh_propertyreference
*/


/*
-- TESTING SQL

SELECT DISTINCT PropertyID FROM (
SELECT mvh_propertyid AS 'PropertyID' FROM mvh_advertisedpropertybase WHERE mvh_propertyid IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_address AS 'PropertyID' FROM mvh_prospectivepropertybase WHERE mvh_address IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_propertyid AS 'PropertyID' FROM mvh_ptvbase WHERE mvh_propertyid IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_propertyid AS 'PropertyID' FROM mvh_signupvisitbase WHERE mvh_propertyid IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_property AS 'PropertyID' FROM mvh_verificationvisitbase WHERE mvh_property IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )
UNION ALL
SELECT mvh_property AS 'PropertyID' FROM mvh_viewingvisitbase WHERE mvh_property IN (
	SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid NOT IN 
		(SELECT mvh_propertiesid FROM mvh_propertiesbase WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) )

) a

*/