﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Xrm.Sdk;

public partial class WordTemplate : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["template"] != null && Request.QueryString["regardingobjectid"] != null && Request.QueryString["regardingobjecttypename"] != null)
            {
                D365EntityHelper xrm = new D365EntityHelper("documenttemplate");               
                string templateid = xrm.EntityGUID("name", Request.QueryString["template"]);

                if (templateid != string.Empty)
                {
                    // Generate the word document from the template and attach it as a note 
                    xrm.GenerateWordTemplate(Request.QueryString["regardingobjecttypename"],
                        Request.QueryString["regardingobjectid"], 
                        templateid);

                    // Retrieve the document bytes from the note created above
                    StringBuilder xml = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\" count=\"1\">");
                    xml.Append("<entity name=\"annotation\">");
                    xml.Append("<attribute name=\"isdocument\" />");
                    xml.Append("<attribute name=\"filename\" />");
                    xml.Append("<attribute name=\"createdon\" />");
                    xml.Append("<attribute name=\"documentbody\" />");
                    xml.Append("<order attribute=\"createdon\" descending=\"true\" />");
                    xml.Append("<filter type=\"and\">");
                    xml.AppendFormat("<condition attribute=\"objectid\" operator=\"eq\" uitype=\"{0}\" value=\"{1}\" />", 
                        Request.QueryString["regardingobjecttypename"],
                        Request.QueryString["regardingobjectid"]);
                    xml.Append("<condition attribute=\"isdocument\" value=\"1\" operator=\"eq\"/>");
                    xml.Append("</filter>");
                    xml.Append("</entity>");
                    xml.Append("</fetch>");

                    if (xrm.FetchEntityCollection(xml.ToString()))
                    {
                        if (xrm.Results.Entities.Count > 0)
                        {
                            xrm.Retrieve(xrm.Results.Entities[0]);

                            Response.Expires = 0;
                            Response.Cache.SetNoStore();
                            Response.AppendHeader("Pragma", "no-cache");
                            // Response.ContentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                            Response.AppendHeader("Content-Transfer-Encoding", "binary");
                            Response.AddHeader("content-disposition", "attachment; filename=" + xrm.Value("filename"));

                            // Output the contents of the attachment
                            Response.BinaryWrite(Convert.FromBase64String(xrm.Value("documentbody")));

                            // Delete the annotation
                            xrm.Delete("annotation", xrm.Results.Entities[0].Id.ToString());

                            // Log that this document has been generated
                            CorrespondenceHistory hist = new CorrespondenceHistory();
                            hist.Create(Request.QueryString["template"], "2", Request.QueryString["regardingobjecttypename"], Request.QueryString["regardingobjectid"]);
                        }
                    }
                }
            }
        }
    }
}