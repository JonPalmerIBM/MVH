﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml;

public partial class Test_SSRS2PDF : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            // Generate XML indexing file


            // Set report parameters
            List<ReportParameter> parameters = new List<ReportParameter>();

            foreach (string s in Request.QueryString)
            {
                if (s.ToLower() != "reportname")
                    parameters.Add(new ReportParameter(s, Request.QueryString[s]));
            }

            // Generate PDF document
            try
            {
                rptCRM.ProcessingMode = ProcessingMode.Remote;
                ServerReport serverReport = rptCRM.ServerReport;

                serverReport.ReportServerUrl = new Uri(ConfigurationManager.AppSettings["swordfish.reportserverurl"]);
                serverReport.ReportPath = ConfigurationManager.AppSettings["swordfish.reportpath"];

                if (Request.QueryString["reportname"] != null)
                    serverReport.ReportPath += Request.QueryString["reportname"];

                rptCRM.ServerReport.SetParameters(parameters);

                // Output PDF to browser
                Warning[] warnings;
                string[] streamids;
                string mimeType, encoding, extension, deviceInfo;

                deviceInfo = "True";

                byte[] bytes = rptCRM.ServerReport.Render("PDF", null, out mimeType, out encoding, out extension, out streamids, out warnings);

                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = mimeType;
                Response.AddHeader("content-disposition", "inline; filename=myfile." + extension);
                Response.BinaryWrite(bytes);
                Response.Flush();
                Response.End();
            }
            catch
            {

            }
        }  
    }
}