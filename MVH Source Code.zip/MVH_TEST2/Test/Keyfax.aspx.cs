﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Test_Keyfax : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        returnUrl.Value = Request.Url.OriginalString.Replace("Test/Keyfax", "Keyfax_Results");
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //Content.Controls.Add(new LiteralControl("[" + Request.Url.Query + "]"));
        //Content.Controls.Add(new LiteralControl("[" + Request.Url.OriginalString + "]"));

        KeyfaxResults results = new KeyfaxResults();

        results.ResultsNVC.Add("RepairCode", "000000");

        Content.Controls.Add(new LiteralControl(string.Format("<p>{0}</p>", results.Result("RepairCode"))));

        results.CreateRepair("DC40DB98-D4E4-E611-80E0-005056BD45EB");

        Content.Controls.Add(new LiteralControl(string.Format("<p>{0}</p>", results.Message)));
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        // Yes = 1
        // Content.Controls.Add(new LiteralControl("[" + returnUrl.Value.Replace("{0}", "1") + "]"));

        Response.Redirect(returnUrl.Value.Replace("{0}", "1"));
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        // No = 2
        // Content.Controls.Add(new LiteralControl("[" + returnUrl.Value.Replace("{0}", "2") + "]"));

        Response.Redirect(returnUrl.Value.Replace("{0}", "2"));
    }
}