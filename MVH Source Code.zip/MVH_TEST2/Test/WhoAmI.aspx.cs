﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Test_WhoAmI : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write(string.Format("User.Identity.Name [{0}]<br/>", User.Identity.Name));

        D365EntityHelper xrm = new D365EntityHelper();

        if (xrm.WhoAmI())
        {
            Response.Write(string.Format("WhoAmIRequest [{0}]", xrm.Value("domainname")));
        }
    }
}