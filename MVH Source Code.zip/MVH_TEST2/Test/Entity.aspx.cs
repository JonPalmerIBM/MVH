﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Crm.Sdk.Messages;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Xml;

public partial class Test_Test : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    private void DoSomething()
    {
        StringBuilder results = new StringBuilder(string.Empty);
        D365EntityHelper xrm = new D365EntityHelper(entity.Text);

        if (xrm.Retrieve(id.Text, fields.Text))
        {
            foreach (D365AttributeHelper attr in xrm.Attributes)
            {
                results.AppendFormat("{0} = [{1}] [{2}]</br>", attr.Name, attr.Value, attr.FormattedValue);
            }
        }
        else
        {
            results.AppendFormat("Error: {0}", xrm.Message);
        }

        Results.Text = results.ToString();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        DoSomething();
    }
}