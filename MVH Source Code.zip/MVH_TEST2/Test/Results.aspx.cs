﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Test_Results : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string xml = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><KeyfaxData><Fault name=\"Fault1\" type=\"RD\"><Job_Code /><Repair name=\"Repair1\"><RepairCode>325117</RepairCode></Repair></Fault><GUID>560CBE80-8523-4B02-AF6FE574E2238F79</GUID><Status>1</Status></KeyfaxData>";

        KeyfaxResults results = new KeyfaxResults(xml);

        Response.Write(results.Cancelled ? "Cancelled" : "Submitted");
        Response.Write("<br/>" + results.RepairNumber);
    }
}