﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CRM : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SwordfishMetadata smd = new SwordfishMetadata(Request.QueryString["reportname"], Request.QueryString);

        Content.Controls.Add(new LiteralControl(string.Format("<h2>[{0}]</h2>", Request.QueryString["reportname"])));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0} / {1} / {2}]</p>", smd.LetCat, smd.LetSubCat, smd.DocumentDescription)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.Reference)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.Initial)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.Surname)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.HouseNumber)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.AddressLine1)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.AddressLine2)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.Postcode)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.DOB)));

        return;

        smd.mvh_reference = "mvh_biddingno";
        smd.mvh_initial = "nickname";
        smd.mvh_surname = "lastname";
        smd.mvh_housenumber = "mvh_personcontactcode";
        smd.mvh_addressline1 = "address1_line1";
        smd.mvh_addressline2 = "address1_line2";
        smd.mvh_postcode = "address1_postalcode";
        smd.mvh_dob = "birthdate";

        smd.Query = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">"
             + "<entity name=\"contact\">"
             + "<attribute name=\"fullname\" />"
             + "<attribute name=\"telephone1\" />"
             + "<attribute name=\"contactid\" />"
             + "<attribute name=\"lastname\" />"
             + "<attribute name=\"nickname\" />"
             + "<attribute name=\"optevia_housingreference\" />"
             + "<attribute name=\"birthdate\" />"
             + "<attribute name=\"address1_postalcode\" />"
             + "<attribute name=\"address1_line2\" />"
             + "<attribute name=\"address1_line1\" />"
             + "<attribute name=\"mvh_biddingno\" />"
             + "<attribute name=\"mvh_personcontactcode\" />"
             + "<order attribute=\"fullname\" descending=\"false\" />"
             + "<filter type=\"and\">"
             + "<condition attribute=\"mvh_biddingno\" operator=\"eq\" value=\"{queryparam1}\" />"
             + "</filter>"
             + "</entity>"
             + "</fetch>";

        // smd.Query = @"<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false"><entity name="contact"><attribute name="fullname" /><attribute name="telephone1" /><attribute name="contactid" /><attribute name="lastname" /><attribute name="nickname" /><attribute name="optevia_housingreference" /><attribute name="birthdate" /><attribute name="address1_postalcode" /><attribute name="address1_line2" /><attribute name="address1_line1" /><attribute name="mvh_biddingno" /><attribute name="mvh_personcontactcode" /><order attribute="fullname" descending="false" /><filter type="and"><condition attribute="mvh_biddingno" operator="eq" value="JP-0-01-001-0001" /></filter></entity></fetch>";

        // Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.Query)));

        smd.ProcessFetchXMLPlaceholders(Request.QueryString);
        smd.ProcessFetchXML();

        // Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.FetchXML)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.Reference)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.Initial)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.Surname)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.HouseNumber)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.AddressLine1)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.AddressLine2)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.Postcode)));
        Content.Controls.Add(new LiteralControl(string.Format("<p>[{0}]</p>", smd.PersonContact.DOB)));



        return;

        Content.Controls.Add(new LiteralControl(DateTime.Now.ToShortDateString() + "<br/>"));

        D365EntityHelper xrm = new D365EntityHelper("contact", "MVH");

        xrm.Url = "http://MVHCRMDEV/";

        if (xrm.Retrieve("398A82B9-BA50-E511-80D7-005056BD15ED", "fullname"))
        {
            Content.Controls.Add(new LiteralControl("Name " + xrm.Value("fullname")));
        }
        else
        {
            Content.Controls.Add(new LiteralControl("Error " + xrm.Message));
        }

        D365EntityHelper crm = new D365EntityHelper("task");
        crm.Url = "http://MVHCRMDEV/";
        crm.AddLookup("regardingobjectid", "contact", "398A82B9-BA50-E511-80D7-005056BD15ED");
        crm.AddString("subject", DateTime.Now.ToLongTimeString());
        crm.AddDateTime("scheduledend", DateTime.Now);
        if (crm.Create())
            crm.AttachNote("Swordfish XML", "SOME XML");
        else
            Content.Controls.Add(new LiteralControl("ERROR: " + crm.Message));




        //XRM crm = new XRM("task");
        //crm.service.AddLookup("regardingobjectid", "contact", "398A82B9-BA50-E511-80D7-005056BD15ED");
        //crm.service.AddString("subject", DateTime.Now.ToLongTimeString());
        //crm.service.AddDateTime("scheduledend", DateTime.Now);
        //if (crm.service.Create())
        //    crm.service.AttachNote("Swordfish XML", "SOME XML");
        //else
        //    Content.Controls.Add(new LiteralControl("ERROR: " + crm.service.Message));


    }
}