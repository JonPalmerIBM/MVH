﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Test_PropertiesDeDupe : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        XRM xrm;
        string sql = @"SELECT mvh_propertiesid, mvh_propertyreference, mvh_name FROM mvh_properties WHERE mvh_propertiesid NOT IN (SELECT mvh_propertiesid FROM mvh_properties WHERE mvh_propertiesid IN (SELECT mvh_address FROM mvh_tenancybasic)) ORDER BY mvh_name";

        // DataSet properties = SqlServerHelper.ExecuteQuery("Data Source=mvhcrmdev;Initial Catalog=devDB;Integrated Security=SSPI", sql);
        DataSet properties = SqlServerHelper.ExecuteQuery("Data Source=mvhcrm1-db;Initial Catalog=MVH_MSCRM;Integrated Security=SSPI", sql);

        Content.Controls.Add(new LiteralControl("<ol>"));

        foreach (DataRow dr in properties.Tables[0].Rows)
        {
            Content.Controls.Add(new LiteralControl("<li>" + Convert.ToString(dr[1]) + " | " + Convert.ToString(dr[2]) + "</li>"));
            xrm = new XRM("mvh_properties", "MVH");
            xrm.d365.Url = "http://mvhcrm1-db/";
            xrm.service.schema.Id = new Guid(Convert.ToString(dr[0]));
            xrm.service.SetState("1", "2");
        }

        Content.Controls.Add(new LiteralControl("</ol>"));
    }
}