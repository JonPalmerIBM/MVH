﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CreateRepair : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        try { cancelurl.Value = Request.UrlReferrer.OriginalString; }
        catch { }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //XRM xrm = new XRM("contact", "MVH");

        //if (xrm.service.Retrieve("398A82B9-BA50-E511-80D7-005056BD15ED", "fullname"))
        //{
        //    Content.Controls.Add(new LiteralControl("Name " + xrm.service.Value("fullname")));
        //}
        //else
        //{
        //    Content.Controls.Add(new LiteralControl("Error " + xrm.service.Message));
        //}
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        XRM xrm = new XRM("contact", "MVH");

        xrm.service.AddString("firstname", "Jon");
        xrm.service.AddString("lastname", "Palmer." + DateTime.Now.ToLongTimeString());

        if (xrm.service.Create())
        {
            string redirect = "http://mvhcrmdev/mvh/main.aspx?etn=contact&pagetype=entityrecord&id=%7B" + xrm.service.schema.Id.ToString() + "%7D";

            // Response.Redirect("http://mvhcrmdev/mvh/main.aspx?etn=contact&pagetype=entityrecord&id=%7B" + xrm.service.schema.Id.ToString() + "%7D");

            // ClientScriptManager.RegisterClientScriptBlock(this.GetType(), "RedirectScript", "window.parent.location = 'http://yoursite.com'", true);

            // Response.Write("<script>top.location='" + redirect + "';parent.location='" + redirect + "';</script>");

            Response.Write("<script>parent.location='" + redirect + "';</script>");
        }
        else
        {
            Content.Controls.Add(new LiteralControl("Error " + xrm.service.Message));
        }

        // Response.Redirect("http://mvhcrmdev/mvh/main.aspx?etn=contact&pagetype=entityrecord&id=%7B398A82B9-BA50-E511-80D7-005056BD15ED%7D");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        // Content.Controls.Add(new LiteralControl(cancelurl.Value));

        // Response.Write("<script>parent.location='" + cancelurl.Value + "';</script>");

        Response.Redirect(cancelurl.Value);
    }
}