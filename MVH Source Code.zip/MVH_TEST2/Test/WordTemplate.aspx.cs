﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Xrm.Sdk;

public partial class Test_WordTemplate : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        D365EntityHelper xrm = new D365EntityHelper("documenttemplate");

        string templateid = xrm.EntityGUID("name", "Structural Alt - Declined");

        xrm.GenerateWordTemplate("incident", "9EE515AE-4F9C-E711-810C-005056BD092E", templateid); // "C6AFB416-61D3-E711-810E-005056BD092E");

        // Response.Write("[" + xrm.Message + "]<br/>");
        // Response.Write("[" + xrm.Response.Results.Count.ToString() + "]<br/>");

        StringBuilder xml = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\" count=\"1\">");
        xml.Append("<entity name=\"annotation\">");
        xml.Append("<attribute name=\"isdocument\" />");
        xml.Append("<attribute name=\"filename\" />");
        xml.Append("<attribute name=\"createdon\" />");
        xml.Append("<attribute name=\"documentbody\" />");
        xml.Append("<order attribute=\"createdon\" descending=\"true\" />");
        xml.Append("<filter type=\"and\">");
        xml.AppendFormat("<condition attribute=\"objectid\" operator=\"eq\" uitype=\"{0}\" value=\"{1}\" />", "incident", "{9EE515AE-4F9C-E711-810C-005056BD092E}");
        xml.Append("<condition attribute=\"isdocument\" value=\"1\" operator=\"eq\"/>");
        xml.Append("</filter>");
        xml.Append("</entity>");
        xml.Append("</fetch>");

        if (xrm.FetchEntityCollection(xml.ToString()))
        {
            // Response.Write("[" + xrm.Results.Entities.Count.ToString() + "]<br/>");

            if (xrm.Results.Entities.Count > 0)
            {
                xrm.Retrieve(xrm.Results.Entities[0]);

                Response.Expires = 0;
                Response.Cache.SetNoStore();
                Response.AppendHeader("Pragma", "no-cache");
                Response.ContentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                Response.AppendHeader("Content-Transfer-Encoding", "binary");
                Response.AddHeader("content-disposition", "attachment; filename=" + xrm.Value("filename"));

                // Output the contents of the attachment
                Response.BinaryWrite(Convert.FromBase64String(xrm.Value("documentbody")));

                // Delete the annotation
                xrm.Delete("annotation", xrm.Results.Entities[0].Id.ToString());

                // Create a task
                D365EntityHelper task = new D365EntityHelper("task");
                task.AddString("subject", "Word template generated - " + xrm.Value("filename"));
                task.AddLookup("regardingobjectid", "incident", "9EE515AE-4F9C-E711-810C-005056BD092E");
                task.Create();
            }

            return;

            //foreach (Entity ent in xrm.Results.Entities)
            //{
            //    xrm.Retrieve(ent);
            //    Response.Write("[" + xrm.Value("isdocument") + "]<br/>");
            //    Response.Write("[" + xrm.Value("filename") + "]<br/>");
            //    Response.Write("[" + xrm.Time("createdon") + "]<br/>");
            //    Response.Write("[" + xrm.Value("documentbody") + "]<br/>");
            //}

            // Convert.FromBase64String(this.Value("documentbody"));

        }



            //annotation["objectid"] = new EntityReference(Type, schema.Id);
            //annotation["objecttypecode"] = Type;
            //annotation["subject"] = "MySSSC document upload";
            //annotation["filename"] = filename;
            //annotation["mimetype"] = mimetype;
            //if (notetext != string.Empty)
            //    annotation["notetext"] = notetext;

            //// Encode the data using base64.
            //attachment.Read(byteData, 0, byteData.Length);
            //annotation["documentbody"] = System.Convert.ToBase64String(byteData);


    }
}