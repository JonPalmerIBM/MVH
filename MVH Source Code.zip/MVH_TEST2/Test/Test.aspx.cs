﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Crm.Sdk.Messages;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Xml;

public partial class Test_Test : System.Web.UI.Page
{
    private void DoSomething()
    {
        D365EntityHelper xrm = new D365EntityHelper("mvh_repairmodule");
        xrm.schema.Id = new Guid("93A323AD-4E42-E811-8147-005056BD54AF");

        D365EntityHelper user = new D365EntityHelper("systemuser");
        string assignee = user.EntityGUID("domainname", "MVHOMES\\tim.jones");

        if (assignee != string.Empty)
        {
            Response.Write(assignee);
            xrm.SetOwner(assignee); // ("f3d05da8-7bf7-e611-80e0-005056bd45eb");
        }
        else
        {
            Response.Write(user.Message);
        }
    }

    private void DoSomethingXXXXXX()
    {
        // Response.Write("[" + DateTime.Now.ToString("yyyy-MM-dd") + "]</br>");

        D365EntityHelper xrm = new D365EntityHelper("mvh_repairmodule"); // ("mvh_predefinedjob");

        xrm.AddPicklist("mvh_locationcostcode_", "76");
        // xrm.AddNull("mvh_locationcostcode_");
        // xrm.AddNull("mvh_locationcostcode");
        xrm.Update("93A323AD-4E42-E811-8147-005056BD54AF");

        Response.Write(string.Format("{0}</br>", xrm.Message));

        xrm.Retrieve("93A323AD-4E42-E811-8147-005056BD54AF"); // ("4241ED33-4821-E811-8141-005056BD54AF");

        foreach (D365AttributeHelper attr in xrm.Attributes)
        {
            Response.Write(string.Format("{0} = [{1}] [{2}]</br>", attr.Name, attr.Value, attr.FormattedValue));
        }
    }

    private void DoSomethingXXXXX()
    {
        XmlDocument doc = new XmlDocument();
        XmlNode node;
        XmlNodeList nodelist;

        doc.Load("C:\\Temp\\keyfaxsample.xml");

        string path = "/" + doc.DocumentElement.Name + "/";

        node = doc.SelectSingleNode(path + "Call/Service/ServiceCode");
        Response.Write(string.Format("[{0}]</br>", node != null ? node.InnerText : "not found"));

        node = doc.SelectSingleNode(path + "Call/ScriptPath/Question");
        Response.Write(string.Format("[{0}]</br>", node != null ? node.InnerText : "not found"));

        nodelist = doc.SelectNodes(path + "Call/ScriptPath/Question");
        Response.Write(string.Format("[{0}]</br>", nodelist != null ? nodelist.Count.ToString() : "node list empty"));

        foreach (XmlNode n in nodelist)
        {
            Response.Write(string.Format("[{0}]</br>", n != null ? n.InnerText : "not found"));
        }
    }

    private void DoSomethingXXXX()
    {
        // Response.Write(DateTime.Now.ToString("hh:mm"));
        // Response.Write(DateTime.Now.ToString("HH:mm"));

        D365EntityHelper xrm = new D365EntityHelper("mvh_sor");

        string id = xrm.EntityGUID("mvh_name", "325117");

        Response.Write(xrm.Message + "<br/>");
        Response.Write(id + "<br/>");

        D365EntityHelper mvh_sor = new D365EntityHelper("mvh_sor");

        mvh_sor.Retrieve(id);

        Response.Write(mvh_sor.Value("mvh_description") + "<br/>");
        Response.Write(mvh_sor.Value("mvh_value") + "<br/>");
    }

    private void DoSomethingXXX()
    {
        ClientCredentials creds = new ClientCredentials();

        // creds.Windows.ClientCredential = new System.Net.NetworkCredential("jon.palmer", "2BMpassword", "MVHOMES");

        creds.Windows.ClientCredential = System.Net.CredentialCache.DefaultNetworkCredentials;

        Response.Write(creds.IssuedToken.ToString());

        {
            // creds.Windows.ClientCredential = (System.Net.NetworkCredential)System.Net.CredentialCache.DefaultCredentials;

            // creds.Windows.ClientCredential = (System.Net.NetworkCredential)System.Net.CredentialCache.DefaultCredentials;
            // return creds.Windows.ClientCredential = (ClientCredentials)System.Net.CredentialCache.DefaultCredentials;

            // creds.UserName.UserName = Username;
            // creds.UserName.Password = Password;
        }



        // return;

        Response.Write("[" + User.Identity.Name + "]");


        D365EntityHelper xrm = new D365EntityHelper("account");

        string id = "15B80504-1ECA-E711-810E-005056BD092E";

        xrm.Retrieve(id, "name");

        Response.Write(xrm.Value("name"));

        //Response.Write(xrm.WhoAmI().ToString());

        //Response.Write(xrm.Value("domainname"));

        Response.Write("<br/>");

        StringBuilder xml = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">"); // count=\"1\">");
        xml.Append("<entity name=\"mvh_targetdatepriority\">");
        xml.Append("<attribute name=\"mvh_targetdatepriorityid\" />");
        xml.Append("<attribute name=\"mvh_name\" />");
        xml.Append("<attribute name=\"createdon\" />");
        xml.Append("<order attribute=\"mvh_name\" descending=\"false\" />");
        xml.Append("<filter type=\"and\">");
        xml.Append("<condition attribute=\"mvh_days\" operator=\"eq\" value=\"17\" />");
        xml.Append("</filter>");
        xml.Append("<link-entity name=\"account\" from=\"accountid\" to=\"mvh_accountid\" alias=\"aa\">");
        xml.Append("<attribute name=\"accountnumber\" />");
        xml.Append("</link-entity>");
        xml.Append("</entity>");
        xml.Append("</fetch>");

        if (xrm.FetchEntityCollection(xml.ToString()))
        {
            Response.Write(xrm.Results.Entities.Count.ToString());
            xrm.Retrieve(xrm.Results.Entities[0]);
            Response.Write(xrm.Value("aa.accountnumber"));
        }
        else
        {
            Response.Write(xrm.Message);
        }
    
    
    
    }

    private void DoSomethingXX()
    {
        D365EntityHelper repair = new D365EntityHelper("mvh_repairmodule");

        repair.Retrieve("8C39301C-62D3-E711-810E-005056BD092E");

        //foreach (D365AttributeHelper attr in repair.Attributes)
        //{
        //    Response.Write(string.Format("[{0}] [{1}] [{2}]<br/>", 
        //        attr.Name, attr.Value, attr.FormattedValue));
        //}

        //Response.Write("<h2>" + repair.schema.Id.ToString() + "</h2>");

        //foreach (string key in repair.schema.Attributes.Keys)
        //{
        //    Response.Write(string.Format("[{0}] ",
        //        key));
        //}

        repair.Clone("mvh_name,mvh_predefinedjobid");
        
        if (repair.CreateClone())
        {
            Response.Write("<h5>" + repair.Message + "</h5>");
            Response.Write("<h2>" + repair.clone.Id.ToString() + "</h2>");

            repair.InitialiseSchema();
            repair.AddString("mvh_name", "020202");
            repair.Update(repair.clone.Id.ToString());
        }

        //clone.schema.Attributes.Remove("mvh_repairmoduleid");
        //clone.schema.Attributes.Remove("mvh_name");
        //clone.AddString("mvh_name", "020202");

        // clone.Clone();

        //Response.Write("<h5>" + repair.Message + "</h5>");
        //Response.Write("<h2>" + repair.schema.Id.ToString() + "</h2>");
    }

    private void DoSomethingX()
    {
        D365EntityHelper bcal = new D365EntityHelper("calendar");

        DateTime mvh_currenttargetdate = DateTime.Today.AddDays(24);

        mvh_currenttargetdate = bcal.NextAvailableDate(mvh_currenttargetdate, false);

        Response.Write("[" + mvh_currenttargetdate.ToString("dd/MM/yyyy") + "]");
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        DoSomething();
        return;

        // string id = "70D31042-D5E3-E611-80DE-005056BD45EB";
        D365EntityHelper bcc = new D365EntityHelper("calendarrule");
        D365EntityHelper bcal = new D365EntityHelper("calendar");

        string id = bcal.EntityGUID("name", "Business Closure Calendar");

        Response.Write("<h2>" + id + "</h2>");

        string cal = bcc.FetchBusinessClosureCalendar(id);

        DateTime mvh_currenttargetdate = DateTime.Today.AddDays(19);

        if (mvh_currenttargetdate.DayOfWeek == DayOfWeek.Saturday)
            mvh_currenttargetdate = mvh_currenttargetdate.AddDays(2);

        if (mvh_currenttargetdate.DayOfWeek == DayOfWeek.Sunday)
            mvh_currenttargetdate = mvh_currenttargetdate.AddDays(1);

        while (cal.Contains(mvh_currenttargetdate.ToString("dd/MM/yyyy")))
        {
            mvh_currenttargetdate = mvh_currenttargetdate.AddDays(1);
        }

        Response.Write(cal);

        Response.Write("[" + mvh_currenttargetdate.ToString("dd/MM/yyyy") + "]");

        return;

        IOrganizationService service = bcc.ConnectToService();

        QueryExpression q = new QueryExpression("calendar");
        q.ColumnSet = new ColumnSet(true);
        q.Criteria = new FilterExpression();
        q.Criteria.AddCondition(new ConditionExpression("calendarid", ConditionOperator.Equal, "70D31042-D5E3-E611-80DE-005056BD45EB"));
        Entity businessClosureCalendar = service.RetrieveMultiple(q).Entities[0];
        if (businessClosureCalendar != null)
        {
            foreach (Entity ent in businessClosureCalendar.GetAttributeValue<EntityCollection>("calendarrules").Entities)
            {
                bcc.Retrieve(ent);
                Response.Write("[" + bcc.Value("effectiveintervalstart") + "] ");
            }
            // return businessClosureCalendar.GetAttributeValue<EntityCollection>("calendarrules").Entities;
        }

        return;

        ExpandCalendarRequest req = new ExpandCalendarRequest();
        req.CalendarId = new Guid("70D31042-D5E3-E611-80DE-005056BD45EB");
        req.Start = DateTime.Now;
        req.End = DateTime.Now.AddDays(5);

        ExpandCalendarResponse resp = (ExpandCalendarResponse)service.Execute(req);

        Response.Write("Done.");

        return;

        // ExpandCalendarRequest 

        StringBuilder xml = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\""); // count=\"1\">");

        xml.Append("<entity name=\"CalendarRule\">");
        xml.Append("<attribute name=\"Name\" />");
        xml.Append("<attribute name=\"CalendarRuleId\" />");
        xml.Append("<filter type=\"and\">");
        // xml.AppendFormat("<condition attribute=\"mvh_priority\" operator=\"eq\" value=\"[0}\" />", priority);
        xml.AppendFormat("<condition attribute=\"CalendarId\" operator=\"eq\" uitype=\"Calendar\" value=\"{0}\" />", "70D31042-D5E3-E611-80DE-005056BD45EB");
        xml.Append("</filter>");
        xml.Append("</entity>");
        xml.Append("</fetch>");

        if (bcc.FetchEntityCollection(xml.ToString()))
        {
            Response.Write(bcc.Results.Entities.Count.ToString());
        }
        else
        {
            Response.Write(bcc.Message);
        }

        return; 

        Response.Write(string.Format("[{0}]</br>", DateTime.Now.ToString("dd/MM/yyyy")));
        Response.Write(string.Format("[{0}]</br>", DateTime.Now.ToString("hh:mm")));
        Response.Write(string.Format("[{0}]</br>", DateTime.Now.ToString("dd-MMM-yyyy hh:mm").ToUpper()));

        string x = "Merthyr Valleys Homes";
        Response.Write(string.Format("[{1}{0}]</br>", x.Substring(0, x.Length > 250 ? 250 : x.Length), "2nd Param!"));
    }
}