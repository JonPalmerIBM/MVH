﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Xml;

public class KeyfaxResults
{
    public NameValueCollection ResultsNVC = new NameValueCollection();
    public XmlDocument ResultsXML = new XmlDocument();
    public string XML = string.Empty;
    public string Message = string.Empty;
    public string OwnerId = string.Empty;

    public KeyfaxResults()
    {

    }

    public KeyfaxResults(string results)
	{
        XML = results;

        try
        {
            ResultsXML.LoadXml(XML);

            AddKey("Status");
            AddKey("Call/Service/ServiceCode");
            AddKey("Call/Service/ServiceCodeDesc");
            AddKey("Call/Service/Priority");
            AddKey("Call/CategoryText");
            AddKey("Call/TopicText");

            XmlNodeList nodelist = ResultsXML.SelectNodes("/" + ResultsXML.DocumentElement.Name + "/Call/ScriptPath/Question");
            string scriptpath = string.Empty;

            foreach (XmlNode node in nodelist)
            {
                if (node != null)
                {
                    scriptpath += node.InnerText + "\n";
                }
            }

            ResultsNVC.Add("ScriptPath", scriptpath);
        }
        catch
        {

        }
    }

    public string Result(string key)
    {
        if (ResultsNVC[key] == null)
            return string.Empty;
        else
            return ResultsNVC[key];
    }

    public bool Cancelled
    {
        get
        {
            if (this.Result("Status") == "1")
                return false;
            else
                return true;
        }
    }

    public string PredefinedJobNumber
    {
        get
        {
            return this.Result("ServiceCode");
            // return this.Result("RepairCode");
        }
    }

    public string Priority
    {
        get
        {
            return this.Result("Priority");
        }
    }

    public string MappedPriority(string priority)
    {
        string key = string.Format("keyfax.priority.{0}", priority);

        return ConfigurationManager.AppSettings[key] != null ? ConfigurationManager.AppSettings[key] : string.Empty;
    }

    // Create a repair linked to a property, based on the predefined job number returned by Keyfax.
    // A plug in handler will take care of the rest.
    public string CreateRepair(string mvh_propertyid)
    {
        if (this.PredefinedJobNumber != string.Empty)
        {
            D365EntityHelper mvh_repair = new D365EntityHelper("mvh_repairmodule");
            D365EntityHelper mvh_predefinedjob = new D365EntityHelper("mvh_predefinedjob");
            string mvh_predefinedjobid = mvh_predefinedjob.EntityGUID("mvh_name", this.PredefinedJobNumber);

            if (mvh_predefinedjobid != string.Empty)
            {
                mvh_repair.AddLookup("mvh_propertyid", "mvh_properties", mvh_propertyid);
                // mvh_repair.AddString("mvh_description", this.Result("ServiceCodeDesc"), 100);
                mvh_repair.AddString("mvh_description", this.Result("CategoryText") + ": " + this.Result("TopicText"), 100);
                mvh_repair.AddString("mvh_scriptpath", this.Result("ScriptPath"));
                mvh_repair.AddBoolean("mvh_scheme", false);
                mvh_repair.AddLookup("mvh_predefinedjobid", "mvh_predefinedjob", mvh_predefinedjobid);
                mvh_repair.AddDateTime("mvh_createdon", DateTime.Now);
                string priority = this.MappedPriority(this.Priority);
                if (priority != string.Empty)
                    mvh_repair.AddPicklist("mvh_priority", priority);
                if (mvh_repair.Create())
                {
                    // Set owner
                    if (OwnerId != string.Empty)
                    {
                        mvh_repair.SetOwner(OwnerId);
                    }

                    // Repair created ok, different priority?
                    string id = mvh_repair.schema.Id.ToString();
                    if (priority != string.Empty)
                    {
                        //mvh_repair.InitialiseSchema();
                        //mvh_repair.AddPicklist("mvh_priority", priority);
                        //mvh_repair.Update(id);
                    }
                    return mvh_repair.schema.Id.ToString();
                }
                else
                {
                    // Error creating repair
                    Message = string.Format("Error creating repair: {0}", mvh_repair.Message);
                    return string.Empty;
                }
            }
            else
            {
                // Could not find predefined job number
                Message = string.Format("Could not find predefined job number {0}. {1}", this.PredefinedJobNumber, mvh_predefinedjob.Message);
                return string.Empty;
            }
        }
        else
        {
            // No repair code returned from Keyfax
            Message = "No repair code returned from Keyfax.";
            return string.Empty;
        }
    }

    private void AddKey(string path)
    {
        path = "/" + ResultsXML.DocumentElement.Name + "/" + path;

        XmlNode node = ResultsXML.SelectSingleNode(path);

        if (node != null)
        {
            ResultsNVC.Add(path.Substring(path.LastIndexOf("/") + 1), node.InnerText);
        }
        else
        {
            ResultsNVC.Add(path.Substring(path.LastIndexOf("/") + 1), string.Empty);
        }
    }
}