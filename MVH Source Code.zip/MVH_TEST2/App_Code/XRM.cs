﻿using System;

public class XRM
{
    public D365EntityHelper d365;

    public XRM(string type)
    {
        d365 = new D365EntityHelper(type);
    }

	public XRM(string type, string org)
	{
        d365 = new D365EntityHelper(type, org);
	}

    public D365EntityHelper service
    {
        get
        {
            return d365;
        }
    }
}