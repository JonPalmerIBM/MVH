﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Xml;

public class CorrespondenceHistory
{
    public CorrespondenceHistory()
    {

    }

    public void Create(string name, string producedas, string regardingobjecttypename, string regardingobjectid)
    {
        string category = string.Format("wordtemplate.{0}.category", regardingobjecttypename);
        string regarding = string.Format("wordtemplate.{0}.regarding", regardingobjecttypename);

        int index = 1;
        string associatedcols = string.Empty;
        NameValueCollection associated = new NameValueCollection();

        while (true)
        {
            string key = string.Format("wordtemplate.{1}.associated{0}", index.ToString(), regardingobjecttypename);
            if (ConfigurationManager.AppSettings[key] != null)
            {
                string[] fields = ConfigurationManager.AppSettings[key].Replace(" ", string.Empty).Split('=');
                if (fields.Length == 2)
                {
                    associated.Add(fields[0], fields[1]);
                    associatedcols += (index > 1 ? "," : string.Empty) + fields[1];
                }
                index++;
            }
            else
            {
                break;
            }
        }

        if (ConfigurationManager.AppSettings[regarding] != null)
        {
            D365EntityHelper regardingobject = new D365EntityHelper(regardingobjecttypename);
            D365EntityHelper history = new D365EntityHelper("mvh_correspondencehistory");

            history.AddString("mvh_name", name, 100);
            history.AddString("mvh_category", ConfigurationManager.AppSettings[category]);
            history.AddPicklist("mvh_producedas", producedas);
            history.AddLookup(ConfigurationManager.AppSettings[regarding], regardingobjecttypename, regardingobjectid);

            if (associated.Count > 0)
            {
                if (regardingobject.Retrieve(regardingobjectid, associatedcols))
                {
                    foreach (string s in associated)
                    {
                        string[] logicalnames = s.Split('.');
                        if (logicalnames.Length == 2)
                        {
                            history.AddLookup(logicalnames[1], logicalnames[0], regardingobject.Value(associated[s]));
                        }
                    }
                }
            }

            history.Create();
        }
    }
}

public class SwordfishPersonContact
{
    public string Reference = string.Empty;
    public string Initial = string.Empty;
    public string Surname = string.Empty;
    public string HouseNumber = string.Empty;
    public string AddressLine1 = string.Empty;
    public string AddressLine2 = string.Empty;
    public string Postcode = string.Empty;
    public string DOB = string.Empty;

    public SwordfishPersonContact()
	{
	}

    public SwordfishPersonContact(string id)
    {
        Retrieve(id);
    }

    public SwordfishPersonContact(string regardingobjecttypename, string regardingobjectid)
    {
        Retrieve(DetermineContactId(regardingobjecttypename, regardingobjectid));
    }

    // Populate contact fields
    public void Retrieve(string id)
    {
        if (id != string.Empty)
        {

        }

    }

    // Work out the contact id and set the Reference
    public string DetermineContactId(string regardingobjecttypename, string regardingobjectid)
    {
        string id = string.Empty;





        return id;
    }
}

public class SwordfishMetadata
{
    public string LetCat = string.Empty;
    public string LetSubCat = string.Empty;
    public string DocumentDescription = string.Empty;
    public string Query = string.Empty;
    public string FetchXML = string.Empty;

    public SwordfishPersonContact PersonContact = new SwordfishPersonContact();

    public string mvh_reference = string.Empty;
    public string mvh_initial = string.Empty;
    public string mvh_surname = string.Empty;
    public string mvh_housenumber = string.Empty;
    public string mvh_addressline1 = string.Empty;
    public string mvh_addressline2 = string.Empty;
    public string mvh_postcode = string.Empty;
    public string mvh_dob = string.Empty;

    public SwordfishMetadata(string filename, NameValueCollection nvc)
    {
        XRM xrm = new XRM("mvh_swordfishmetadata");

        if (xrm.service.Retrieve(xrm.service.EntityGUID("mvh_name", filename)))
        {
            LetCat = xrm.service.Value("mvh_letcat");
            LetSubCat = xrm.service.Value("mvh_letsubcat");
            DocumentDescription = xrm.service.Value("mvh_description");
            Query = xrm.service.Value("mvh_query");
            mvh_reference = xrm.service.Value("mvh_reference");
            mvh_initial = xrm.service.Value("mvh_initial");
            mvh_surname = xrm.service.Value("mvh_surname");
            mvh_housenumber = xrm.service.Value("mvh_housenumber");
            mvh_addressline1 = xrm.service.Value("mvh_addressline1");
            mvh_addressline2 = xrm.service.Value("mvh_addressline2");
            mvh_postcode = xrm.service.Value("mvh_postcode");
            mvh_dob = xrm.service.Value("mvh_dob");
        }

        if (Query != string.Empty)
        {
            this.ProcessFetchXMLPlaceholders(nvc);
            this.ProcessFetchXML();
        }
    }

    public void ProcessFetchXMLPlaceholders(NameValueCollection nvc)
    {
        FetchXML = Query;

        foreach (string s in nvc)
            FetchXML = FetchXML.Replace("{" + s + "}", nvc[s]);
    }

    public void ProcessFetchXML()
    {
        XRM xrm = new XRM("mvh_swordfishmetadata");

        if (xrm.service.FetchEntityCollection(FetchXML))
        {
            if (xrm.service.Results.Entities.Count > 0)
            {
                xrm.service.Retrieve(xrm.service.Results[0]);
                PersonContact.Reference = xrm.service.Value(mvh_reference);
                PersonContact.Initial = xrm.service.Value(mvh_initial);
                PersonContact.Surname = xrm.service.Value(mvh_surname);
                PersonContact.HouseNumber = xrm.service.Value(mvh_housenumber);
                PersonContact.AddressLine1 = xrm.service.Value(mvh_addressline1);
                PersonContact.AddressLine2 = xrm.service.Value(mvh_addressline2);
                PersonContact.Postcode = xrm.service.Value(mvh_postcode);
                PersonContact.DOB = xrm.service.Value(mvh_dob);
            }
        }
    }
}