﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using ServiceReference1;

public partial class Keyfax_Results : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request["propertyid"] != null && Request["id"] != null && Request["entityname"] != null && Request["status"] != null && Request["guid"] != null)
        {
            KeyfaxWSSoapClient keyfax = new KeyfaxWSSoapClient();
            StringBuilder redirectUrl = new StringBuilder(string.Empty);
            KeyfaxResults results = new KeyfaxResults(keyfax.GetResults(ConfigurationManager.AppSettings["keyfax.company"], Request["guid"]).ResultXml);

            if (Request["ownerid"] != null)
            {
                results.OwnerId = Request["ownerid"];
            }

            if (!results.Cancelled)
            {
                string mvh_repairid = results.CreateRepair(Request["propertyid"]);

                if (mvh_repairid != string.Empty)
                {
                    // Repair created successfully
                    redirectUrl.AppendFormat("{0}?etn={1}&pagetype=entityrecord&id={2}",
                        ConfigurationManager.AppSettings["keyfax.redirecturl"], "mvh_repairmodule", mvh_repairid);
                }
                else
                {
                    Content.Controls.Add(new LiteralControl(string.Format("<p>Error: {0}</p>", results.Message)));
                    Ok.Visible = true;
                }
            }

            if (redirectUrl.ToString() == string.Empty)
            {
                // User cancelled Keyfax diagnostic tool or problem creating repair, return to property record
                redirectUrl.AppendFormat("{0}?etn={1}&pagetype=entityrecord&id={2}",
                    ConfigurationManager.AppSettings["keyfax.redirecturl"], Request["entityname"], Request["id"]);
            }

            // Depending on result, return to property record or display new repair, or show an error message
            if (!Ok.Visible)
            {
                Response.Write("<script>top.location='" + redirectUrl.ToString() + "';parent.location='" + redirectUrl.ToString() + "';</script>");
            }
        }
        else
        {
            // Error, querystring should contain correct parameters
            Content.Controls.Add(new LiteralControl("Incorrect number of parameters in " + Request.Url.OriginalString));
        }
    }

    protected void Ok_Click(object sender, EventArgs e)
    {
        Response.Write(string.Format("<script>top.location='{0}';parent.location='{0}';</script>",
            string.Format("{0}?etn={1}&pagetype=entityrecord&id={2}",
            ConfigurationManager.AppSettings["keyfax.redirecturl"], Request["entityname"], Request["id"])));
    }
}