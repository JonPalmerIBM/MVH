﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_TextLocal_PlugInAssembly
{
    public class Handler_SendSMS : IPlugin
    {
        // Demo API key = "9VGaoGAujZw-thApdxt5wursgCvnwm4efGYnd2VzLk"
        // MVH API key = "Sv1uEfnwHEY-yIR7Ly383x9g75NttmtsmGLysmHZi4"

        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_SendSMS()
        {
        }

        public Handler_SendSMS(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_SendSMS(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth == 1 || context.Depth == 2)
            {
                bool send = false;
                string number = string.Empty;
                string message = string.Empty;

                primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_number,mvh_message,mvh_send,regardingobjectid,mvh_predefinedsmsid");

                switch (context.MessageName.ToLower())
                {
                    case "create":
                    case "update":
                        send = primaryentity.BooleanValue("mvh_send");
                        number = primaryentity.Value("mvh_number");
                        message = primaryentity.Value("mvh_message");
                        break;
                }

                // Only send message if the Send? box is ticked
                if (send)
                {
                    if (message == string.Empty && primaryentity.Value("mvh_predefinedsmsid") != string.Empty)
                    {
                        // Message is blank, but there is a predefined SMS ID
                        XRMHelper mvh_predefinedsms = new XRMHelper(service, "mvh_predefinedsms");
                        if (mvh_predefinedsms.Retrieve(primaryentity.Value("mvh_predefinedsmsid"), "mvh_message"))
                            message = mvh_predefinedsms.Value("mvh_message");
                    }

                    string actual_number = SMSNumber(number, primaryentity.Value("regardingobjectid"), primaryentity.LookupType("regardingobjectid"), service);
                    string actual_message = ProcessMessagePlaceholders(message, primaryentity.Value("regardingobjectid"), primaryentity.LookupType("regardingobjectid"), service);

                    // If testrecipient contains a value, use a test number when the number is derived from the Regarding field
                    if (config["testrecipient"] != null)
                    {
                        if (config["testrecipient"] != string.Empty && number == string.Empty)
                        {
                            actual_number = config["testrecipient"];
                        }
                    }

                    if (SendSMS(config["apikey"], actual_number, actual_message))
                    {
                        // Update activity
                        primaryentity.InitialiseSchema();
                        primaryentity.AddDateTime("mvh_datesent", DateTime.Now);
                        primaryentity.AddString("mvh_message", message);
                        primaryentity.Update(context.PrimaryEntityId.ToString());
                    }
                }
            }
        }

        private bool SendSMS(string apikey, string number, string message)
        {
            if (number == string.Empty || message == string.Empty)
                return false;

            try
            {
                using (var wb = new System.Net.WebClient())
                {
                    byte[] response = wb.UploadValues("http://api.txtlocal.com/send/", new NameValueCollection()
                    {
                        {"apikey" , apikey},
                        {"numbers" , number},
                        {"message" , System.Web.HttpUtility.UrlEncode(message)},
                    });

                    // Record the API response against the SMS activity
                    primaryentity.AttachNote("Message has been sent to " + number, System.Text.Encoding.UTF8.GetString(response));

                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        private string ProcessMessagePlaceholders(string message, string regardingobjectid, string regardingobjecttype, IOrganizationService service)
        {
            // Does this SMS activity have a regarding object and at least one place holder in the message?
            if (regardingobjectid != string.Empty && message.IndexOf("{") >= 0 && message.IndexOf("}") > message.IndexOf("{"))
            {
                XRMHelper regardingobject = new XRMHelper(service, regardingobjecttype);

                if (regardingobject.Retrieve(regardingobjectid))
                {
                    foreach (XRMAttributeHelper attr in regardingobject.Attributes)
                        message = message.Replace("{" + attr.Name + "}", attr.FormattedValue);
                }
            }

            return message;
        }

        private string SMSNumber(string number, string regardingobjectid, string regardingobjecttype, IOrganizationService service)
        {
            if (number == string.Empty)
            {
                // No number supplied, try and obtain it from the regarding object
                if (regardingobjectid != string.Empty && config[regardingobjecttype] != null)
                {
                    XRMHelper regardingobject = new XRMHelper(service, regardingobjecttype);
                    if (regardingobject.Retrieve(regardingobjectid, config[regardingobjecttype]))
                        number = regardingobject.Value(config[regardingobjecttype]);
                }
            }

            return number;
        }
    }
}
