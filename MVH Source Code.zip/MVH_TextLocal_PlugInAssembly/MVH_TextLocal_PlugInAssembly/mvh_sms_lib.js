﻿function OnLoad() {
    var subject = Xrm.Page.getAttribute('subject').getValue();

    if (subject == '' || subject == null)
        SubjectText();
}

function OnSave() {

}

function SubjectText() {
    var subject = null;
    var regardingobjectid = Xrm.Page.getAttribute('regardingobjectid').getValue();
    var mvh_predefinedsmsid = Xrm.Page.getAttribute('mvh_predefinedsmsid').getValue();
    var mvh_number = Xrm.Page.getAttribute('mvh_number').getValue();

    if (mvh_predefinedsmsid != null) {
        subject = mvh_predefinedsmsid[0].name;
    }

    if (mvh_number == null)
        mvh_number = '';

    if (mvh_number != '') {
        subject = "New SMS to " + mvh_number;
    }

    if (regardingobjectid != null) {
        subject = 'New SMS to ' + regardingobjectid[0].name;
    }

    if (subject != null)
        Xrm.Page.getAttribute('subject').setValue(subject);
}

function regardingobjectid_OnChange() {
    SubjectText();
}

function mvh_number_OnChange() {
    SubjectText();
}

function mvh_predefinedsmsid_OnChange() {
    SubjectText();

    var mvh_predefinedsmsid = Xrm.Page.getAttribute("mvh_predefinedsmsid").getValue();

    if (mvh_predefinedsmsid != null) {
        var url = Xrm.Page.context.getClientUrl() + '/api/data/v8.0/';
        url += 'mvh_predefinedsmses(' + mvh_predefinedsmsid[0].id.replace('{', '').replace('}', '') + ')';
        url += '?$select=mvh_message';

        var req = new XMLHttpRequest();
        req.open('GET', url, true);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var result = JSON.parse(this.response);
                    if (result["mvh_message"] != null) {
                        Xrm.Page.getAttribute('mvh_message').setValue(result["mvh_message"]);
                    }
                }
            }
        };

        req.send();
    }
    else {
        Xrm.Page.getAttribute('mvh_message').setValue('');
    }
}