﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Optitime_PollingService
{
    class Program
    {
        // APPOINTMENT-CONFIRMATION (FIRST)
        // COMPLETIONS (4), VARIATIONS (9), ABANDONMENTS (3)

        // Scheduled task command line arguments: "MVH_Optitime_PollingService.EXE /applog /unattended"
        // applog = Write to application log file in the Log sub folder
        // unattended = Run unattended, eg. as a scheduled task

        static void Main(string[] args)
        {
            string AppLog = string.Empty;
            string Rejections = string.Format("\\Rejections\\OptiRejections_{0}_{1}_{2}.txt", DateTime.Now.Year.ToString(),
                DateTime.Now.Month.ToString("00"),
                DateTime.Now.Day.ToString("00"));
            bool Unattended = false;
            bool CopyFiles = false;
            bool BJBTImport = false;
            bool _81to99 = false;
            Config config = new Config();
            XRM repair = new XRM("mvh_repairmodule", config);
            XRM mvh_stagehistory = new XRM("mvh_stagehistory", config);
            string repairid = string.Empty;
            string id = string.Empty;
            string FILname = "EVA"; // defaults to only processing variations
            bool mvh_applyminvalue = false;
            bool invalidstage = false;
            bool ProcessVariations = false;
            bool ProcessAbandons = false;
            bool ProcessCompletions = false;
            decimal minval = Convert.ToDecimal(config.Settings["minval"]);
            StringBuilder xml = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");

            // Process command line args
            foreach (string s in args)
            {
                // eg. "/applog" 
                if (s.ToLower().Contains("applog"))
                    AppLog = "\\Log\\" + DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString("00") + DateTime.Now.Day.ToString("00") + DateTime.Now.ToLongTimeString().Replace(":", string.Empty) + ".txt";
                // eg. "/unattended" 
                if (s.ToLower().Contains("unattended"))
                    Unattended = true;
                // eg. "/copyfiles"
                if (s.ToLower().Contains("copyfiles"))
                    CopyFiles = true;
                // eg. "/bjbt"
                if (s.ToLower().Contains("bjbt"))
                    BJBTImport = true;
                // eg. "/81to99"
                if (s.ToLower().Contains("81to99"))
                    _81to99 = true;
                // FIL type for processing abandons or completions
                if (s.ToUpper().Contains("EAB"))
                    FILname = "EAB";
                if (s.ToUpper().Contains("EPH"))
                    FILname = "EPH";
            }

            if (CopyFiles)
            {
                PollingFolder copy = new PollingFolder(config.Settings["path.filecopy.from"], "*.DAT");

                ConsoleAppHelper.WriteLine(AppLog, string.Format("Found: {0}", copy.Contents.Count.ToString()));

                foreach (OptiFile f in copy.Contents)
                {
                    ConsoleAppHelper.WriteLine(AppLog, string.Format("{0}", f.Name));
                    File.Move(f.FullName, config.Settings["path.filecopy.to"] + f.Name);
                }
            }
            else if (BJBTImport)
            {
                PollingFolder CSV = new PollingFolder(config.Settings["path.bjbt"], "*.CSV");

                ConsoleAppHelper.WriteLine(AppLog, string.Format("BJBT Import - found (*.CSV): {0}", CSV.Contents.Count.ToString()));

                foreach (OptiFile f in CSV.Contents)
                {
                    ConsoleAppHelper.WriteLine(AppLog, string.Format("-{0}", f.FullName));
                    f.OpenBJBT();
                    ConsoleAppHelper.WriteLine(AppLog, string.Format("--rows: {0}", f.BJBTRecords.Count.ToString()));
                    foreach (BJBTRecord bjbt in f.BJBTRecords)
                    {
                        id = repair.service.EntityGUID("mvh_name", bjbt.RepairNumber);
                        if (id != string.Empty)
                        {
                            repair.service.Retrieve(id, "mvh_scheme,mvh_stage");
                            if (!repair.service.BooleanValue("mvh_scheme"))
                            {
                                invalidstage = true;
                                if (config.Settings[string.Format("stage.{0}", repair.service.Value("mvh_stage"))] != null)
                                {
                                    if (config.Settings[string.Format("stage.{0}", repair.service.Value("mvh_stage"))].Contains(bjbt.Stage))
                                        invalidstage = false;
                                }
                                if (!invalidstage)
                                {
                                    // Valid repair number
                                    ConsoleAppHelper.WriteLine(AppLog, string.Format("---{0} {1} -> {2}", bjbt.RepairNumber, bjbt.Stage, id));
                                    mvh_stagehistory.service.InitialiseSchema();
                                    mvh_stagehistory.service.AddLookup("mvh_repairid", "mvh_repairmodule", id);
                                    mvh_stagehistory.service.AddPicklist("mvh_stage", bjbt.Stage);
                                    mvh_stagehistory.service.AddDateTime("mvh_datechanged", DateTime.Now);
                                    if (!mvh_stagehistory.service.Create())
                                    {
                                        // Error creating stage history record
                                        ConsoleAppHelper.WriteLine(Rejections, string.Format("(BJBT) error setting stage {1} for {0} ({2})", bjbt.RepairNumber, bjbt.Stage, mvh_stagehistory.service.Message), config, id);
                                    }
                                    else
                                    {
                                        // Now try and set completed date and/or abandon reason for the repair
                                        if (bjbt.CompletedDate != string.Empty || bjbt.AbandonReason != string.Empty)
                                        {
                                            ConsoleAppHelper.WriteLine(AppLog, string.Format("---{0} {1} {2}", bjbt.RepairNumber, bjbt.CompletedDate, bjbt.AbandonReason));
                                            repair.service.InitialiseSchema();
                                            if (config.Settings[string.Format("abandonreason.{0}", bjbt.AbandonReason)] != null)
                                            {
                                                repair.service.AddDateTime("mvh_abandoneddate", bjbt.CompletedDate);
                                                repair.service.AddPicklist("mvh_abandonreason", config.Settings[string.Format("abandonreason.{0}", bjbt.AbandonReason)]);
                                            }
                                            else
                                            {
                                                repair.service.AddDateTime("mvh_physicalcompleteddate", bjbt.CompletedDate);
                                            }
                                            if (!repair.service.Update(id))
                                            {
                                                // Error creating stage history record
                                                ConsoleAppHelper.WriteLine(Rejections, string.Format("(BJBT) error updating repair completed date / abandon reason for {0} ({1})", bjbt.RepairNumber, repair.service.Message), config, id);
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    // Rejected because it's an invalid stage
                                    ConsoleAppHelper.WriteLine(Rejections, string.Format("(BJBT) repair {0} cannot go to stage {1} because it is already at stage {2}", 
                                        bjbt.RepairNumber, repair.service.Value("mvh_stage"), bjbt.Stage), config, id);
                                }
                            }
                            else
                            {
                                // Rejected because it's a scheme
                                ConsoleAppHelper.WriteLine(Rejections, string.Format("(BJBT) repair {0} is a scheme", bjbt.RepairNumber), config, id);
                            }
                        }
                        else
                        {
                            // Not found
                            ConsoleAppHelper.WriteLine(Rejections, string.Format("(BJBT) repair not found: {0}", bjbt.RepairNumber), config);
                        }
                    }

                    // Delete the file so it doesn't get processed again
                    if (config.Settings["deletefiles"] == "yes")
                    {
                        f.Archive();
                        // f.Delete();
                        // ConsoleAppHelper.WriteLine(AppLog, f.ErrorMessage);
                    }
                }
            }
            else if (_81to99)
            {
                ConsoleAppHelper.WriteLine(AppLog, "81 -> 99");

                // Find all stage history records where date changed is in the last 7 days, stage = 81 and the linked repair is active and is still at stage 81
                xml.Append("<entity name=\"mvh_stagehistory\">");
                xml.Append("<attribute name=\"mvh_repairid\" />");
                xml.Append("<filter type=\"and\">");
                xml.Append("<condition attribute=\"mvh_stage\" operator=\"eq\" value=\"81\" />");
                xml.Append("<condition attribute=\"mvh_datechanged\" operator=\"last-seven-days\" />");
                xml.Append("</filter>");
                xml.Append("<link-entity name=\"mvh_repairmodule\" from=\"mvh_repairmoduleid\" to=\"mvh_repairid\" alias=\"ab\">");
                xml.Append("<attribute name=\"mvh_name\" />");
                xml.Append("<filter type=\"and\">");
                xml.Append("<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />");
                xml.Append("<condition attribute=\"mvh_stage\" operator=\"eq\" value=\"81\" />");
                xml.Append("</filter>");
                xml.Append("</link-entity>");
                xml.Append("</entity>");
                xml.Append("</fetch>");

                if (mvh_stagehistory.service.FetchEntityCollection(xml.ToString()))
                {
                    ConsoleAppHelper.WriteLine(AppLog, string.Format("-Found {0}", mvh_stagehistory.service.Results.Entities.Count.ToString()));

                    foreach (Entity ent in mvh_stagehistory.service.Results.Entities)
                    {
                        mvh_stagehistory.service.Retrieve(ent);
                        id = mvh_stagehistory.service.Value("mvh_repairid");
                        ConsoleAppHelper.WriteLine(AppLog, string.Format("-{0}", mvh_stagehistory.service.FormattedValue("ab.mvh_name")));

                        mvh_stagehistory.service.InitialiseSchema();
                        mvh_stagehistory.service.AddLookup("mvh_repairid", "mvh_repairmodule", id);
                        mvh_stagehistory.service.AddPicklist("mvh_stage", "99");
                        mvh_stagehistory.service.AddDateTime("mvh_datechanged", DateTime.Now);
                        if (!mvh_stagehistory.service.Create())
                        {
                            // Error creating stage history record
                            ConsoleAppHelper.WriteLine(Rejections, string.Format("(81 -> 99) error creating stage history for {0} ({1})",
                                mvh_stagehistory.service.FormattedValue("ab.mvh_name"), 
                                mvh_stagehistory.service.Message), config, id);
                        }
                    }
                }
            }
            else
            {
                // *******************************************
                // Process all .DAT files
                // *******************************************
                try
                {
                    int updated = 0;
                    string SlotFrom = string.Empty;
                    string SlotTo = string.Empty;
                    string Slot = string.Empty;
                    PollingFolder DAT = new PollingFolder(config.Settings["path.opti"], "*.DAT");

                    ConsoleAppHelper.WriteLine(AppLog, string.Format("Found (*.DAT): {0}", DAT.Contents.Count.ToString()));

                    foreach (OptiFile f in DAT.Contents)
                    {
                        ConsoleAppHelper.WriteLine(AppLog, string.Format("-Opening {0}", f.Name));
                        f.Open();

                        // Process each record in this file
                        foreach (string[] cols in f.ParsedLines)
                        {
                            if (cols.Length >= 10)
                            {
                                switch (cols[0])
                                {
                                    case "APPOINTMENT-CONFIRMATION":
                                        // Only process "FIRST" transactions
                                        if (cols[9].ToUpper() == "FIRST" || cols[9].ToUpper() == "FOLLOW ON")
                                        {
                                            id = repair.service.EntityGUID("mvh_name", RepairNumber.Convert(cols[2]));
                                            if (id != string.Empty)
                                            {
                                                repair.service.InitialiseSchema();
                                                if (cols[5] != string.Empty)
                                                    repair.service.AddDateTime("mvh_appointmentdate", cols[5]);
                                                if (cols[7] != string.Empty && cols[9].ToUpper() == "FIRST")
                                                    repair.service.AddDateTime("mvh_currenttargetdate", cols[7]);
                                                if (cols[5] != string.Empty && cols[6] != string.Empty)
                                                {
                                                    SlotFrom = Convert.ToDateTime(cols[5]).ToString("HH:mm");
                                                    SlotTo = Convert.ToDateTime(cols[6]).ToString("HH:mm");
                                                    if (SlotFrom == "08:00" && SlotTo == "12:00")
                                                        Slot = "916470000";
                                                    else if (SlotFrom == "09:30")
                                                        Slot = "916470001";
                                                    else if (SlotFrom == "13:00")
                                                        Slot = "916470002";
                                                    else
                                                        Slot = "916470003";
                                                    repair.service.AddPicklist("mvh_appointmentslot", Slot);
                                                    ConsoleAppHelper.WriteLine(AppLog, string.Format("-from {0} to {1} = {2}", SlotFrom, SlotTo, Slot));
                                                }
                                                if (repair.service.Update(id))
                                                {
                                                    ConsoleAppHelper.WriteLine(AppLog, string.Format("-Confirmed repair {0}", cols[2]));
                                                    updated++;
                                                }
                                                else
                                                {
                                                    ConsoleAppHelper.WriteLine(Rejections, string.Format("Error confirming repair {0} ({1})", cols[2], repair.service.Message), config, id);
                                                }
                                            }
                                            else
                                            {
                                                ConsoleAppHelper.WriteLine(Rejections, string.Format("Repair {0} not found", cols[2]), config);
                                            }
                                        }
                                        break;
                                }
                            }
                        }

                        // Delete the file so it doesn't get processed again
                        if (config.Settings["deletefiles"] == "yes")
                        {
                            f.Archive();
                            // f.Delete();
                            // ConsoleAppHelper.WriteLine(AppLog, f.ErrorMessage);
                        }
                    }

                    ConsoleAppHelper.WriteLine(AppLog, string.Format("Appointment confirmations: {0}", updated.ToString()));
                }
                catch (Exception ex)
                {
                    ConsoleAppHelper.WriteLine(Rejections, string.Format("ERROR processing .DAT files: {0}", ex.Message), config);
                }

                // *******************************************
                // Process all .FIL files
                // *******************************************
                try
                {
                    FILname = string.Format("*{0}*.FIL", FILname);
                    int completions = 0;
                    int abandonments = 0;
                    int variations = 0;
                    PollingFolder FIL = new PollingFolder(config.Settings["path.kirona"], FILname); // "*.FIL");

                    ConsoleAppHelper.WriteLine(AppLog, string.Format("\n\nFound ({1}): {0}", FIL.Contents.Count.ToString(), FILname));

                    // Process file types in the following order: variations, abandons, completions
                    for (int FILtype = 1; FILtype <= 3; FILtype++)
                    {
                        ProcessVariations = false;
                        ProcessAbandons = false;
                        ProcessCompletions = false;

                        if (FILtype == 1 && FILname.Contains("EVA"))
                            ProcessVariations = true;
                        if (FILtype == 2 && FILname.Contains("EAB"))
                            ProcessAbandons = true;
                        if (FILtype == 3 && FILname.Contains("EPH"))
                            ProcessCompletions = true;

                        // ConsoleAppHelper.WriteLine(AppLog, string.Format("{0} {1} {2}", ProcessVariations, ProcessAbandons, ProcessCompletions));

                        if (ProcessVariations || ProcessAbandons || ProcessCompletions)
                        {
                            foreach (OptiFile f in FIL.Contents)
                            {
                                ConsoleAppHelper.WriteLine(AppLog, string.Format("-Opening {0}", f.Name));
                                f.Open();

                                if (f.KironaRecords.Count > 0)
                                {
                                    if (f.KironaRecords[0].IsVariation && ProcessVariations)
                                    {
                                        // Get all SORs for this repair
                                        XRM mvh_repairworksorderline = new XRM("mvh_repairworksorderline", config);
                                        XRM mvh_sor = new XRM("mvh_sor", config);
                                        OptiFile CRMList = new OptiFile();
                                        decimal mvh_value = 0;

                                        CRMList.KironaRecords = new List<KironaRecord>();

                                        repairid = repair.service.EntityGUID("mvh_name", RepairNumber.Convert(f.KironaRecords[0].RepairNumber));
                                        ConsoleAppHelper.WriteLine(AppLog, string.Format("-Variation for RepairNumber {0}", f.KironaRecords[0].RepairNumber));

                                        // xml.Length = 0;
                                        xml = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");
                                        xml.Append("<entity name=\"mvh_repairworksorderline\">");
                                        xml.Append("<attribute name=\"mvh_repairworksorderlineid\" />");
                                        xml.Append("<attribute name=\"mvh_sor\" />");
                                        xml.Append("<attribute name=\"mvh_qty\" />");
                                        xml.Append("<filter type=\"and\">");
                                        xml.Append("<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />");
                                        xml.AppendFormat("<condition attribute=\"mvh_repair\" operator=\"eq\" uitype=\"mvh_repairmodule\" value=\"{0}\" />", repairid);
                                        xml.Append("</filter>");
                                        xml.Append("</entity>");
                                        xml.Append("</fetch>");

                                        if (mvh_repairworksorderline.service.FetchEntityCollection(xml.ToString()))
                                        {
                                            // ConsoleAppHelper.WriteLine(AppLog, string.Format("-Found {0}", mvh_repairworksorderline.service.Results.Entities.Count.ToString()));
                                            foreach (Entity ent in mvh_repairworksorderline.service.Results.Entities)
                                            {
                                                mvh_repairworksorderline.service.Retrieve(ent);
                                                CRMList.KironaRecords.Add(new KironaRecord(mvh_repairworksorderline.service.Value("mvh_repairworksorderlineid"),
                                                    mvh_repairworksorderline.service.Value("mvh_sor"),
                                                    mvh_repairworksorderline.service.FormattedValue("mvh_sor"),
                                                    mvh_repairworksorderline.service.Value("mvh_qty")));
                                            }

                                            foreach (KironaRecord k in f.KironaRecords)
                                            {
                                                if (!CRMList.Contains(k.SOR))
                                                {
                                                    // Not found, new SOR
                                                    id = mvh_sor.service.EntityGUID("mvh_name", k.SOR);
                                                    if (mvh_sor.service.Retrieve(id, "mvh_value"))
                                                    {
                                                        if (mvh_sor.service.Value("mvh_value") != string.Empty)
                                                            mvh_value = Convert.ToDecimal(mvh_sor.service.Value("mvh_value"));
                                                        mvh_repairworksorderline.service.InitialiseSchema();
                                                        mvh_repairworksorderline.service.AddLookup("mvh_repair", "mvh_repairmodule", repairid);
                                                        mvh_repairworksorderline.service.AddLookup("mvh_sor", "mvh_sor", id);
                                                        mvh_repairworksorderline.service.AddString("mvh_name", k.SOR);
                                                        mvh_repairworksorderline.service.AddDecimal("mvh_qty", k.Quantity.ToString());
                                                        mvh_repairworksorderline.service.AddMoney("mvh_sorvalue", Convert.ToString(mvh_value));
                                                        mvh_repairworksorderline.service.AddMoney("mvh_linevalue", Convert.ToString(mvh_value * k.Quantity));
                                                        if (!mvh_repairworksorderline.service.Create())
                                                        {
                                                            ConsoleAppHelper.WriteLine(Rejections, string.Format("Error adding SOR to {0} ({1})", k.RepairNumber, mvh_repairworksorderline.service.Message), config, repairid);
                                                        }
                                                        variations++;
                                                    }
                                                    ConsoleAppHelper.WriteLine(AppLog, string.Format("-Create SOR {0} {1}", k.SOR, id == string.Empty ? "(SOR not found)" : string.Empty));
                                                }
                                                else
                                                {
                                                    if (CRMList.Quantity != k.Quantity)
                                                    {
                                                        // Found, quantity changed
                                                        id = mvh_sor.service.EntityGUID("mvh_name", k.SOR);
                                                        if (mvh_sor.service.Retrieve(id, "mvh_value"))
                                                        {
                                                            if (mvh_sor.service.Value("mvh_value") != string.Empty)
                                                                mvh_value = Convert.ToDecimal(mvh_sor.service.Value("mvh_value"));
                                                            mvh_repairworksorderline.service.InitialiseSchema();
                                                            mvh_repairworksorderline.service.AddDecimal("mvh_qty", k.Quantity.ToString());
                                                            mvh_repairworksorderline.service.AddMoney("mvh_linevalue", Convert.ToString(mvh_value * k.Quantity));
                                                            if (!mvh_repairworksorderline.service.Update(CRMList.mvh_repairworksorderlineid))
                                                            {
                                                                ConsoleAppHelper.WriteLine(Rejections, string.Format("Error updating SOR quantity for {0} ({1})", k.RepairNumber, mvh_repairworksorderline.service.Message), config, repairid);
                                                            }
                                                            variations++;
                                                        }
                                                        ConsoleAppHelper.WriteLine(AppLog, string.Format("-Update SOR quantity {0} to {1}", k.SOR, k.Quantity.ToString("0.000")));
                                                    }
                                                    else
                                                    {
                                                        // Found, same quantity, do nothing
                                                        // ConsoleAppHelper.WriteLine(AppLog, string.Format("-Do Nothing SOR {0}", k.SOR));
                                                    }
                                                }
                                            }

                                            foreach (KironaRecord k in CRMList.KironaRecords)
                                            {
                                                if (!f.Contains(k.SOR))
                                                {
                                                    // Not found, abandon SOR
                                                    mvh_repairworksorderline.service.InitialiseSchema();
                                                    mvh_repairworksorderline.service.AddPicklist("mvh_abandonreason", "40"); // "916470039"); // NREQ - NOT REQUIRED
                                                    if (!mvh_repairworksorderline.service.Update(k.mvh_repairworksorderlineid))
                                                    {
                                                        ConsoleAppHelper.WriteLine(Rejections, string.Format("Error abandoning SOR for {0} ({1})", k.RepairNumber, mvh_repairworksorderline.service.Message), config, repairid);
                                                    }
                                                    ConsoleAppHelper.WriteLine(AppLog, string.Format("-Abandon SOR {0}", k.SOR));

                                                    // Not found, delete SOR
                                                    //mvh_repairworksorderline.service.Delete(k.mvh_repairworksorderlineid);
                                                    //ConsoleAppHelper.WriteLine(AppLog, string.Format("-Delete SOR {0}", k.SOR));

                                                    variations++;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            ConsoleAppHelper.WriteLine(Rejections, string.Format("Error running fetch XML for repair {0}: {1}", f.KironaRecords[0].RepairNumber, mvh_repairworksorderline.service.Message), config);
                                        }
                                    }
                                    else if (ProcessAbandons || ProcessCompletions)
                                    {
                                        // Process each completion / abdandonment record in this file
                                        foreach (KironaRecord k in f.KironaRecords)
                                        {
                                            if (k.SubType == "1")
                                            {
                                                ConsoleAppHelper.WriteLine(AppLog, string.Format("-RepairNumber {0}", k.RepairNumber));
                                                mvh_applyminvalue = false;
                                                id = repair.service.EntityGUID("mvh_name", RepairNumber.Convert(k.RepairNumber));
                                                if (id != string.Empty)
                                                {
                                                    if (repair.service.Retrieve(id, "mvh_totalcommittedcost"))
                                                    {
                                                        if (repair.service["mvh_totalcommittedcost"] != null)
                                                        {
                                                            if (Convert.ToDecimal(repair.service.Value("mvh_totalcommittedcost")) < minval)
                                                                mvh_applyminvalue = true;
                                                        }
                                                    }
                                                    repair.service.InitialiseSchema();
                                                    // Completion
                                                    if (k.IsCompletion && ProcessCompletions)
                                                    {
                                                        repair.service.AddDateTime("mvh_physicalcompleteddate", k.CompletionDate);
                                                        if (mvh_applyminvalue)
                                                            repair.service.AddBoolean("mvh_applyminvalue", mvh_applyminvalue);
                                                        if (repair.service.Update(id))
                                                        {
                                                            ConsoleAppHelper.WriteLine(AppLog, string.Format("-Completed repair {0}", k.RepairNumber));
                                                            completions++;
                                                        }
                                                        else
                                                        {
                                                            ConsoleAppHelper.WriteLine(Rejections, string.Format("Error completing repair {0} ({1})", k.RepairNumber, repair.service.Message), config, id);
                                                        }
                                                        // Update stage history
                                                        mvh_stagehistory.service.InitialiseSchema();
                                                        mvh_stagehistory.service.AddLookup("mvh_repairid", "mvh_repairmodule", id);
                                                        mvh_stagehistory.service.AddPicklist("mvh_stage", "81");
                                                        mvh_stagehistory.service.AddDateTime("mvh_datechanged", DateTime.Now);
                                                        mvh_stagehistory.service.Create();
                                                    }

                                                    // Abandonment
                                                    if (k.IsAbandonment && ProcessAbandons)
                                                    {
                                                        repair.service.AddDateTime("mvh_abandoneddate", k.AbandonedDate);
                                                        if (config.Settings[string.Format("abandonreason.{0}", k.AbandonReason)] != null)
                                                            repair.service.AddPicklist("mvh_abandonreason", config.Settings[string.Format("abandonreason.{0}", k.AbandonReason)]);
                                                        else
                                                            repair.service.AddPicklist("mvh_abandonreason", "59"); // "916470058"); // SE - SYSTEMS ERROR
                                                        if (repair.service.Update(id))
                                                        {
                                                            ConsoleAppHelper.WriteLine(AppLog, string.Format("-Abandoned repair {0}", k.RepairNumber));
                                                            abandonments++;
                                                        }
                                                        else
                                                        {
                                                            ConsoleAppHelper.WriteLine(Rejections, string.Format("Error abandoning repair {0} ({1})", k.RepairNumber, repair.service.Message), config, id);
                                                        }
                                                        // Update stage history
                                                        mvh_stagehistory.service.InitialiseSchema();
                                                        mvh_stagehistory.service.AddLookup("mvh_repairid", "mvh_repairmodule", id);
                                                        mvh_stagehistory.service.AddPicklist("mvh_stage", "50");
                                                        mvh_stagehistory.service.AddDateTime("mvh_datechanged", DateTime.Now);
                                                        mvh_stagehistory.service.Create();
                                                    }
                                                }
                                                else
                                                {
                                                    ConsoleAppHelper.WriteLine(Rejections, string.Format("Repair {0} not found", k.RepairNumber), config);
                                                }
                                            }
                                        }
                                    }
                                }

                                // Delete the file so it doesn't get processed again
                                //if (config.Settings["deletefiles"] == "yes")
                                //{
                                //    f.Archive();
                                //    // f.Delete();
                                //    // ConsoleAppHelper.WriteLine(AppLog, f.ErrorMessage);
                                //}
                            }
                        }
                    }

                    // Archive the files
                    foreach (OptiFile f in FIL.Contents)
                    {
                        if (config.Settings["deletefiles"] == "yes")
                        {
                            f.Archive();
                            ConsoleAppHelper.WriteLine(AppLog, string.Format("ERR: {0}", f.ErrorMessage));
                        }
                    }

                    ConsoleAppHelper.WriteLine(AppLog, string.Format("Variations: {0}", variations.ToString()));
                    ConsoleAppHelper.WriteLine(AppLog, string.Format("Abandonments: {0}", abandonments.ToString()));
                    ConsoleAppHelper.WriteLine(AppLog, string.Format("Completions: {0}", completions.ToString()));
                }
                catch (Exception ex)
                {
                    ConsoleAppHelper.WriteLine(Rejections, string.Format("ERROR processing .FIL files: {0}", ex.Message), config);
                }
            }

            // Done.
            if (!Unattended)
            {
                Console.WriteLine("\n\nProcessing completed - press any key to continue...");
                Console.ReadLine();
            }
        }
    }

    class OptiFile
    {
        public string Name = string.Empty;
        public string BaseName = string.Empty;
        public string FullName = string.Empty;
        public string Path = string.Empty;
        public string Extension = string.Empty;
        public string ErrorMessage = string.Empty;
        public bool Deleted = false;
        public decimal Quantity = 0;
        public string mvh_repairworksorderlineid = string.Empty;
        public IEnumerable<string> Lines;
        public List<string[]> ParsedLines;
        public List<KironaRecord> KironaRecords;
        public List<BJBTRecord> BJBTRecords;

        public OptiFile()
        {

        }

        public OptiFile(string name, string fullname, string path, string extension, string basename)
        {
            Name = name;
            FullName = fullname;
            Path = path;
            Extension = extension;
            BaseName = basename;

            if (!Path.EndsWith("\\"))
                Path += "\\";
        }

        public void Delete()
        {
            try
            {
                FileInfo fi = new FileInfo(FullName);

                if (fi.Exists)
                {
                    fi.Delete();
                    Deleted = true;
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
            }
        }

        public void Rename(string newfilename)
        {
            try
            {
                File.Move(FullName, Path + newfilename);
                Name = newfilename;
                FullName = Path + newfilename;
                Extension = System.IO.Path.GetFileNameWithoutExtension(FullName);
            }
            catch
            {

            }
        }

        public void RenameExtension(string newextension)
        {
            try
            {
                File.Move(FullName, Path + BaseName + newextension);
                FullName = Path + BaseName + newextension;
                Extension = newextension;
            }
            catch
            {

            }
        }

        public void Archive()
        {
            try
            {
                File.Move(FullName, Path + "Archive\\" + Name);
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message + " > " + Path;
            }
        }

        public void Open()
        {
            ParsedLines = new List<string[]>();
            KironaRecords = new List<KironaRecord>();

            Lines = File.ReadLines(FullName);

            foreach (string line in Lines)
            {
                if (!string.IsNullOrEmpty(line))
                {
                    ParsedLines.Add(line.Replace("'", string.Empty).Split(','));
                    KironaRecords.Add(new KironaRecord(line));
                }
            }
        }

        public void OpenBJBT()
        {
            string[] Line;
            ParsedLines = new List<string[]>();
            BJBTRecords = new List<BJBTRecord>();

            Lines = File.ReadLines(FullName);

            foreach (string line in Lines)
            {
                if (!string.IsNullOrEmpty(line))
                {
                    Line = line.Replace("'", string.Empty).Split(',');
                    if (Line.Length >= 2)
                        BJBTRecords.Add(new BJBTRecord(Line[0].Replace("\"", string.Empty), Line[1].Replace("\"", string.Empty)));
                    if (Line.Length >= 3)
                        BJBTRecords[BJBTRecords.Count - 1].CompletedDate = Line[2].Replace("\"", string.Empty);
                    if (Line.Length == 4)
                        BJBTRecords[BJBTRecords.Count - 1].AbandonReason = Line[3].Replace("\"", string.Empty);
                }
            }
        }

        public bool Contains(string sor)
        {
            bool found = false;

            foreach (KironaRecord k in this.KironaRecords)
            {
                if (k.SOR == sor)
                {
                    found = true;
                    Quantity = k.Quantity;
                    mvh_repairworksorderlineid = k.mvh_repairworksorderlineid;
                }
            }

            return found;
        }
    }

    class KironaRecord
    {
        public string Type = string.Empty;
        public string SubType = string.Empty;
        public string RepairNumber = string.Empty;
        public string CompletionDate = string.Empty;
        public string AbandonedDate = string.Empty;
        public string AbandonReason = string.Empty;
        public string SOR = string.Empty;
        public string mvh_sor = string.Empty;
        public string mvh_repairworksorderlineid = string.Empty;
        public decimal Quantity = 0;

        public KironaRecord()
        {

        }

        public KironaRecord(string line)
        {
            if (line.Length >= 12)
            {
                Type = line.Substring(0, 1);
                SubType = line.Substring(1, 1);
                RepairNumber = line.Substring(2, 10).Trim();
                if (this.IsCompletion)
                {
                    CompletionDate = Date(line.Substring(35, 14));
                }
                if (this.IsAbandonment)
                {
                    AbandonedDate = Date(line.Substring(39, 14));
                    AbandonReason = line.Substring(35, 4).Trim();
                }
                if (this.IsVariation)
                {
                    SOR = line.Substring(34, 8).Trim();
                    Quantity = line.Substring(42, 7).Trim() == string.Empty ? 0 : (Convert.ToDecimal(line.Substring(42, 7).Trim()) / 1000);
                }
            }
        }

        public KironaRecord(string id, string sor, string qty)
        {
            mvh_sor = id;
            SOR = sor;
            if (qty != string.Empty)
                Quantity = Convert.ToDecimal(qty);
        }

        public KironaRecord(string id, string sorid, string sor, string qty)
        {
            mvh_repairworksorderlineid = id;
            mvh_sor = sorid;
            SOR = sor;
            if (qty != string.Empty)
                Quantity = Convert.ToDecimal(qty);
        }

        public bool IsCompletion
        {
            get
            {
                if (Type == "4")
                    return true;
                else
                    return false;
            }
        }

        public bool IsAbandonment
        {
            get
            {
                if (Type == "3")
                    return true;
                else
                    return false;
            }
        }

        public bool IsVariation
        {
            get
            {
                if (Type == "9")
                    return true;
                else
                    return false;
            }
        }

        private string Date(string date)
        {
            if (date.Length == 14)
            {
                return string.Format("{0}/{1}/{2} {3}:{4}",
                    date.Substring(0, 2),
                    date.Substring(2, 2),
                    date.Substring(4, 4),
                    date.Substring(8, 2),
                    date.Substring(10, 2));
            }
            else
            {
                return string.Empty;
            }

        }
    }

    class BJBTRecord
    {
        public string RepairNumber = string.Empty;
        public string Stage = string.Empty;
        public string CompletedDate = string.Empty;
        public string AbandonReason = string.Empty;

        public BJBTRecord()
        {

        }

        public BJBTRecord(string repairnumber, string stage)
        {
            RepairNumber = repairnumber;
            Stage = stage;
        }

        public string RepairID
        {
            get
            {
                return string.Empty;
            }
        }
    }

    class PollingFolder
    {
        public List<OptiFile> Contents;

        public PollingFolder()
        {
            Contents = new List<OptiFile>();
        }

        public PollingFolder(string path)
        {
            this.Refresh(path, "*.*");
        }

        public PollingFolder(string path, string pattern)
        {
            this.Refresh(path, pattern);
        }

        public void Refresh(string path, string pattern)
        {
            Contents = new List<OptiFile>();

            DirectoryInfo dir = new DirectoryInfo(path);

            foreach (FileInfo file in dir.GetFiles(pattern))
            {
                Contents.Add(new OptiFile(file.Name, file.FullName, file.DirectoryName, file.Extension, Path.GetFileNameWithoutExtension(file.FullName)));
            }
        }
    }

    static class RepairNumber
    {
        public static string Convert(string repairnumber)
        {
            string newrepairnumber = repairnumber;

            if (!newrepairnumber.ToUpper().StartsWith("C"))
            {
                if (newrepairnumber.Length >= 6)
                    newrepairnumber = newrepairnumber.Substring(newrepairnumber.Length - 6);
            }

            return newrepairnumber;
        }
    }
}
