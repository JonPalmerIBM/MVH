﻿using System;
using System.Collections.Specialized;
using System.Data;
using System.Data.SqlClient;
using System.IO;

public class XRM
{
    public D365EntityHelper d365;

    public XRM(string type, Config config)
    {
        d365 = new D365EntityHelper(type);

        d365.Url = config.Settings["xrm.url"];
        d365.Organisation = config.Settings["xrm.organisation"];
        d365.Domain = config.Settings["xrm.domain"];
        d365.Username = config.Settings["xrm.username"];
        d365.Password = config.Settings["xrm.password"];
    }

    public XRM(string type, string org, Config config)
	{
        d365 = new D365EntityHelper(type, org);

        d365.Url = config.Settings["xrm.url"];
        d365.Domain = config.Settings["xrm.domain"];
        d365.Username = config.Settings["xrm.username"];
        d365.Password = config.Settings["xrm.password"];
	}

    public D365EntityHelper service
    {
        get
        {
            return d365;
        }
    }
}

public class Config
{
    public NameValueCollection Settings = new NameValueCollection();

    public Config()
    {
        string path = string.Format("{0}\\config.xml", Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location));

        DataSet ds = new DataSet("Config");

        ds.ReadXml(path);

        foreach (DataColumn dc in ds.Tables[0].Columns)
            Settings.Add(dc.ColumnName, Convert.ToString(ds.Tables[0].Rows[0][dc.ColumnName]));
    }
}

public class ConsoleAppHelper
{
    public static void WriteLine(string applog, string text)
    {
        Console.WriteLine(text);

        if (applog != string.Empty)
        {
            StreamWriter sw = System.IO.File.AppendText(ServiceFolder + applog);
            sw.WriteLine(text + "\n");
            sw.Close();
        }
    }

    public static void WriteLine(string applog, string text, Config config)
    {
        Console.WriteLine(text);

        if (applog != string.Empty)
        {
            StreamWriter sw = System.IO.File.AppendText(ServiceFolder + applog);
            sw.WriteLine(text + "\n");
            sw.Close();
        }

        // Create opti rejection record
        XRM mvh_optirejection = new XRM("mvh_optirejection", config);
        mvh_optirejection.service.AddString("mvh_name", text);
        mvh_optirejection.service.Create();
    }

    public static void WriteLine(string applog, string text, Config config, string id)
    {
        Console.WriteLine(text);

        if (applog != string.Empty)
        {
            StreamWriter sw = System.IO.File.AppendText(ServiceFolder + applog);
            sw.WriteLine(text + "\n");
            sw.Close();
        }

        // Create opti rejection record
        XRM mvh_optirejection = new XRM("mvh_optirejection", config);
        mvh_optirejection.service.AddString("mvh_name", text);
        mvh_optirejection.service.AddLookup("mvh_repairmoduleid", "mvh_repairmodule", id);
        mvh_optirejection.service.Create();
    }

    public static string ServiceFolder
    {
        get
        {
            string folder = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);

            if (!folder.EndsWith("\\"))
                folder += "\\";

            return folder;
        }
    }

    public static DateTime FormatDate(string date, string time)
    {
        if (time.StartsWith("23"))
            return Convert.ToDateTime(date).AddDays(1);
        else
            return Convert.ToDateTime(date);
    }
}