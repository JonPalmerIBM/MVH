﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    // 4.4	Recalculate Repair Value
    // Step: Message=Create + Update (mvh_qty, mvh_abandonreason), Primary Entity=mvh_repairworksorderline
    // Step: Message=Create, Primary Entity=mvh_stagehistory, Execution Order=9

    public class Handler_RecalculateRepairValue : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_RecalculateRepairValue()
        {
        }

        public Handler_RecalculateRepairValue(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_RecalculateRepairValue(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);
            string id = string.Empty;

            if (context.Depth >= 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "create":
                    case "update":
                        switch (context.PrimaryEntityName.ToLower())
                        {
                            case "mvh_repairworksorderline":
                                primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_repair,mvh_sor,mvh_qty");
                                if (primaryentity["mvh_repair"] != null && !primaryentity.FormattedValue("mvh_sor").ToLower().Contains("minval"))
                                {
                                    id = primaryentity.Value("mvh_repair");

                                    // Recalculate the SOR value for this WOL if the contractor qualifies for a discount and it's not a CONADJ
                                    if (!primaryentity.FormattedValue("mvh_sor").ToLower().Contains("conadj"))
                                    {
                                        decimal discount = GetContractorDiscount(id);

                                        if (discount > 0)
                                        {
                                            XRMHelper mvh_sor = new XRMHelper(service, "mvh_sor");

                                            if (mvh_sor.Retrieve(primaryentity.Value("mvh_sor"), "mvh_value"))
                                            {
                                                if (mvh_sor["mvh_value"] != null && primaryentity["mvh_qty"] != null)
                                                {
                                                    decimal sorvalue = Convert.ToDecimal(mvh_sor.Value("mvh_value"));
                                                    decimal qty = Convert.ToDecimal(primaryentity.Value("mvh_qty"));
                                                    discount = ((100 - discount) / 100);

                                                    sorvalue = (sorvalue * discount);

                                                    primaryentity.InitialiseSchema();
                                                    primaryentity.AddMoney("mvh_sorvalue", sorvalue);
                                                    primaryentity.AddMoney("mvh_linevalue", (qty * sorvalue));
                                                    primaryentity.Update(context.PrimaryEntityId.ToString());
                                                }
                                            }
                                        }
                                    }

                                    // Recalc
                                    RecalculateRepairValue(id, true);
                                }
                                break;
                            case "mvh_stagehistory":
                                primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_stage,mvh_repairid");
                                if (primaryentity["mvh_stage"] != null && primaryentity["mvh_repairid"] != null)
                                {
                                    if (primaryentity.Value("mvh_stage") == "81")
                                    {
                                        id = primaryentity.Value("mvh_repairid");
                                        decimal discount = GetContractorDiscount(id);

                                        // Recalculate if stage 81 and contractor qualifies for a discount
                                        if (discount > 0)
                                        {
                                            RecalculateWOLs(id, ((100 - discount) / 100));
                                            RecalculateRepairValue(id, false);
                                        }
                                    }
                                }
                                break;
                        }
                        break;
                }
            }
        }

        private void RecalculateRepairValue(string id, bool createstagehistory)
        {
            XRMHelper mvh_repairmodule = new XRMHelper(service, "mvh_repairmodule");
            XRMHelper mvh_stagehistory = new XRMHelper(service, "mvh_stagehistory");
            mvh_repairmodule.Retrieve(id, "mvh_stage");
            string stage = mvh_repairmodule.Value("mvh_stage");

            StringBuilder fetchXML = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");
            fetchXML.Append("<entity name=\"mvh_repairworksorderline\">");
            fetchXML.Append("<attribute name=\"mvh_qty\" />");
            fetchXML.Append("<attribute name=\"mvh_sorvalue\" />");
            fetchXML.Append("<attribute name=\"mvh_linevalue\" />");
            fetchXML.Append("<attribute name=\"mvh_abandonreason\" />");
            fetchXML.Append("<filter type=\"and\">");
            fetchXML.AppendFormat("<condition attribute=\"mvh_repair\" operator=\"eq\" uitype=\"mvh_repairmodule\" value=\"{0}\" />", id);
            fetchXML.Append("<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />");
            fetchXML.Append("</filter>");
            fetchXML.Append("</entity>");
            fetchXML.Append("</fetch>");

            if (primaryentity.FetchEntityCollection(fetchXML.ToString()))
            {
                decimal mvh_qty = 0;
                decimal mvh_sorvalue = 0;
                decimal mvh_linevalue = 0;
                decimal mvh_originalvalue = 0;
                decimal mvh_totalcommittedcost = 0;
                decimal mvh_abandonedvalue = 0;
                XRMHelper mvh_repairworksorderline = new XRMHelper(service);

                foreach (Entity ent in primaryentity.Results.Entities)
                {
                    mvh_repairworksorderline.Retrieve(ent);
                    if (mvh_repairworksorderline["mvh_qty"] != null && mvh_repairworksorderline["mvh_sorvalue"] != null)
                    {
                        mvh_qty = Convert.ToDecimal(mvh_repairworksorderline.Value("mvh_qty"));
                        mvh_sorvalue = Convert.ToDecimal(mvh_repairworksorderline.Value("mvh_sorvalue"));
                        mvh_linevalue = (mvh_qty * mvh_sorvalue); 

                        if (mvh_linevalue > 0)
                            mvh_originalvalue += mvh_linevalue;
                        if (mvh_repairworksorderline["mvh_abandonreason"] == null)
                        {
                            // Not abandoned
                            mvh_totalcommittedcost += mvh_linevalue;
                        }
                        else
                        {
                            // Abandoned
                            mvh_abandonedvalue += mvh_linevalue;
                        }
                    }
                }

                // Update the parent repair
                mvh_repairmodule.InitialiseSchema();
                mvh_repairmodule.AddMoney("mvh_totalcommittedcost", mvh_totalcommittedcost);
                mvh_repairmodule.AddMoney("mvh_abandonedvalue", mvh_abandonedvalue);
                switch (stage)
                {
                    case "1":
                        mvh_repairmodule.AddMoney("mvh_originalvalue", mvh_originalvalue);
                        break;
                }
                mvh_repairmodule.Update(id);

                // Add a stage history to reflect this amendment (but not for all stages)
                switch (stage)
                {
                    case "2":
                    case "3":
                    case "6":
                    case "11":
                    case "15":
                        if (createstagehistory)
                        {
                            mvh_stagehistory.AddLookup("mvh_repairid", "mvh_repairmodule", id);
                            mvh_stagehistory.AddPicklist("mvh_stage", "6");
                            mvh_stagehistory.AddDateTime("mvh_datechanged", DateTime.Now);
                            mvh_stagehistory.AddString("mvh_additionalinformation", "Change to works order line.");
                            mvh_stagehistory.Create();
                        }
                        break;
                }
            }
        }

        private void RecalculateWOLs(string id, decimal discount)
        {
            decimal mvh_qty = 0;
            decimal mvh_value = 0;
            decimal mvh_linevalue = 0;
            XRMHelper wol = new XRMHelper(service, "mvh_repairworksorderline");
            StringBuilder fetchXML = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");

            fetchXML.Append("<entity name=\"mvh_repairworksorderline\">");
            fetchXML.Append("<attribute name=\"mvh_qty\" />");
            fetchXML.Append("<attribute name=\"mvh_sor\" />");
            fetchXML.Append("<filter type=\"and\">");
            fetchXML.AppendFormat("<condition attribute=\"mvh_repair\" operator=\"eq\" uitype=\"mvh_repairmodule\" value=\"{0}\" />", id);
            fetchXML.Append("<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />");
            fetchXML.Append("</filter>");
            fetchXML.Append("<link-entity name=\"mvh_sor\" from=\"mvh_sorid\" to=\"mvh_sor\" visible=\"false\" link-type=\"outer\" alias=\"sor\">");
            fetchXML.Append("<attribute name=\"mvh_value\" />");
            fetchXML.Append("</link-entity>");
            fetchXML.Append("</entity>");
            fetchXML.Append("</fetch>");

            if (primaryentity.FetchEntityCollection(fetchXML.ToString()))
            {
                foreach (Entity ent in primaryentity.Results.Entities)
                {
                    wol.Retrieve(ent);
                    if (wol.FormattedValue("mvh_sor").ToLower() != "minval" && wol.FormattedValue("mvh_sor").ToLower() != "conadj")
                    {
                        mvh_qty = 0;
                        mvh_value = 0;
                        if (wol["mvh_qty"] != null)
                            mvh_qty = Convert.ToDecimal(wol.Value("mvh_qty"));
                        if (ent.Attributes["sor.mvh_value"] != null)
                            mvh_value = ((Microsoft.Xrm.Sdk.Money)((AliasedValue)ent.Attributes["sor.mvh_value"]).Value).Value;

                        mvh_value = (mvh_value * discount);
                        mvh_linevalue = (mvh_qty * mvh_value);

                        wol.InitialiseSchema();
                        wol.AddMoney("mvh_sorvalue", mvh_value);
                        wol.AddMoney("mvh_linevalue", mvh_linevalue);
                        wol.Update(ent.Id.ToString());
                    }
                }
            }
        }

        private decimal GetContractorDiscount(string id)
        {
            decimal discount = 0;
            string today = DateTime.Now.ToString("yyyy-MM-dd");
            XRMHelper mvh_repairmodule = new XRMHelper(service, "mvh_repairmodule");

            if (mvh_repairmodule.Retrieve(id, "mvh_accountid,mvh_type"))
            {
                StringBuilder fetchXML = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");
                fetchXML.Append("<entity name=\"mvh_contractordiscount\">");
                fetchXML.Append("<attribute name=\"mvh_contractordiscountid\" />");
                fetchXML.Append("<attribute name=\"mvh_discount\" />");
                fetchXML.Append("<order attribute=\"mvh_discount\" descending=\"false\" />");
                fetchXML.Append("<filter type=\"and\">");
                fetchXML.AppendFormat("<condition attribute=\"mvh_accountid\" operator=\"eq\" uitype=\"account\" value=\"{0}\" />", mvh_repairmodule.Value("mvh_accountid"));
                fetchXML.AppendFormat("<condition attribute=\"mvh_repairtype\" operator=\"eq\" value=\"{0}\" />", mvh_repairmodule.Value("mvh_type"));
                fetchXML.AppendFormat("<condition attribute=\"mvh_from\" operator=\"on-or-before\" value=\"{0}\" />", today);
                fetchXML.AppendFormat("<condition attribute=\"mvh_to\" operator=\"on-or-after\" value=\"{0}\" />", today);
                fetchXML.Append("<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />");
                fetchXML.Append("</filter>");
                fetchXML.Append("</entity>");
                fetchXML.Append("</fetch>");

                if (primaryentity.FetchEntityCollection(fetchXML.ToString()))
                {
                    if (primaryentity.Results.Entities.Count > 0)
                    {
                        XRMHelper mvh_contractordiscount = new XRMHelper(service, "mvh_contractordiscount");

                        mvh_contractordiscount.Retrieve(primaryentity.Results.Entities[0]);

                        if (mvh_contractordiscount["mvh_discount"] != null)
                            discount = Convert.ToDecimal(mvh_contractordiscount.Value("mvh_discount"));
                    }
                }
            }

            return discount;
        }
    }
}

