﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    /*
     * 4.15 Apply Minimum Value
     * Message = Update
     * Primary Entity = mvh_repairmodule
     * Filtering Attributes = mvh_applyminvalue
     * Execution Order = 1
     * Unsecure = 35 (min value amount)
     * Secure = 
    */

    public class Handler_ApplyMinValue : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_ApplyMinValue()
        {
        }

        public Handler_ApplyMinValue(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_ApplyMinValue(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);
            string message = context.MessageName.ToLower();

            if (context.Depth >= 1)
            {
                if (message == "update")
                {
                    primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_totalcommittedcost,mvh_applyminvalue");
                    if (primaryentity.BooleanValue("mvh_applyminvalue"))
                    {
                        decimal minval = 35;
                        decimal mvh_totalcommittedcost = 0;

                        if (unsecure != string.Empty)
                            minval = Convert.ToDecimal(unsecure);

                        if (primaryentity["mvh_totalcommittedcost"] != null)
                            mvh_totalcommittedcost = Convert.ToDecimal(primaryentity.Value("mvh_totalcommittedcost"));

                        if (mvh_totalcommittedcost < minval)
                        {
                            decimal diff = (minval - mvh_totalcommittedcost);
                            XRMHelper mvh_repairworksorderline = new XRMHelper(service, "mvh_repairworksorderline");
                            XRMHelper mvh_sor = new XRMHelper(service, "mvh_sor");

                            string sorname = "MINVAL";
                            string id = mvh_sor.EntityGUID("mvh_name", sorname);
                            if (id != string.Empty)
                            {
                                mvh_repairworksorderline.AddString("mvh_name", sorname);
                                mvh_repairworksorderline.AddLookup("mvh_repair", "mvh_repairmodule", context.PrimaryEntityId.ToString());
                                mvh_repairworksorderline.AddLookup("mvh_sor", "mvh_sor", id);
                                mvh_repairworksorderline.AddDecimal("mvh_qty", diff.ToString("0.00"));
                                mvh_repairworksorderline.AddMoney("mvh_linevalue", diff);
                                mvh_repairworksorderline.AddMoney("mvh_sorvalue", 1);

                                if (mvh_repairworksorderline.Create())
                                {
                                    primaryentity.InitialiseSchema();
                                    primaryentity.AddMoney("mvh_totalcommittedcost", minval);
                                    primaryentity.Update(context.PrimaryEntityId.ToString());
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

