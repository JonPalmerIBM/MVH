﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    // 4.7	Update Repair Target Dates
    // Step: Message=Create + Update (mvh_accountid, mvh_priority, mvh_createdon), Primary Entity=mvh_repairmodule
    // SELECT CalendarId FROM CalendarBase WHERE Name = 'Business Closure Calendar'

    public class Handler_UpdateRepairTargetDates : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_UpdateRepairTargetDates()
        {
        }

        public Handler_UpdateRepairTargetDates(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_UpdateRepairTargetDates(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth >= 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "create":
                    case "update":
                        primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_priority,mvh_accountid,mvh_createdon,mvh_originaltargetdate");
                        if (primaryentity["mvh_priority"] != null && primaryentity["mvh_accountid"] != null && primaryentity["mvh_createdon"] != null)
                        {
                            string priority = primaryentity.Value("mvh_priority");
                            string contractor = primaryentity.Value("mvh_accountid");
                            string mvh_originaltargetdate = primaryentity.Value("mvh_originaltargetdate");

                            // Find the days to add
                            StringBuilder xml = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\" count=\"1\">");

                            xml.Append("<entity name=\"mvh_targetdatepriority\">");
                            xml.Append("<attribute name=\"mvh_days\" />");
                            xml.Append("<filter type=\"and\">");
                            xml.Append("<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />");
                            xml.AppendFormat("<condition attribute=\"mvh_priority\" operator=\"eq\" value=\"{0}\" />", priority);
                            // xml.AppendFormat("<condition attribute=\"mvh_accountid\" operator=\"eq\" uitype=\"account\" value=\"{0}\" />", contractor);
                            xml.Append("</filter>");
                            xml.Append("</entity>");
                            xml.Append("</fetch>");

                            if (primaryentity.FetchEntityCollection(xml.ToString()))
                            {
                                if (primaryentity.Results.Entities.Count > 0)
                                {
                                    XRMHelper bcal = new XRMHelper(service, "calendar");
                                    XRMHelper mvh_targetdatepriority = new XRMHelper(service, "mvh_targetdatepriority");

                                    mvh_targetdatepriority.Retrieve(primaryentity.Results.Entities[0]);

                                    if (mvh_targetdatepriority["mvh_days"] != null)
                                    {
                                        DateTime mvh_currenttargetdate = primaryentity.Date("mvh_createdon").AddDays(Convert.ToInt32(mvh_targetdatepriority.Value("mvh_days"))); // DateTime.Today.AddDays(Convert.ToInt32(mvh_targetdatepriority.Value("mvh_days")));

                                        // Ensure date is not a weekend date or in the business closure calendar
                                        mvh_currenttargetdate = bcal.NextAvailableDate(mvh_currenttargetdate);

                                        // Update the repair dates
                                        primaryentity.InitialiseSchema();
                                        primaryentity.AddDateTime("mvh_currenttargetdate", mvh_currenttargetdate);
                                        //if (context.MessageName.ToLower() == "create")
                                        //    primaryentity.AddDateTime("mvh_originaltargetdate", mvh_currenttargetdate);
                                        if (mvh_originaltargetdate == string.Empty)
                                            primaryentity.AddDateTime("mvh_originaltargetdate", mvh_currenttargetdate);
                                        primaryentity.Update(context.PrimaryEntityId.ToString());
                                    }
                                }
                            }
                        }
                        break;
                }
            }
        }
    }
}

