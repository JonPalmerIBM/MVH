﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    // 4.11	Calculate H&S WIP Scores
    // Step: Message=Update, Primary Entity=mvh_hs_wip, Attribute=mvh_completed

    public class Handler_OnUpdate_HS_WIP : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_OnUpdate_HS_WIP()
        {
        }

        public Handler_OnUpdate_HS_WIP(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_OnUpdate_HS_WIP(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth == 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "update":
                        primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_hs_inspectionid");
                        string mvh_hs_inspectionid = primaryentity.Value("mvh_hs_inspectionid").ToUpper();

                        if (mvh_hs_inspectionid != string.Empty)
                        {
                            int B74 = 0;
                            int C74 = 0;
                            int D74 = 0;

                            StringBuilder fetchXML = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");
                            fetchXML.Append("<entity name=\"mvh_hs_wip\">");
                            fetchXML.Append("<attribute name=\"mvh_hs_wipid\" />");
                            fetchXML.Append("<attribute name=\"mvh_completed\" />");
                            fetchXML.Append("<filter type=\"and\">");
                            fetchXML.Append("<condition attribute=\"mvh_hs_inspectionid\" operator=\"eq\" uitype=\"mvh_hs_inspection\" value=\"{GUID}\" />");
                            fetchXML.Append("<condition attribute=\"mvh_completed\" operator=\"eq\" value=\"YESNO\" />");
                            fetchXML.Append("</filter>");
                            fetchXML.Append("</entity>");
                            fetchXML.Append("</fetch>");

                            string query = fetchXML.ToString();

                            // Yes
                            if (primaryentity.FetchEntityCollection(fetchXML.ToString().Replace("GUID", mvh_hs_inspectionid).Replace("YESNO", "916470000")))
                                B74 = primaryentity.Results.Entities.Count;

                            // No
                            if (primaryentity.FetchEntityCollection(fetchXML.ToString().Replace("GUID", mvh_hs_inspectionid).Replace("YESNO", "916470001")))
                                C74 = primaryentity.Results.Entities.Count;

                            D74 = (B74 + C74);

                            XRMHelper mvh_hs_inspection = new XRMHelper(service, "mvh_hs_inspection");
                            mvh_hs_inspection.AddInteger("mvh_actionsraisedwip", C74.ToString());
                            if (D74 > 0)
                                mvh_hs_inspection.AddInteger("mvh_percentagescore", Convert.ToString(B74 / D74));
                            else
                                mvh_hs_inspection.AddInteger("mvh_percentagescore", B74.ToString());
                            mvh_hs_inspection.Update(mvh_hs_inspectionid);
                        }

                        break;
                }
            }
        }
    }
}


