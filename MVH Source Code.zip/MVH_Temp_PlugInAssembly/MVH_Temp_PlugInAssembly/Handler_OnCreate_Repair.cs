﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    // 4.2	Create a Repair from a Predefined Job
    // Step: Message=Create, Primary Entity=mvh_repairmodule

    public class Handler_OnCreate_Repair : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_OnCreate_Repair()
        {
        }

        public Handler_OnCreate_Repair(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_OnCreate_Repair(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth >= 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "create":
                        // Predefined job?
                        primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_predefinedjobid,mvh_propertyid,mvh_description,mvh_priority");
                        string mvh_description = primaryentity.Value("mvh_description");
                        string overridenpriority = primaryentity.Value("mvh_priority");
                        if (primaryentity["mvh_predefinedjobid"] != null)
                        {
                            string mvh_predefinedjobid = primaryentity.Value("mvh_predefinedjobid");
                            XRMHelper mvh_predefinedjob = new XRMHelper(service, "mvh_predefinedjob");
                            if (mvh_predefinedjob.Retrieve(mvh_predefinedjobid,
                                "mvh_description,mvh_contractor,mvh_type,mvh_priority,mvh_trade,mvh_location,mvh_source,mvh_category,mvh_costcode,mvh_costcentrecode,mvh_expensecode,mvh_projectcode,mvh_locationcostcodes,mvh_inspection,mvh_inspector"))
                            {
                                // Update the repair
                                primaryentity.InitialiseSchema();
                                if (mvh_description == string.Empty)
                                    primaryentity.AddString("mvh_description", mvh_predefinedjob.Value("mvh_description"));
                                primaryentity.AddString("mvh_costcode", mvh_predefinedjob.Value("mvh_costcode"));
                                primaryentity.AddLookup("mvh_accountid", "account", mvh_predefinedjob.Value("mvh_contractor"));
                                primaryentity.AddLookup("mvh_tenancybasicid", "mvh_tenancybasic", GetTenancyIdForProperty(primaryentity.Value("mvh_propertyid")));
                                // primaryentity.AddLookup("mvh_source", "mvh_jobsource", mvh_predefinedjob.Value("mvh_source"));
                                // primaryentity.AddBoolean("mvh_inspection", mvh_predefinedjob.Value("mvh_inspection"));
                                if (mvh_predefinedjob.FormattedValue("mvh_type") != string.Empty)
                                    primaryentity.AddPicklist("mvh_type", mvh_predefinedjob.Value("mvh_type"));
                                if (mvh_predefinedjob.FormattedValue("mvh_priority") != string.Empty && overridenpriority == string.Empty)
                                    primaryentity.AddPicklist("mvh_priority", mvh_predefinedjob.Value("mvh_priority"));
                                if (mvh_predefinedjob.FormattedValue("mvh_trade") != string.Empty)
                                    primaryentity.AddPicklist("mvh_trade", mvh_predefinedjob.Value("mvh_trade"));
                                if (mvh_predefinedjob.FormattedValue("mvh_location") != string.Empty)
                                    primaryentity.AddPicklist("mvh_location", mvh_predefinedjob.Value("mvh_location"));
                                if (mvh_predefinedjob.FormattedValue("mvh_category") != string.Empty)
                                    primaryentity.AddPicklist("mvh_category", mvh_predefinedjob.Value("mvh_category"));
                                if (mvh_predefinedjob.FormattedValue("mvh_costcentrecode") != string.Empty)
                                    primaryentity.AddPicklist("mvh_costcentrecode", mvh_predefinedjob.Value("mvh_costcentrecode"));
                                if (mvh_predefinedjob.FormattedValue("mvh_expensecode") != string.Empty)
                                    primaryentity.AddPicklist("mvh_expensecode", mvh_predefinedjob.Value("mvh_expensecode"));
                                if (mvh_predefinedjob.FormattedValue("mvh_projectcode") != string.Empty)
                                    primaryentity.AddPicklist("mvh_projectcode", mvh_predefinedjob.Value("mvh_projectcode"));
                                if (mvh_predefinedjob.FormattedValue("mvh_locationcostcodes") != string.Empty)
                                    primaryentity.AddPicklist("mvh_locationcostcode_", mvh_predefinedjob.Value("mvh_locationcostcodes"));
                                // primaryentity.AddPicklist("mvh_locationcode", mvh_predefinedjob.Value("mvh_locationcode"));
                                // primaryentity.AddPicklist("mvh_inspectedby", mvh_predefinedjob.Value("mvh_inspector"));
                                
                                if (!primaryentity.Update(context.PrimaryEntityId.ToString()))
                                {
                                    // throw new InvalidPluginExecutionException("Error updating repair from predefined job: " + primaryentity.Message);
                                }

                                // Retrieve predefined job works order lines
                                StringBuilder fetchXML = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");
                                fetchXML.Append("<entity name=\"mvh_predefinedjobworksorderline\">");
                                fetchXML.Append("<attribute name=\"mvh_name\" />");
                                fetchXML.Append("<attribute name=\"mvh_sor\" />");
                                fetchXML.Append("<attribute name=\"mvh_qty\" />");
                                fetchXML.Append("<attribute name=\"mvh_location\" />");
                                fetchXML.Append("<filter type=\"and\">");
                                fetchXML.AppendFormat("<condition attribute=\"mvh_predefinedjob\" operator=\"eq\" uitype=\"mvh_predefinedjob\" value=\"{0}\" />", mvh_predefinedjobid);
                                fetchXML.Append("<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />");
                                fetchXML.Append("</filter>");
                                fetchXML.Append("<link-entity name=\"mvh_sor\" from=\"mvh_sorid\" to=\"mvh_sor\" visible=\"false\" link-type=\"outer\" alias=\"sor\">");
                                fetchXML.Append("<attribute name=\"mvh_value\" />");
                                fetchXML.Append("</link-entity>");
                                fetchXML.Append("</entity>");
                                fetchXML.Append("</fetch>");

                                if (primaryentity.FetchEntityCollection(fetchXML.ToString()))
                                {
                                    // Add works order lines to repair
                                    XRMHelper mvh_repairworksorderline = new XRMHelper(service, "mvh_repairworksorderline");
                                    XRMHelper mvh_predefinedjobworksorderline = new XRMHelper(service);
                                    foreach (Entity ent in primaryentity.Results.Entities)
                                    {
                                        mvh_predefinedjobworksorderline.Retrieve(ent);
                                        string mvh_value = string.Empty;
                                        if (ent.Attributes["sor.mvh_value"] != null)
                                            mvh_value = ((Microsoft.Xrm.Sdk.Money)((AliasedValue)ent.Attributes["sor.mvh_value"]).Value).Value.ToString();
                                        mvh_repairworksorderline.InitialiseSchema();
                                        mvh_repairworksorderline.AddString("mvh_name", mvh_predefinedjobworksorderline.Value("mvh_name"));
                                        mvh_repairworksorderline.AddLookup("mvh_repair", "mvh_repairmodule", context.PrimaryEntityId.ToString());
                                        mvh_repairworksorderline.AddLookup("mvh_sor", "mvh_sor", mvh_predefinedjobworksorderline.Value("mvh_sor"));
                                        mvh_repairworksorderline.AddDecimal("mvh_qty", mvh_predefinedjobworksorderline.Value("mvh_qty"));
                                        mvh_repairworksorderline.AddPicklist("mvh_location", mvh_predefinedjobworksorderline.Value("mvh_location"));
                                        mvh_repairworksorderline.AddMoney("mvh_sorvalue", mvh_value);
                                        if (mvh_value != string.Empty && mvh_predefinedjobworksorderline.Value("mvh_qty") != string.Empty)
                                            mvh_repairworksorderline.AddMoney("mvh_linevalue",
                                                (Convert.ToDecimal(mvh_value) * Convert.ToDecimal(mvh_predefinedjobworksorderline.Value("mvh_qty"))));
                                        mvh_repairworksorderline.Create();
                                    }
                                }
                            }
                        }
                        break;
                }
            }
        }

        public string GetTenancyIdForProperty(string id)
        {
            XRMHelper tenancy = new XRMHelper(service);
            StringBuilder xml = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\" count=\"1\">");

            xml.Append("<entity name=\"mvh_tenancybasic\">");
            xml.Append("<attribute name=\"mvh_name\" />");
            xml.Append("<order attribute=\"mvh_tenancystartdate\" descending=\"true\" />");
            xml.Append("<filter type=\"and\">");
            xml.Append("<condition attribute=\"mvh_tenancystatus\" operator=\"eq\" value=\"1\" />");
            xml.Append("<condition attribute=\"mvh_tenancystartdate\" operator=\"not-null\" />");
            xml.Append("<condition attribute=\"mvh_tenancyenddate\" operator=\"null\" />");
            xml.AppendFormat("<condition attribute=\"mvh_address\" operator=\"eq\" uitype=\"mvh_properties\" value=\"{0}\" />", id);
            xml.Append("</filter>");
            xml.Append("</entity>");
            xml.Append("</fetch>");

            if (tenancy.FetchEntityCollection(xml.ToString()))
            {
                if (tenancy.Results.Entities.Count > 0)
                {
                    return tenancy.Results.Entities[0].Id.ToString();
                }
            }

            return string.Empty;
        }
    }
}

