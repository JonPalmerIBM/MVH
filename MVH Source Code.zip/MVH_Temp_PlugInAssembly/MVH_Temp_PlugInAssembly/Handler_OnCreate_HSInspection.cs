﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    // 4.9	Create H&S Sections
    // Step: Message=Create, Primary Entity=mvh_hs_inspection

    public class Handler_OnCreate_HSInspection : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_OnCreate_HSInspection()
        {
        }

        public Handler_OnCreate_HSInspection(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_OnCreate_HSInspection(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth == 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "create":
                        // Retrieve all control measure records
                        StringBuilder fetchXML = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");
                        fetchXML.Append("<entity name=\"mvh_hs_section\">");
                        fetchXML.Append("<attribute name=\"mvh_name\" />");
                        fetchXML.Append("<attribute name=\"mvh_section\" />");
                        fetchXML.Append("<attribute name=\"mvh_order\" />");
                        fetchXML.Append("<attribute name=\"mvh_reforder\" />");
                        fetchXML.Append("<attribute name=\"mvh_hs_sectionid\" />");
                        fetchXML.Append("<attribute name=\"mvh_form\" />");
                        fetchXML.Append("<attribute name=\"mvh_auditcategory\" />");
                        fetchXML.Append("<order attribute=\"mvh_section\" descending=\"false\" />");
                        fetchXML.Append("<order attribute=\"mvh_order\" descending=\"false\" />");
                        fetchXML.Append("<filter type=\"and\">");
                        fetchXML.Append("<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />");
                        fetchXML.Append("</filter>");
                        fetchXML.Append("</entity>");
                        fetchXML.Append("</fetch>");

                        XRMHelper mvh_hs_section = new XRMHelper(service, "mvh_hs_section");
                        XRMHelper mvh_hs_auditreport = new XRMHelper(service, "mvh_hs_auditreport");
                        XRMHelper mvh_hs_wip = new XRMHelper(service, "mvh_hs_wip");

                        if (mvh_hs_section.FetchEntityCollection(fetchXML.ToString()))
                        {
                            // Create control measure item records for this inspection
                            foreach (Entity ent in mvh_hs_section.Results.Entities)
                            {
                                mvh_hs_section.Retrieve(ent);
                                switch (mvh_hs_section.Value("mvh_form"))
                                {
                                    case "916470000":
                                        // Audit
                                        mvh_hs_auditreport.InitialiseSchema();
                                        mvh_hs_auditreport.AddLookup("mvh_hs_inspectionid", "mvh_hs_inspection", context.PrimaryEntityId.ToString());
                                        mvh_hs_auditreport.AddLookup("mvh_hs_sectionid", "mvh_hs_section", mvh_hs_section.Value("mvh_hs_sectionid"));
                                        mvh_hs_auditreport.AddInteger("mvh_order", mvh_hs_section.Value("mvh_order"));
                                        mvh_hs_auditreport.AddString("mvh_name", mvh_hs_section.FormattedValue("mvh_section"), 100);
                                        mvh_hs_auditreport.AddPicklist("mvh_auditcategory", mvh_hs_section.Value("mvh_auditcategory"));
                                        mvh_hs_auditreport.AddInteger("mvh_overallrating", "0");
                                        mvh_hs_auditreport.Create();
                                        break;
                                    case "916470001":
                                        // WIP
                                        mvh_hs_wip.InitialiseSchema();
                                        mvh_hs_wip.AddLookup("mvh_hs_inspectionid", "mvh_hs_inspection", context.PrimaryEntityId.ToString());
                                        mvh_hs_wip.AddLookup("mvh_hs_sectionid", "mvh_hs_section", mvh_hs_section.Value("mvh_hs_sectionid"));
                                        mvh_hs_wip.AddInteger("mvh_order", mvh_hs_section.Value("mvh_order"));
                                        mvh_hs_wip.AddString("mvh_name", mvh_hs_section.FormattedValue("mvh_section"), 100);
                                        mvh_hs_wip.Create();
                                        break;
                                }
                            }
                        }

                        break;
                }
            }
        }
    }
}

