﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    // 4.6	Update Stage History
    // Step: Message=Create, Primary Entity=mvh_stagehistory

    public class Handler_OnCreate_StageHistory : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_OnCreate_StageHistory()
        {
        }

        public Handler_OnCreate_StageHistory(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_OnCreate_StageHistory(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth >= 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "create":
                        primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_stage,mvh_repairid");
                        if (primaryentity["mvh_stage"] != null && primaryentity["mvh_repairid"] != null)
                        {
                            if (primaryentity.Value("mvh_stage") != "1")
                            {
                                XRMHelper repair = new XRMHelper(service, "mvh_repairmodule");
                                repair.AddPicklist("mvh_stage", primaryentity.Value("mvh_stage"));
                                repair.Update(primaryentity.Value("mvh_repairid"));
                            }
                        }
                        break;
                }
            }
        }
    }
}

