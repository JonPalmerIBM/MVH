﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    // 4.3	Convert Inspection To Repair
    // Step: Message=Update (mvh_predefjobid1,mvh_predefjobid2,mvh_predefjobid3,mvh_predefjobid4), Primary Entity=mvh_repairmodule
    // Step (not used): Message=Update (mvh_converttorepair), Primary Entity=mvh_repairmodule

    public class Handler_OnUpdate_Repair : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_OnUpdate_Repair()
        {
        }

        public Handler_OnUpdate_Repair(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_OnUpdate_Repair(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth >= 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "update":
                        primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_propertyid,mvh_predefjobid1,mvh_predefjobid2,mvh_predefjobid3,mvh_predefjobid4");

                        if (primaryentity["mvh_predefjobid1"] != null || primaryentity["mvh_predefjobid2"] != null || primaryentity["mvh_predefjobid3"] != null || primaryentity["mvh_predefjobid4"] != null)
                        {
                            // Create repairs
                            CreateRepairFromInspection(primaryentity.Value("mvh_propertyid"), primaryentity.Value("mvh_predefjobid1"), context.PrimaryEntityId.ToString());
                            CreateRepairFromInspection(primaryentity.Value("mvh_propertyid"), primaryentity.Value("mvh_predefjobid2"), context.PrimaryEntityId.ToString());
                            CreateRepairFromInspection(primaryentity.Value("mvh_propertyid"), primaryentity.Value("mvh_predefjobid3"), context.PrimaryEntityId.ToString());
                            CreateRepairFromInspection(primaryentity.Value("mvh_propertyid"), primaryentity.Value("mvh_predefjobid4"), context.PrimaryEntityId.ToString());

                            // Reset predef job fields
                            primaryentity.InitialiseSchema();
                            primaryentity.AddNull("mvh_predefjobid1");
                            primaryentity.AddNull("mvh_predefjobid2");
                            primaryentity.AddNull("mvh_predefjobid3");
                            primaryentity.AddNull("mvh_predefjobid4");
                            primaryentity.Update(context.PrimaryEntityId.ToString());
                        }
                        break;
                }
            }
        }

        private void CreateRepairFromInspection(string propertyid, string predefjobid, string inspectionid)
        {
            XRMHelper mvh_repairmodule = new XRMHelper(service, "mvh_repairmodule");

            if (propertyid != string.Empty && predefjobid != string.Empty)
            {
                mvh_repairmodule.AddLookup("mvh_propertyid", "mvh_properties", propertyid);
                mvh_repairmodule.AddLookup("mvh_predefinedjobid", "mvh_predefinedjob", predefjobid);
                mvh_repairmodule.AddLookup("mvh_inspectiontemplate_repairid", "mvh_repairmodule", inspectionid);
                mvh_repairmodule.AddDateTime("mvh_createdon", DateTime.Now);
                mvh_repairmodule.Create();
            }
        }
    }
}

