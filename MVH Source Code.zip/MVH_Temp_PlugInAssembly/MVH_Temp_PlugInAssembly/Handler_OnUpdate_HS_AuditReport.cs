﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    // 4.10	Calculate H&S Audit Scores
    // Step: Message=Update, Primary Entity=mvh_hs_auditreport, Attribute=mvh_completed

    public class Handler_OnUpdate_HS_AuditReport : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_OnUpdate_HS_AuditReport()
        {
        }

        public Handler_OnUpdate_HS_AuditReport(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_OnUpdate_HS_AuditReport(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth == 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "update":
                        primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_hs_inspectionid");
                        string mvh_hs_inspectionid = primaryentity.Value("mvh_hs_inspectionid").ToUpper();

                        if (mvh_hs_inspectionid != string.Empty)
                        {
                            int XER3 = 0;
                            int XER4 = 0;
                            int XER5 = 0;
                            int XES3 = 0;
                            int XES4 = 0;
                            int XES5 = 0;
                            int XET3 = 0;
                            int XET4 = 0;
                            int XET5 = 0;

                            StringBuilder fetchXML = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");
                            fetchXML.Append("<entity name=\"mvh_hs_auditreport\">");
                            fetchXML.Append("<attribute name=\"mvh_name\" />");
                            fetchXML.Append("<attribute name=\"mvh_hs_auditreportid\" />");
                            fetchXML.Append("<filter type=\"and\">");
                            fetchXML.Append("<condition attribute=\"mvh_hs_inspectionid\" operator=\"eq\" uitype=\"mvh_hs_inspection\" value=\"{GUID}\" />");
                            fetchXML.Append("<condition attribute=\"mvh_completed\" operator=\"eq\" value=\"YESNO\" />");
                            fetchXML.Append("<condition attribute=\"mvh_auditcategory\" operator=\"eq\" value=\"CATEGORY\" />");
                            fetchXML.Append("</filter>");
                            fetchXML.Append("</entity>");
                            fetchXML.Append("</fetch>");

                            string query = fetchXML.ToString();

                            // Yes / H&S
                            if (primaryentity.FetchEntityCollection(fetchXML.ToString().Replace("GUID", mvh_hs_inspectionid).Replace("YESNO", "916470000").Replace("CATEGORY", "916470000")))
                                XER3 = primaryentity.Results.Entities.Count;

                            // Yes / Env
                            if (primaryentity.FetchEntityCollection(fetchXML.ToString().Replace("GUID", mvh_hs_inspectionid).Replace("YESNO", "916470000").Replace("CATEGORY", "916470001")))
                                XER4 = primaryentity.Results.Entities.Count;

                            // No / H&S
                            if (primaryentity.FetchEntityCollection(fetchXML.ToString().Replace("GUID", mvh_hs_inspectionid).Replace("YESNO", "916470001").Replace("CATEGORY", "916470000")))
                                XES3 = primaryentity.Results.Entities.Count;

                            // No / Env
                            if (primaryentity.FetchEntityCollection(fetchXML.ToString().Replace("GUID", mvh_hs_inspectionid).Replace("YESNO", "916470001").Replace("CATEGORY", "916470001")))
                                XES4 = primaryentity.Results.Entities.Count;

                            XER5 = (XER3 + XER4);
                            XES5 = (XES3 + XES4);
                            XET3 = (XER3 + XES3);
                            XET4 = (XER4 + XES4);
                            XET5 = (XER5 + XES5);

                            int mvh_overallscore = 0;
                            int mvh_actionsraised_audit = XES5;
                            int mvh_hsscore = 0;
                            int mvh_environmentalscore = 0;

                            if (XET5 > 0)
                                mvh_overallscore = (XER5 / XET5);
                            if (XET3 > 0)
                                mvh_hsscore = (XER3 / XET3);
                            if (XET4 > 0)
                                mvh_environmentalscore = (XER4 / XET4);

                            XRMHelper mvh_hs_inspection = new XRMHelper(service, "mvh_hs_inspection");
                            mvh_hs_inspection.AddInteger("mvh_overallscore", mvh_overallscore.ToString());
                            mvh_hs_inspection.AddInteger("mvh_actionsraised", mvh_actionsraised_audit.ToString());
                            mvh_hs_inspection.AddInteger("mvh_hsscore", mvh_hsscore.ToString());
                            mvh_hs_inspection.AddInteger("mvh_environmentalscore", mvh_environmentalscore.ToString());
                            mvh_hs_inspection.Update(mvh_hs_inspectionid);
                        }

                        break;
                }
            }
        }
    }
}

