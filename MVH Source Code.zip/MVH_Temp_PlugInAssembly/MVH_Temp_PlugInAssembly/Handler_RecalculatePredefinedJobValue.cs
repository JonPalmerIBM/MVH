﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    // 4.5	Recalculate Predefined Job Value
    // Step: Message=Create + Update (mvh_linevalue, mvh_sorvalue, mvh_qty), Primary Entity=mvh_predefinedjobworksorderline

    public class Handler_RecalculatePredefinedJobValue : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_RecalculatePredefinedJobValue()
        {
        }

        public Handler_RecalculatePredefinedJobValue(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_RecalculatePredefinedJobValue(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth == 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "create":
                    case "update":
                        primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_predefinedjob");
                        if (primaryentity["mvh_predefinedjob"] != null)
                        {
                            string id = primaryentity.Value("mvh_predefinedjob");

                            // Retrieve predefined job works order lines and sum the line values
                            StringBuilder fetchXML = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");
                            fetchXML.Append("<entity name=\"mvh_predefinedjobworksorderline\">");
                            fetchXML.Append("<attribute name=\"mvh_linevalue\" />");
                            fetchXML.Append("<filter type=\"and\">");
                            fetchXML.AppendFormat("<condition attribute=\"mvh_predefinedjob\" operator=\"eq\" uitype=\"mvh_predefinedjob\" value=\"{0}\" />", id);
                            fetchXML.Append("<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />");
                            fetchXML.Append("</filter>");
                            fetchXML.Append("</entity>");
                            fetchXML.Append("</fetch>");

                            if (primaryentity.FetchEntityCollection(fetchXML.ToString()))
                            {
                                decimal mvh_totalcommittedcost = 0;
                                XRMHelper mvh_predefinedjobworksorderline = new XRMHelper(service);

                                foreach (Entity ent in primaryentity.Results.Entities)
                                {
                                    mvh_predefinedjobworksorderline.Retrieve(ent);
                                    if (mvh_predefinedjobworksorderline["mvh_linevalue"] != null)
                                        mvh_totalcommittedcost += Convert.ToDecimal(mvh_predefinedjobworksorderline.Value("mvh_linevalue"));
                                }

                                // Update the parent predefined job
                                XRMHelper mvh_predefinedjob = new XRMHelper(service, "mvh_predefinedjob");
                                mvh_predefinedjob.AddMoney("mvh_totalcommittedcost", mvh_totalcommittedcost);
                                mvh_predefinedjob.Update(id);
                            }
                        }
                        break;
                }
            }
        }
    }
}

