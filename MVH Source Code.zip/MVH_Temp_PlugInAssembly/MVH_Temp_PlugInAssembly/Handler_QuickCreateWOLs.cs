﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    // 4.14 Quick Create Repair Works Order Lines
    // Step: Message=Update (mvh_sorid1, mvh_sorid2, mvh_sorid3, mvh_sorid4), Primary Entity=mvh_repairmodule

    public class Handler_QuickCreateWOLs : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_QuickCreateWOLs()
        {
        }

        public Handler_QuickCreateWOLs(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_QuickCreateWOLs(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth >= 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "update":
                        bool woladded = false;
                        primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_sorid1,mvh_sorid2,mvh_sorid3,mvh_sorid4,mvh_qty1,mvh_qty2,mvh_qty3,mvh_qty4");

                        decimal mvh_qty1 = primaryentity["mvh_qty1"] == null ? 0 : Convert.ToDecimal(primaryentity.Value("mvh_qty1"));
                        decimal mvh_qty2 = primaryentity["mvh_qty2"] == null ? 0 : Convert.ToDecimal(primaryentity.Value("mvh_qty2"));
                        decimal mvh_qty3 = primaryentity["mvh_qty3"] == null ? 0 : Convert.ToDecimal(primaryentity.Value("mvh_qty3"));
                        decimal mvh_qty4 = primaryentity["mvh_qty4"] == null ? 0 : Convert.ToDecimal(primaryentity.Value("mvh_qty4"));

                        if (primaryentity["mvh_sorid1"] != null && mvh_qty1 != 0)
                        {
                            CreateWOL(context.PrimaryEntityId.ToString(), primaryentity.Value("mvh_sorid1"), primaryentity.FormattedValue("mvh_sorid1"), mvh_qty1);
                            woladded = true;
                        }
                        if (primaryentity["mvh_sorid2"] != null && mvh_qty2 != 0)
                        {
                            CreateWOL(context.PrimaryEntityId.ToString(), primaryentity.Value("mvh_sorid2"), primaryentity.FormattedValue("mvh_sorid2"), mvh_qty2);
                            woladded = true;
                        }
                        if (primaryentity["mvh_sorid3"] != null && mvh_qty3 != 0)
                        {
                            CreateWOL(context.PrimaryEntityId.ToString(), primaryentity.Value("mvh_sorid3"), primaryentity.FormattedValue("mvh_sorid3"), mvh_qty3);
                            woladded = true;
                        }
                        if (primaryentity["mvh_sorid4"] != null && mvh_qty4 != 0)
                        {
                            CreateWOL(context.PrimaryEntityId.ToString(), primaryentity.Value("mvh_sorid4"), primaryentity.FormattedValue("mvh_sorid4"), mvh_qty4);
                            woladded = true;
                        }

                        if (woladded)
                        {
                            primaryentity.InitialiseSchema();
                            primaryentity.AddNull("mvh_sorid1");
                            primaryentity.AddNull("mvh_sorid2");
                            primaryentity.AddNull("mvh_sorid3");
                            primaryentity.AddNull("mvh_sorid4");
                            primaryentity.AddNull("mvh_qty1");
                            primaryentity.AddNull("mvh_qty2");
                            primaryentity.AddNull("mvh_qty3");
                            primaryentity.AddNull("mvh_qty4");
                            primaryentity.Update(context.PrimaryEntityId.ToString());
                        }
                        break;
                }
            }
        }

        private void CreateWOL(string id, string sorid, string sorname, decimal qty)
        {
            XRMHelper mvh_sor = new XRMHelper(service, "mvh_sor");
            XRMHelper mvh_repairworksorderline = new XRMHelper(service, "mvh_repairworksorderline");

            if (mvh_sor.Retrieve(sorid, "mvh_value"))
            {
                if (mvh_sor["mvh_value"] != null)
                {
                    mvh_repairworksorderline.AddString("mvh_name", sorname);
                    mvh_repairworksorderline.AddLookup("mvh_repair", "mvh_repairmodule", id);
                    mvh_repairworksorderline.AddLookup("mvh_sor", "mvh_sor", sorid);
                    mvh_repairworksorderline.AddDecimal("mvh_qty", qty.ToString());
                    mvh_repairworksorderline.AddMoney("mvh_linevalue", (qty * Convert.ToDecimal(mvh_sor.Value("mvh_value"))));
                    mvh_repairworksorderline.AddMoney("mvh_sorvalue", mvh_sor.Value("mvh_value"));
                    mvh_repairworksorderline.Create();
                }
            }
        }
    }
}

