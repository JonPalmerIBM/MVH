﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    // 4.8	Create FRA Control Measures
    // Step: Message=Create, Primary Entity=mvh_fra_inspection

    public class Handler_OnCreate_FRAInspection : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_OnCreate_FRAInspection()
        {
        }

        public Handler_OnCreate_FRAInspection(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_OnCreate_FRAInspection(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth == 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "create":
                        // Retrieve all control measure records
                        StringBuilder fetchXML = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");
                        fetchXML.Append("<entity name=\"mvh_fra_controlmeasure\">");
                        fetchXML.Append("<attribute name=\"mvh_order\" />");
                        fetchXML.Append("<attribute name=\"mvh_fra_hazardid\" />");
                        fetchXML.Append("<attribute name=\"mvh_fra_controlmeasureid\" />");
                        fetchXML.Append("<order attribute=\"mvh_fra_hazardid\" descending=\"false\" />");
                        fetchXML.Append("<order attribute=\"mvh_order\" descending=\"false\" />");
                        fetchXML.Append("<filter type=\"and\">");
                        fetchXML.Append("<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />");
                        fetchXML.Append("</filter>");
                        fetchXML.Append("</entity>");
                        fetchXML.Append("</fetch>");

                        XRMHelper controlmeasures = new XRMHelper(service);
                        XRMHelper controlmeasureitem = new XRMHelper(service, "mvh_fra_controlmeasureitem");

                        if (controlmeasures.FetchEntityCollection(fetchXML.ToString()))
                        {
                            // Create control measure item records for this inspection
                            foreach (Entity ent in controlmeasures.Results.Entities)
                            {
                                controlmeasures.Retrieve(ent);
                                controlmeasureitem.InitialiseSchema();
                                controlmeasureitem.AddLookup("mvh_fra_inspectionid", "mvh_fra_inspection", context.PrimaryEntityId.ToString());
                                controlmeasureitem.AddLookup("mvh_fra_hazardid", "mvh_fra_hazrd", controlmeasures.Value("mvh_fra_hazardid"));
                                controlmeasureitem.AddLookup("mvh_fra_controlmeasureid", "mvh_fra_controlmeasure", controlmeasures.Value("mvh_fra_controlmeasureid"));
                                controlmeasureitem.AddInteger("mvh_order", controlmeasures.Value("mvh_order"));
                                controlmeasureitem.AddString("mvh_name", controlmeasures.FormattedValue("mvh_fra_controlmeasureid"), 100);
                                controlmeasureitem.Create();
                            }
                        }

                        break;
                }
            }
        }
    }
}

