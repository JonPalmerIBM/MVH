﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    /*
     * Message = Update
     * Primary Entity = mvh_repairmodule
     * Filtering Attributes = mvh_abandonreason
     * Execution Order = 1
     * Unsecure = 
     * Secure = 
    */

    public class Handler_AbandonWOLs : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_AbandonWOLs()
        {
        }

        public Handler_AbandonWOLs(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_AbandonWOLs(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth >= 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "update":
                        primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_abandonreason");

                        if (primaryentity["mvh_abandonreason"] != null)
                        {
                            // Retrieve works order lines 
                            StringBuilder fetchXML = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");
                            fetchXML.Append("<entity name=\"mvh_repairworksorderline\">");
                            fetchXML.Append("<attribute name=\"mvh_abandonreason\" />");
                            fetchXML.Append("<filter type=\"and\">");
                            fetchXML.AppendFormat("<condition attribute=\"mvh_repair\" operator=\"eq\" uitype=\"mvh_repairmodule\" value=\"{0}\" />", context.PrimaryEntityId.ToString());
                            fetchXML.Append("<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />");
                            fetchXML.Append("</filter>");
                            fetchXML.Append("</entity>");
                            fetchXML.Append("</fetch>");

                            if (primaryentity.FetchEntityCollection(fetchXML.ToString()))
                            {
                                XRMHelper mvh_repairworksorderline = new XRMHelper(service, "mvh_repairworksorderline");

                                // Set the abandon reason on each WOL to match that of the repair
                                foreach (Entity ent in primaryentity.Results.Entities)
                                {
                                    mvh_repairworksorderline.InitialiseSchema();
                                    mvh_repairworksorderline.AddPicklist("mvh_abandonreason", primaryentity.Value("mvh_abandonreason"));
                                    mvh_repairworksorderline.Update(ent.Id.ToString());
                                }
                            }
                        }
                        break;
                }
            }
        }
    }
}

