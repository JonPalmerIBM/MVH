﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    // 4.13 Update Repair Appointment Slot
    // Step: Message=Create, Update (mvh_appointmentslotid), Primary Entity=mvh_repairmodule

    public class Handler_UpdateRepairAppointmentSlot : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_UpdateRepairAppointmentSlot()
        {
        }

        public Handler_UpdateRepairAppointmentSlot(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_UpdateRepairAppointmentSlot(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth >= 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "create":
                    case "update":
                        primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_appointmentslotid");
                        if (primaryentity["mvh_appointmentslotid"] != null)
                        {
                            XRMHelper mvh_appointmentslot = new XRMHelper(service, "mvh_appointmentslot");

                            // Remove this repair from any existing slots
                            StringBuilder xml = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");

                            xml.Append("<entity name=\"mvh_appointmentslot\">");
                            xml.Append("<attribute name=\"mvh_name\" />");
                            xml.Append("<filter type=\"and\">");
                            xml.AppendFormat("<condition attribute=\"mvh_repairmoduleid\" operator=\"eq\" uitype=\"mvh_repairmodule\" value=\"{0}\" />", context.PrimaryEntityId.ToString());
                            xml.Append("</filter>");
                            xml.Append("</entity>");
                            xml.Append("</fetch>");

                            if (primaryentity.FetchEntityCollection(xml.ToString()))
                            {
                                foreach (Entity ent in primaryentity.Results.Entities)
                                {
                                    mvh_appointmentslot.InitialiseSchema();
                                    mvh_appointmentslot.AddNull("mvh_repairmoduleid");
                                    mvh_appointmentslot.Update(ent.Id.ToString());
                                }
                            }

                            // Assign this repair to the slot so it doesn't appear in the list of available slots
                            mvh_appointmentslot.InitialiseSchema();
                            mvh_appointmentslot.AddLookup("mvh_repairmoduleid", "mvh_repairmodule", context.PrimaryEntityId.ToString());
                            mvh_appointmentslot.Update(primaryentity.Value("mvh_appointmentslotid"));
                        }
                        break;
                }
            }
        }
    }
}

