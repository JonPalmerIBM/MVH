﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    // 4.12	Create appointment slot from inspection calendar entry
    // Step: Message=Create, Primary Entity=mvh_inspectioncalendar

    public class Handler_CreateAppointmentSlot : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_CreateAppointmentSlot()
        {
        }

        public Handler_CreateAppointmentSlot(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_CreateAppointmentSlot(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth >= 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "create":
                        primaryentity.Retrieve(context.PrimaryEntityId.ToString());

                        XRMHelper mvh_appointmentslot = new XRMHelper(service, "mvh_appointmentslot");
                        DateTime date = primaryentity.Date("mvh_date");
                        int[] amslots = new int[5];
                        int[] pmslots = new int[5];

                        amslots[0] = Convert.ToInt32(primaryentity.Value("mvh_amslots"));
                        amslots[1] = Convert.ToInt32(primaryentity.Value("mvh_tueam"));
                        amslots[2] = Convert.ToInt32(primaryentity.Value("mvh_wedam"));
                        amslots[3] = Convert.ToInt32(primaryentity.Value("mvh_thuam"));
                        amslots[4] = Convert.ToInt32(primaryentity.Value("mvh_friam"));

                        pmslots[0] = Convert.ToInt32(primaryentity.Value("mvh_pmslots"));
                        pmslots[1] = Convert.ToInt32(primaryentity.Value("mvh_tuepm"));
                        pmslots[2] = Convert.ToInt32(primaryentity.Value("mvh_wedpm"));
                        pmslots[3] = Convert.ToInt32(primaryentity.Value("mvh_thupm"));
                        pmslots[4] = Convert.ToInt32(primaryentity.Value("mvh_fripm"));
                    
                        for (int slot = 0;slot <= 4;slot++)
                        {
                            if (amslots[slot] > 0)
                            {
                                for (int am = 1; am <= amslots[slot]; am++)
                                {
                                    mvh_appointmentslot.InitialiseSchema();
                                    mvh_appointmentslot.AddString("mvh_name", string.Format("{0} {1} AM{2}",
                                        date.ToString("d MMM yyyy"),
                                        primaryentity.FormattedValue("mvh_inspector_systemuserid"),
                                        am.ToString()));
                                    mvh_appointmentslot.AddDateTime("mvh_date", date);
                                    mvh_appointmentslot.AddLookup("mvh_inspector_systemuserid", "systemuser", primaryentity.Value("mvh_inspector_systemuserid"));
                                    mvh_appointmentslot.AddPicklist("mvh_slot", "916470000");
                                    mvh_appointmentslot.Create();
                                }
                            }
                            if (pmslots[slot] > 0)
                            {
                                for (int pm = 1; pm <= pmslots[slot]; pm++)
                                {
                                    mvh_appointmentslot.InitialiseSchema();
                                    mvh_appointmentslot.AddString("mvh_name", string.Format("{0} {1} PM{2}",
                                        date.ToString("d MMM yyyy"),
                                        primaryentity.FormattedValue("mvh_inspector_systemuserid"),
                                        pm.ToString()));
                                    mvh_appointmentslot.AddDateTime("mvh_date", date);
                                    mvh_appointmentslot.AddLookup("mvh_inspector_systemuserid", "systemuser", primaryentity.Value("mvh_inspector_systemuserid"));
                                    mvh_appointmentslot.AddPicklist("mvh_slot", "916470001");
                                    mvh_appointmentslot.Create();
                                }
                            }
                            date = date.AddDays(1);
                        }
                        break;
                    case "createX":
                        //primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_date,mvh_inspector_systemuserid,mvh_amslots,mvh_pmslots");
                        //int amslots = Convert.ToInt32(primaryentity.Value("mvh_amslots"));
                        //int pmslots = Convert.ToInt32(primaryentity.Value("mvh_pmslots"));

                        //XRMHelper mvh_appointmentslot = new XRMHelper(service, "mvh_appointmentslot");

                        //if (amslots > 0)
                        //{
                        //    for (int i = 1;i <= amslots;i++)
                        //    {
                        //        mvh_appointmentslot.InitialiseSchema();
                        //        mvh_appointmentslot.AddString("mvh_name", string.Format("{0} {1} AM{2}",
                        //            primaryentity.Date("mvh_date").ToString("d MMM yyyy"),
                        //            primaryentity.FormattedValue("mvh_inspector_systemuserid"),
                        //            i.ToString()));
                        //        mvh_appointmentslot.AddDateTime("mvh_date", primaryentity.Value("mvh_date"));
                        //        mvh_appointmentslot.AddLookup("mvh_inspector_systemuserid", "systemuser", primaryentity.Value("mvh_inspector_systemuserid"));
                        //        mvh_appointmentslot.AddPicklist("mvh_slot", "916470000");                                
                        //        mvh_appointmentslot.Create();
                        //    }
                        //}

                        //if (pmslots > 0)
                        //{
                        //    for (int i = 1; i <= pmslots; i++)
                        //    {
                        //        mvh_appointmentslot.InitialiseSchema();
                        //        mvh_appointmentslot.AddString("mvh_name", string.Format("{0} {1} PM{2}",
                        //            primaryentity.Date("mvh_date").ToString("d MMM yyyy"),
                        //            primaryentity.FormattedValue("mvh_inspector_systemuserid"),
                        //            i.ToString()));
                        //        mvh_appointmentslot.AddDateTime("mvh_date", primaryentity.Value("mvh_date"));
                        //        mvh_appointmentslot.AddLookup("mvh_inspector_systemuserid", "systemuser", primaryentity.Value("mvh_inspector_systemuserid"));
                        //        mvh_appointmentslot.AddPicklist("mvh_slot", "916470001");
                        //        mvh_appointmentslot.Create();
                        //    }
                        //}
                        break;
                }
            }
        }
    }
}

