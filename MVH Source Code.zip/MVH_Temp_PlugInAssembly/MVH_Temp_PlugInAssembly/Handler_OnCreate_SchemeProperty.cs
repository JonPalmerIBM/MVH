﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Temp_PlugInAssembly
{
    // 4.1	Create a Scheme Property
    // Step: Message=Create, Primary Entity=mvh_schemeproperty

    public class Handler_OnCreate_SchemeProperty : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_OnCreate_SchemeProperty()
        {
        }

        public Handler_OnCreate_SchemeProperty(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_OnCreate_SchemeProperty(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName, context.PrimaryEntityId);
            config = ConfigHelper.Retrieve(secure);

            if (context.Depth == 1)
            {
                switch (context.MessageName.ToLower())
                {
                    case "create":
                        primaryentity.Retrieve(context.PrimaryEntityId.ToString(), "mvh_scheme,mvh_property,mvh_ownerid");
                        string mvh_scheme = primaryentity.Value("mvh_scheme");
                        string mvh_property = primaryentity.Value("mvh_property");
                        string mvh_ownerid = primaryentity.Value("mvh_ownerid");

                        // Retrieve all non-null fields from the scheme repair so they can be cloned
                        XRMHelper repair = new XRMHelper(service, "mvh_repairmodule");
                        if (repair.Retrieve(mvh_scheme))
                        {
                            string mvh_predefinedjobid = repair.Value("mvh_predefinedjobid");

                            // Clone this repair, excluding the repair number, predefined job and scheme template field values
                            repair.CloneAttributes("mvh_name,mvh_predefinedjobid,mvh_propertyid,mvh_schemetemplate_repairid,mvh_stage");

                            if (repair.CreateClone())
                            {
                                // Set owner
                                if (mvh_ownerid != string.Empty)
                                {
                                    repair.schema.Id = repair.clone.Id;
                                    repair.SetOwner(mvh_ownerid);
                                }

                                // After creating the cloned record, add some values back in
                                repair.InitialiseSchema();
                                repair.AddLookup("mvh_propertyid", "mvh_properties", mvh_property);
                                repair.AddLookup("mvh_schemetemplate_repairid", "mvh_repairmodule", mvh_scheme);
                                repair.AddLookup("mvh_predefinedjobid", "mvh_predefinedjob", mvh_predefinedjobid);
                                repair.Update(repair.clone.Id.ToString());

                                // Link the new repair to the scheme property record
                                primaryentity.InitialiseSchema();
                                primaryentity.AddLookup("mvh_repairmoduleid", "mvh_repairmodule", repair.clone.Id.ToString());
                                primaryentity.Update(context.PrimaryEntityId.ToString());

                                // Retrieve the works order lines linked to the original scheme repair
                                StringBuilder fetchXML = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");
                                fetchXML.Append("<entity name=\"mvh_repairworksorderline\">");
                                fetchXML.Append("<attribute name=\"mvh_name\" />");
                                fetchXML.Append("<filter type=\"and\">");
                                fetchXML.AppendFormat("<condition attribute=\"mvh_repair\" operator=\"eq\" uitype=\"mvh_repairmodule\" value=\"{0}\" />", mvh_scheme);
                                fetchXML.Append("<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />");
                                fetchXML.Append("</filter>");
                                fetchXML.Append("</entity>");
                                fetchXML.Append("</fetch>");

                                if (primaryentity.FetchEntityCollection(fetchXML.ToString()))
                                {
                                    // Clone the works order lines
                                    XRMHelper mvh_repairworksorderline;
                                    foreach (Entity ent in primaryentity.Results.Entities)
                                    {
                                        mvh_repairworksorderline = new XRMHelper(service, "mvh_repairworksorderline");
                                        mvh_repairworksorderline.Retrieve(ent.Id.ToString());

                                        mvh_repairworksorderline.CloneAttributes("mvh_repair");
                                        mvh_repairworksorderline.CreateClone();

                                        // Reparent cloned works order line
                                        mvh_repairworksorderline.InitialiseSchema();
                                        mvh_repairworksorderline.AddLookup("mvh_repair", "mvh_repairmodule", repair.clone.Id.ToString());
                                        mvh_repairworksorderline.Update(mvh_repairworksorderline.clone.Id.ToString());
                                    }
                                }
                            }
                        }
                        break;
                }
            }
        }
    }
}

