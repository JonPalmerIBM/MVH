﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;
using System.Web;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Crm.Sdk.Messages;

public class XRMAttributeHelper
{
    public string Name = string.Empty;
    public string Value = string.Empty;
    public string FormattedValue = string.Empty;
    public string Time = string.Empty;
    public string LookupType = string.Empty;
    public DateTime Date;
    public EntityCollection Party;

    public XRMAttributeHelper(string name)
    {
        Name = name;
    }
}

public class XRMHelper : IDisposable
{
    public IOrganizationService Service;
    public Entity schema;
    public Entity clone;
    public List<XRMAttributeHelper> Attributes = new List<XRMAttributeHelper>();
    public EntityCollection Results;

    public string Type = string.Empty;
    public string ConnectionString = string.Empty;
    public string Message = string.Empty;
    public string annotationid = string.Empty;
    public string activitymimeattachmentid = string.Empty;

    bool disposed = false;

    public XRMHelper(IOrganizationService service)
    {
        Service = service;
    }

    public XRMHelper(IOrganizationService service, string type)
    {
        Service = service;
        Type = type;

        schema = new Entity(Type);
    }

    public XRMHelper(IOrganizationService service, string type, Guid id)
    {
        Service = service;
        Type = type;

        schema = new Entity(Type);
        schema.Id = id;
    }

    public IOrganizationService ConnectToService()
    {
        return Service;
    }

    public void InitialiseSchema()
    {
        schema = new Entity(Type);
    }

    public void InitialiseSchema(string type)
    {
        Type = type;
        schema = new Entity(Type);
    }

    [System.Runtime.CompilerServices.IndexerName("XRMAttributeHelper")]
    public XRMAttributeHelper this[int index]
    {
        get
        {
            return Attributes[index];
        }
    }

    [System.Runtime.CompilerServices.IndexerName("XRMAttributeHelper")]
    public XRMAttributeHelper this[string name]
    {
        get
        {
            foreach (XRMAttributeHelper attr in Attributes)
            {
                if (attr.Name == name)
                    return attr;
            }
            return null;
        }
    }

    public bool IsNull(string name)
    {
        if (this[name] == null)
            return true;
        else
            return false;
    }

    public string Value(string name)
    {
        if (this[name] == null)
            return string.Empty;
        else
            return this[name].Value;
    }

    public string FormattedValue(string name)
    {
        if (this[name] == null)
            return string.Empty;
        else
            return this[name].FormattedValue;
    }

    public string LookupType(string name)
    {
        if (this[name] == null)
            return string.Empty;
        else
            return this[name].LookupType;
    }

    public bool BooleanValue(string name)
    {
        if (Value(name).ToLower() == "true")
            return true;
        else
            return false;
    }

    public string Time(string name)
    {
        if (this[name] == null)
            return string.Empty;
        else
            return this[name].Time;
    }

    public DateTime Date(string name)
    {
        if (this[name] == null)
            return DateTime.Now;
        else
            return this[name].Date;
    }

    private string FormatExceptionMessage(System.Exception ex)
    {
        StringBuilder message = new StringBuilder("(Exception) ");

        message.Append(ex.Message);

        if (ex.InnerException != null)
        {
            message.Append(" (InnerException) ");
            message.Append(ex.InnerException.Message);
            FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> fe = ex.InnerException
                as FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault>;
            if (fe != null)
            {
                message.Append("(FaultException) ");
                message.Append(fe.Detail.ErrorCode);
                message.Append(" ");
                message.Append(fe.Detail.Message);
            }
        }

        return message.ToString();
    }

    public bool Retrieve(string id)
    {
        return Retrieve(Type, id, string.Empty);
    }

    public bool Retrieve(string id, string cols)
    {
        return Retrieve(Type, id, cols);
    }

    public bool Retrieve(string type, string id, string cols)
    {
        Attributes.Clear();
        Type = type;

        try
        {
            IOrganizationService service = ConnectToService();
            XRMAttributeHelper attr;
            ColumnSet cset;

            if (cols == string.Empty)
                cset = new ColumnSet(true);
            else
                cset = new ColumnSet(cols.Split(','));

            schema = service.Retrieve(Type, new Guid(id), cset);

            foreach (string key in schema.Attributes.Keys)
            {
                attr = new XRMAttributeHelper(key);
                attr.Value = schema.Attributes[key].ToString();
                // Formatted value?
                if (schema.FormattedValues.Contains(key))
                    attr.FormattedValue = schema.FormattedValues[key];
                else
                    attr.FormattedValue = attr.Value;
                // Lookup?
                if (schema.Attributes[key] is Microsoft.Xrm.Sdk.EntityReference)
                {
                    attr.Value = ((Microsoft.Xrm.Sdk.EntityReference)schema.Attributes[key]).Id.ToString();
                    attr.FormattedValue = ((Microsoft.Xrm.Sdk.EntityReference)schema.Attributes[key]).Name;
                    attr.LookupType = ((Microsoft.Xrm.Sdk.EntityReference)schema.Attributes[key]).LogicalName;
                }
                // Picklist?
                if (schema.Attributes[key] is Microsoft.Xrm.Sdk.OptionSetValue)
                {
                    attr.Value = ((Microsoft.Xrm.Sdk.OptionSetValue)schema.Attributes[key]).Value.ToString();
                }
                // Money?
                if (schema.Attributes[key] is Microsoft.Xrm.Sdk.Money)
                {
                    attr.Value = ((Microsoft.Xrm.Sdk.Money)schema.Attributes[key]).Value.ToString();
                }
                // Date?
                if (schema.Attributes[key] is DateTime)
                {
                    attr.Value = ((DateTime)schema.Attributes[key]).ToLocalTime().ToShortDateString();
                    attr.Time = ((DateTime)schema.Attributes[key]).ToLocalTime().ToShortTimeString();
                    attr.Date = ((DateTime)schema.Attributes[key]).ToLocalTime();
                }
                // EntityCollection?
                if (schema.Attributes[key] is EntityCollection)
                {
                    attr.Party = (EntityCollection)schema.Attributes[key];
                }
                Attributes.Add(attr);
            }
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("Retrieve");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("Retrieve");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("Retrieve");
            return false;
        }

        return true;
    }

    public bool Retrieve(Entity entity)
    {
        Attributes.Clear();

        try
        {
            XRMAttributeHelper attr;

            schema = entity;

            foreach (string key in schema.Attributes.Keys)
            {
                attr = new XRMAttributeHelper(key);
                attr.Value = schema.Attributes[key].ToString();
                // Formatted value?
                if (schema.FormattedValues.Contains(key))
                    attr.FormattedValue = schema.FormattedValues[key];
                // Lookup?
                if (schema.Attributes[key] is Microsoft.Xrm.Sdk.EntityReference)
                {
                    attr.Value = ((Microsoft.Xrm.Sdk.EntityReference)schema.Attributes[key]).Id.ToString();
                    attr.FormattedValue = ((Microsoft.Xrm.Sdk.EntityReference)schema.Attributes[key]).Name;
                }
                // Picklist?
                if (schema.Attributes[key] is Microsoft.Xrm.Sdk.OptionSetValue)
                {
                    attr.Value = ((Microsoft.Xrm.Sdk.OptionSetValue)schema.Attributes[key]).Value.ToString();
                }
                // Money?
                if (schema.Attributes[key] is Microsoft.Xrm.Sdk.Money)
                {
                    attr.Value = ((Microsoft.Xrm.Sdk.Money)schema.Attributes[key]).Value.ToString();
                }
                // Date?
                if (schema.Attributes[key] is DateTime)
                {
                    attr.Value = ((DateTime)schema.Attributes[key]).ToLocalTime().ToShortDateString();
                    attr.Time = ((DateTime)schema.Attributes[key]).ToLocalTime().ToShortTimeString();
                    attr.Date = ((DateTime)schema.Attributes[key]).ToLocalTime();
                }
                // EntityCollection?
                if (schema.Attributes[key] is EntityCollection)
                {
                    attr.Party = (EntityCollection)schema.Attributes[key];
                }
                // Aliased value
                if (schema.Attributes[key] is AliasedValue)
                {
                    attr.FormattedValue = ((AliasedValue)schema.Attributes[key]).Value.ToString();
                }
                Attributes.Add(attr);
            }
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("Retrieve");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("Retrieve");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("Retrieve");
            return false;
        }

        return true;
    }

    public bool Create()
    {
        try
        {
            IOrganizationService service = ConnectToService();
            schema.Id = service.Create(schema);
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("Create");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("Create");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("Create");
            return false;
        }

        return true;
    }

    public bool CloneAttributes(string exclude)
    {
        exclude += "," + Type + "id,ownerid,createdby,modifiedby,createdonbehlafby,modifiedonbehalfby,owningbusinessunit,owningteam,owninguser,statecode,statuscode";

        exclude = exclude.ToLower();

        try
        {
            IOrganizationService service = ConnectToService();
            clone = new Entity(Type);

            foreach (string key in schema.Attributes.Keys)
            {
                if (!exclude.Contains(key.ToLower()))
                    clone[key] = schema.Attributes[key];
            }
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("Clone");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("Clone");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("Clone");
            return false;
        }

        return true;
    }

    public bool CreateClone()
    {
        try
        {
            IOrganizationService service = ConnectToService();
            clone.Id = service.Create(clone);
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("CreateClone");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("CreateClone");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("CreateClone");
            return false;
        }

        return true;
    }

    public bool Update()
    {
        return Update(schema.Id.ToString());
    }

    public bool Update(string id)
    {
        try
        {
            IOrganizationService service = ConnectToService();
            schema.Id = new Guid(id);
            service.Update(schema);
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("Update");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("Update");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("Update");
            return false;
        }

        return true;
    }

    public bool Delete()
    {
        return Delete(Type, schema.Id.ToString());
    }

    public bool Delete(string id)
    {
        return Delete(Type, id);
    }

    public bool Delete(string type, string id)
    {
        if (id != string.Empty)
        {
            try
            {
                IOrganizationService service = ConnectToService();
                service.Delete(type, new Guid(id));
            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
                LogException("Delete");
                return false;
            }
            catch (System.TimeoutException ex)
            {
                Message = "(TimeoutException) " + ex.Message;
                LogException("Delete");
                return false;
            }
            catch (System.Exception ex)
            {
                Message = FormatExceptionMessage(ex);
                LogException("Delete");
                return false;
            }
        }

        return true;
    }

    public void AddNull(string attribute)
    {
        schema[attribute] = null;
    }

    public void AddString(string attribute, string value)
    {
        schema[attribute] = value;
    }

    public void AddString(string attribute, string value, int maxlen)
    {
        if (value.Length > maxlen)
            schema[attribute] = value.Substring(0, maxlen);
        else
            schema[attribute] = value;
    }

    public void AddBoolean(string attribute, string value)
    {
        switch (value.ToLower())
        {
            case "1":
            case "yes":
            case "true":
                schema[attribute] = true;
                break;
            default:
                schema[attribute] = false;
                break;
        }
    }

    public void AddBoolean(string attribute, bool value)
    {
        schema[attribute] = value;
    }

    public void AddPicklist(string attribute, string value)
    {
        if (value != string.Empty)
            schema[attribute] = new OptionSetValue(Convert.ToInt32(value));
        else
            schema[attribute] = null;
    }

    public void AddMoney(string attribute, string value)
    {
        if (value != string.Empty)
            schema[attribute] = new Money(Convert.ToDecimal(value));
    }

    public void AddMoney(string attribute, decimal value)
    {
        schema[attribute] = new Money(value);
    }

    public void AddLookup(string attribute, string entitytypename, string value)
    {
        if (value != string.Empty)
            schema[attribute] = new EntityReference(entitytypename, new Guid(value));
    }

    public void AddPartyList(string attribute, string entitytypename, string value)
    {
        if (value != string.Empty)
        {
            EntityCollection partylist = new EntityCollection();
            Entity party = new Entity("activityparty");
            party["partyid"] = new EntityReference(entitytypename, new Guid(value));
            partylist.Entities.Add(party);
            schema[attribute] = partylist;
        }
    }

    public void AddPartyList(string attribute, EntityCollection partylist)
    {
        if (partylist.Entities.Count > 0)
            schema[attribute] = partylist;
    }

    public void AddDateTime(string attribute, string value)
    {
        if (value != string.Empty)
            schema[attribute] = Convert.ToDateTime(value);
    }

    public void AddDateTime(string attribute, DateTime value)
    {
        schema[attribute] = value;
    }

    public void AddInteger(string attribute, string value)
    {
        if (value != string.Empty)
            schema[attribute] = Convert.ToInt32(value);
    }

    public void AddSingle(string attribute, string value)
    {
        if (value != string.Empty)
            schema[attribute] = Convert.ToSingle(value);
    }

    public void AddDecimal(string attribute, string value)
    {
        if (value != string.Empty)
            schema[attribute] = Convert.ToDecimal(value);
    }

    public bool AttachNote(string subject, string text)
    {
        try
        {
            IOrganizationService service = ConnectToService();
            Entity annotation = new Entity("annotation");

            annotation["objectid"] = new EntityReference(Type, schema.Id);
            annotation["objecttypecode"] = Type;
            annotation["notetext"] = text;

            if (subject != string.Empty)
                annotation["subject"] = subject;

            annotationid = string.Empty;
            annotationid = service.Create(annotation).ToString();
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("AttachNote");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("AttachNote");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("AttachNote");
            return false;
        }

        return true;
    }

    public bool AttachFile(string filename, string mimetype, System.IO.Stream attachment)
    {
        return AttachFile(filename, mimetype, attachment, string.Empty);
    }

    public bool AttachFile(string filename, string mimetype, System.IO.Stream attachment, string notetext)
    {
        try
        {
            IOrganizationService service = ConnectToService();
            Entity annotation = new Entity("annotation");
            byte[] byteData = new byte[attachment.Length];

            annotation["objectid"] = new EntityReference(Type, schema.Id);
            annotation["objecttypecode"] = Type;
            annotation["subject"] = "MySSSC document upload";
            annotation["filename"] = filename;
            annotation["mimetype"] = mimetype;
            if (notetext != string.Empty)
                annotation["notetext"] = notetext;

            // Encode the data using base64.
            attachment.Read(byteData, 0, byteData.Length);
            annotation["documentbody"] = System.Convert.ToBase64String(byteData);

            annotationid = string.Empty;
            annotationid = service.Create(annotation).ToString();
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("AttachFile");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("AttachFile");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("AttachFile");
            return false;
        }

        return true;
    }

    public bool AttachFile(string filename, string mimetype, string attachment)
    {
        try
        {
            IOrganizationService service = ConnectToService();
            Entity annotation = new Entity("annotation");
            byte[] byteData = new byte[attachment.Length];

            annotation["objectid"] = new EntityReference(Type, schema.Id);
            annotation["objecttypecode"] = Type;
            annotation["subject"] = "File Attachment";
            annotation["filename"] = filename;
            annotation["mimetype"] = mimetype;
            annotation["documentbody"] = attachment;

            annotationid = string.Empty;
            annotationid = service.Create(annotation).ToString();
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("AttachFile");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("AttachFile");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("AttachFile");
            return false;
        }

        return true;
    }

    public byte[] DownloadAttachment()
    {
        try
        {
            return Convert.FromBase64String(this.Value("documentbody"));
        }
        catch (System.Exception ex)
        {
            Message = ex.Message;
            LogException("DownloadAttachment");
            return new byte[1];
        }
    }

    public bool AddEmailAttachment(string filename, string mimetype, string attachment)
    {
        try
        {
            IOrganizationService service = ConnectToService();
            Entity mimeattachment = new Entity("activitymimeattachment");
            byte[] byteData = new byte[attachment.Length];

            mimeattachment["objectid"] = new EntityReference(Type, schema.Id);
            mimeattachment["objecttypecode"] = Type;
            mimeattachment["subject"] = "Mime Attachment";
            mimeattachment["filename"] = filename;
            mimeattachment["mimetype"] = mimetype;
            mimeattachment["body"] = attachment;

            activitymimeattachmentid = string.Empty;
            activitymimeattachmentid = service.Create(mimeattachment).ToString();
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("AddEmailAttachment");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("AddEmailAttachment");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("AddEmailAttachment");
            return false;
        }

        return true;
    }

    public bool AssignToQueue(string id, string queueid)
    {
        try
        {
            IOrganizationService service = ConnectToService();
            AddToQueueRequest addToSourceQueue = new AddToQueueRequest
            {
                DestinationQueueId = new Guid(queueid),
                Target = new EntityReference(Type, new Guid(id))
            };

            service.Execute(addToSourceQueue);
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("AssignToQueue");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("AssignToQueue");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("AssignToQueue");
            return false;
        }

        return true;
    }

    public bool SetOwner(string systemuserid)
    {
        try
        {
            IOrganizationService service = ConnectToService();
            AssignRequest assign = new AssignRequest
            {
                Assignee = new EntityReference("systemuser", new Guid(systemuserid)),
                Target = new EntityReference(Type, schema.Id)
            };

            service.Execute(assign);
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("SetOwner");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("SetOwner");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("SetOwner");
            return false;
        }

        return true;
    }

    public bool SetTeamOwner(string teamid)
    {
        try
        {
            IOrganizationService service = ConnectToService();
            AssignRequest assign = new AssignRequest
            {
                Assignee = new EntityReference("team", new Guid(teamid)),
                Target = new EntityReference(Type, schema.Id)
            };

            service.Execute(assign);
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("SetTeamOwner");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("SetTeamOwner");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("SetTeamOwner");
            return false;
        }

        return true;
    }

    public bool SetState(string statecode, string statuscode)
    {
        try
        {
            if (statecode != string.Empty && statuscode != string.Empty)
            {
                IOrganizationService service = ConnectToService();
                SetStateRequest setStateRequest = new SetStateRequest()
                {
                    EntityMoniker = new EntityReference
                    {
                        Id = schema.Id,
                        LogicalName = Type,
                    },
                    State = new OptionSetValue(Convert.ToInt32(statecode)),
                    Status = new OptionSetValue(Convert.ToInt32(statuscode))
                };
                service.Execute(setStateRequest);
            }
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("SetState");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("SetState");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("SetState");
            return false;
        }

        return true;
    }

    public bool Resolve(string id, string subject, string description)
    {
        try
        {
            IOrganizationService service = ConnectToService();

            schema.Attributes.Add("incidentid", new EntityReference("incident", new Guid(id)));
            schema.Attributes.Add("subject", subject);
            schema.Attributes.Add("description", description);

            CloseIncidentRequest req = new CloseIncidentRequest();
            req.IncidentResolution = schema;
            req.RequestName = "CloseIncident";
            OptionSetValue optionsetvalue = new OptionSetValue();
            optionsetvalue.Value = 5;
            req.Status = optionsetvalue;

            CloseIncidentResponse resp = (CloseIncidentResponse)service.Execute(req);
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("Resolve");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("Resolve");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("Resolve");
            return false;
        }

        return true;
    }

    public bool AssociateEntities(string etn1, string id1, string etn2, string id2, string relationshipname)
    {
        try
        {
            IOrganizationService service = ConnectToService();
            EntityReferenceCollection relatedEntities = new EntityReferenceCollection();
            Relationship relationship = new Relationship(relationshipname);

            relatedEntities.Add(new EntityReference(etn2, new Guid(id2)));
            service.Associate(etn1, new Guid(id1), relationship, relatedEntities);
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("AssociateEntities");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("AssociateEntities");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("AssociateEntities");
            return false;
        }

        return true;
    }

    public bool AddListMember(string listid, string entityid)
    {
        try
        {
            IOrganizationService service = ConnectToService();
            AddMemberListRequest req = new AddMemberListRequest();

            req.ListId = new Guid(listid);
            req.EntityId = new Guid(entityid);

            service.Execute(req);
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("AddListMember");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("AddListMember");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("AddListMember");
            return false;
        }

        return true;
    }

    public string Qualify(string leadid)
    {
        string contactid = string.Empty;

        try
        {
            IOrganizationService service = ConnectToService();
            QualifyLeadRequest qlrequest = new QualifyLeadRequest();
            QualifyLeadResponse qlresponse = new QualifyLeadResponse();

            qlrequest.CreateAccount = false;
            qlrequest.CreateContact = true;
            qlrequest.CreateOpportunity = false;
            qlrequest.LeadId = new EntityReference("lead", new Guid(leadid));
            qlrequest.Status = new OptionSetValue(3);

            qlresponse = (QualifyLeadResponse)service.Execute(qlrequest);
            contactid = qlresponse.CreatedEntities[0].Id.ToString();
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("Qualify");
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("Qualify");
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("Qualify");
        }

        return contactid;
    }

    public bool Send(bool create, string trackingtoken)
    {
        try
        {
            IOrganizationService service = ConnectToService();
            SendEmailRequest request = new SendEmailRequest();

            // Create the email record
            if (create)
                schema.Id = service.Create(schema);

            // Send it
            request.EmailId = schema.Id;
            request.IssueSend = true;
            request.TrackingToken = trackingtoken;

            service.Execute(request);
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("SendEmail");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("SendEmail");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("SendEmail");
            return false;
        }

        return true;
    }

    public string EntityGUID(string field, string value)
    {
        return EntityGUID(Type + "id", field, value);
    }

    public string EntityGUID(string pk, string field, string value)
    {
        try
        {
            IOrganizationService service = ConnectToService();
            QueryByAttribute querybyattribute = new QueryByAttribute(Type);

            querybyattribute.ColumnSet = new ColumnSet(pk);
            querybyattribute.Attributes.AddRange(field);
            querybyattribute.Values.AddRange(value);

            Results = service.RetrieveMultiple(querybyattribute);

            if (Results.Entities.Count > 0)
            {
                return ((System.Guid)Results.Entities[0].Attributes[pk]).ToString();
            }
            else
            {
                return string.Empty;
            }
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            // Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message + " (" + ex.Detail.InnerFault.Message + ")";
            LogException("EntityGUID");
            return string.Empty;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("EntityGUID");
            return string.Empty;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("EntityGUID");
            return string.Empty;
        }
    }

    private void LogException(string function)
    {

    }

    public string ToHTML()
    {
        StringBuilder ent = new StringBuilder(string.Empty);

        foreach (XRMAttributeHelper attr in this.Attributes)
        {
            ent.Append("<p><strong>");
            ent.Append(attr.Name);
            ent.Append("</strong></p><ul>");
            ent.Append("<li>Value: [");
            ent.Append(attr.Value);
            ent.Append("]</li>");
            ent.Append("<li>FormattedValue: [");
            ent.Append(attr.FormattedValue);
            ent.Append("]</li>");
            ent.Append("<li>Date: [");
            ent.Append(attr.Date);
            ent.Append("]</li>");
            ent.Append("<li>Time: [");
            ent.Append(attr.Time);
            ent.Append("]</li>");
            ent.Append("</ul>");
        }

        return ent.ToString();
    }

    public bool FetchEntityCollection(string query)
    {
        if (query == string.Empty || query == null)
            return false;

        try
        {
            IOrganizationService service = ConnectToService();
            Results = service.RetrieveMultiple(new FetchExpression(query));
            return true;
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message + " (" + ((ex.Detail.InnerFault != null) ? ex.Detail.InnerFault.Message : string.Empty) + ")";
            LogException("EntityGUID");
            return false;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("EntityGUID");
            return false;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("EntityGUID");
            return false;
        }
    }

    public string BusinessClosureCalendarId
    {
        get
        {
            return this.EntityGUID("name", "Business Closure Calendar");
        }
    }

    public string FetchBusinessClosureCalendar()
    {
        return this.FetchBusinessClosureCalendar(this.BusinessClosureCalendarId);
    }

    public string FetchBusinessClosureCalendar(string id)
    {
        try
        {
            StringBuilder results = new StringBuilder(string.Empty);
            IOrganizationService service = ConnectToService();
            QueryExpression q = new QueryExpression("calendar");

            q.ColumnSet = new ColumnSet(true);
            q.Criteria = new FilterExpression();
            q.Criteria.AddCondition(new ConditionExpression("calendarid", ConditionOperator.Equal, id));

            Entity businessClosureCalendar = service.RetrieveMultiple(q).Entities[0];

            if (businessClosureCalendar != null)
            {
                foreach (Entity ent in businessClosureCalendar.GetAttributeValue<EntityCollection>("calendarrules").Entities)
                {
                    this.Retrieve(ent);
                    results.AppendFormat("{0} ", this.Value("effectiveintervalstart"));
                }
            }

            return results.ToString();
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message + " (" + ((ex.Detail.InnerFault != null) ? ex.Detail.InnerFault.Message : string.Empty) + ")";
            LogException("EntityGUID");
            return string.Empty;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("EntityGUID");
            return string.Empty;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("EntityGUID");
            return string.Empty;
        }
    }

    public DateTime NextAvailableDate(DateTime date)
    {
        return NextAvailableDate(date, false);
    }

    public DateTime NextAvailableDate(DateTime date, bool excludeweekends)
    {
        if (!excludeweekends)
        {
            if (date.DayOfWeek == DayOfWeek.Saturday)
                date = date.AddDays(2);
            if (date.DayOfWeek == DayOfWeek.Sunday)
                date = date.AddDays(1);
        }

        // Ensure date is not in the business closure calendar
        string bcc = this.FetchBusinessClosureCalendar();
        while (bcc.Contains(date.ToString("dd/MM/yyyy")))
        {
            date = date.AddDays(1);
        }

        return date;
    }

    public string RetrieveAbsoluteAndSiteCollectionUrl(Guid entityid)
    {
        try
        {
            IOrganizationService service = ConnectToService();
            RetrieveAbsoluteAndSiteCollectionUrlRequest req = new RetrieveAbsoluteAndSiteCollectionUrlRequest
            {
                Target = new EntityReference("sharepointdocumentlocation", entityid)
            };

            RetrieveAbsoluteAndSiteCollectionUrlResponse resp = (RetrieveAbsoluteAndSiteCollectionUrlResponse)service.Execute(req);

            return resp.AbsoluteUrl;
        }
        catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
        {
            Message = "(FaultException) " + ex.Detail.ErrorCode + " " + ex.Detail.Message;
            LogException("AddListMember");
            return string.Empty;
        }
        catch (System.TimeoutException ex)
        {
            Message = "(TimeoutException) " + ex.Message;
            LogException("AddListMember");
            return string.Empty;
        }
        catch (System.Exception ex)
        {
            Message = FormatExceptionMessage(ex);
            LogException("AddListMember");
            return string.Empty;
        }
    }

    // Public implementation of Dispose pattern callable by consumers.
    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    // Protected implementation of Dispose pattern.
    protected virtual void Dispose(bool disposing)
    {
        if (disposed)
            return;

        if (disposing)
        {
            // handle.Dispose();
            // Free any other managed objects here.
            //
        }

        // Free any unmanaged objects here.
        //
        disposed = true;
    }
}

// Converts an XML config string (most likely stored in the secure parameter)
// into a NameValueCollection object. Sample config file (really simple):
//<?xml version="1.0" encoding="utf-8" ?>
//<Config>
//  <value1>XXXX</value1>
//  <value2>XXXX</value2>
//  <value3>XXXX</value3>
//</Config>
// You can then access a setting as: NameValueCollection config = ConfigHelper.Retrieve(); string value1 = config["value1"];
public class ConfigHelper
{
    public static NameValueCollection Retrieve(string config)
    {
        NameValueCollection nvc = new NameValueCollection();

        if (config != string.Empty && config != null)
        {
            System.IO.StringReader sr = new System.IO.StringReader(config);
            DataSet ds = new DataSet("Config");
            ds.ReadXml(sr);
            foreach (DataColumn dc in ds.Tables[0].Columns)
                nvc.Add(dc.ColumnName, Convert.ToString(ds.Tables[0].Rows[0][dc.ColumnName]));
        }

        return nvc;
    }
}