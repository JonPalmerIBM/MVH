﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace MVH_Optitime_PlugInAssembly
{
    /*
     * Message = Update
     * Primary Entity = mvh_repairmodule 
     * Filtering Attributes = mvh_stage
     * Execution Order = 99
     * Unsecure = value of stage to trigger writing to Opti
     * Secure = path to write to
    */
    
    public class Handler_Repair : IPlugin
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;
        private XRMHelper primaryentity;
        private NameValueCollection config;

        private string unsecure = string.Empty;
        private string secure = string.Empty;

        public Handler_Repair()
        {
        }

        public Handler_Repair(string unsec)
        {
            unsecure = unsec;
        }

        public Handler_Repair(string unsec, string sec)
        {
            unsecure = unsec;
            secure = sec;
        }

        public void Execute(IServiceProvider serviceprovider)
        {
            context = (IPluginExecutionContext)serviceprovider.GetService(typeof(IPluginExecutionContext));
            service = ((IOrganizationServiceFactory)serviceprovider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(context.UserId);
            primaryentity = new XRMHelper(service, context.PrimaryEntityName);

            if (context.Depth >= 1)
            {
                int records = 1;
                string batch = NextBatchNumber();
                string trans = NextTransactionNumber();
                string transfile = GenerateUniqueTemporaryFilename(batch);

                try
                {
                    primaryentity.Retrieve(context.PrimaryEntityId.ToString(),
                        "mvh_name,mvh_locationcode,mvh_priority,mvh_description,mvh_originaltargetdate," +
                        "mvh_priority,mvh_operativecomments,mvh_tenancybasicid,mvh_currenttargetdate,mvh_cancellationreason," +
                        "mvh_accountid,ownerid,mvh_propertyid,mvh_stage,mvh_specialinstructions");

                    //switch (context.MessageName.ToLower())
                    //{
                    //    case "create":
                    //        // ORDER-CREATE
                    //        sw.WriteLine(TransFileRepairHeader("ORDER-CREATE", trans));
                    //        includesors = true;
                    //        break;
                    //    case "update":
                    //        // No longer needed to let Optitime know about repair updates
                    //        if (primaryentity["mvh_cancellationreason"] == null)
                    //        {
                    //            // ORDER-AMEND
                    //            sw.WriteLine(TransFileRepairHeader("ORDER-AMEND", trans));
                    //            includesors = true;
                    //        }
                    //        else
                    //        {
                    //            // ORDER-DELETE
                    //            sw.WriteLine(TransFileRepairHeader("ORDER-DELETE", trans));
                    //        }
                    //        break;
                    //}

                    // ORDER-CREATE only when stage = 3
                    if (context.MessageName.ToLower() == "update" && primaryentity.Value("mvh_stage") == unsecure)
                    {
                        try
                        {
                            // Open transaction file
                            StreamWriter sw = System.IO.File.AppendText(transfile);
                            sw.WriteLine(TransFileHeader(batch));

                            sw.WriteLine(TransFileRepairHeader("ORDER-CREATE", trans));

                            // Scheduled items
                            int sequence = 1;
                            int transaction = 1;
                            StringBuilder fetchXML = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");
                            fetchXML.Append("<entity name=\"mvh_repairworksorderline\">");
                            fetchXML.Append("<attribute name=\"mvh_qty\" />");
                            fetchXML.Append("<attribute name=\"mvh_sor\" />");
                            fetchXML.Append("<filter type=\"and\">");
                            fetchXML.AppendFormat("<condition attribute=\"mvh_repair\" operator=\"eq\" uitype=\"mvh_repairmodule\" value=\"{0}\" />", context.PrimaryEntityId.ToString());
                            fetchXML.Append("</filter>");
                            fetchXML.Append("</entity>");
                            fetchXML.Append("</fetch>");

                            if (primaryentity.FetchEntityCollection(fetchXML.ToString()))
                            {
                                foreach (Entity ent in primaryentity.Results.Entities)
                                {
                                    sw.WriteLine(TransFileScheduledItem(ent, primaryentity.Value("mvh_name"), sequence, transaction));
                                    sequence++;
                                    transaction++;
                                    records++;
                                }
                            }

                            // Close transaction file
                            sw.WriteLine(TransFileTrailer(batch, records));
                            sw.Close();
                        }
                        catch (Exception ex)
                        {
                            throw new InvalidPluginExecutionException(ex.Message);
                        }

                        // Archive copy
                        try
                        {
                            File.Copy(transfile, string.Format("C:\\IBM\\Opti\\From_D365\\{0}.DAT", primaryentity.Value("mvh_name")), true);
                        }
                        catch
                        {

                        }

                        // Rename temporary file to .DAT
                        try
                        {
                            File.Move(transfile, transfile.Replace(".TMP", ".DAT"));
                        }
                        catch
                        {

                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new InvalidPluginExecutionException(ex.Message);
                }
            }
        }

        private string GenerateUniqueTemporaryFilename()
        {
            string filename;

            do
            {
                filename = string.Format("{0}{1}_FROM_D365.DAT", secure, NextBatchNumber());
            } while (File.Exists(filename));

            return filename.Replace(".DAT", ".TMP");
        }

        private string GenerateUniqueTemporaryFilename(string batch)
        {
            try
            {
                string filename;

                do
                {
                    filename = string.Format("{0}{1}_FROM_D365.DAT", secure, batch);
                } while (File.Exists(filename));

                return filename.Replace(".DAT", ".TMP");
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private string NextBatchNumber()
        {
            // Random number between 1 & 999,999
            Random r = new Random();

            return r.Next(1, 999999).ToString("000000");
        }

        private string NextTransactionNumber()
        {
            // Random number between 1 & 99,999
            Random r = new Random(DateTime.Now.Millisecond);

            return r.Next(1, 99999).ToString("00000");
        }

        private string TransFileHeader(string batch)
        {
            return string.Format("'HEADER','{0}','{1}','{2}',''",
                batch,
                DateTime.Now.ToShortDateString(),
                DateTime.Now.ToShortTimeString());
        }

        private string TransFileTrailer(string batch, int rows)
        {
            rows += 2;

            return string.Format("'TRAILER','{0}','{1}'",
                batch,
                rows.ToString());
        }

        private string TransFileRepairHeader(string type, string trans)
        {
            string warning = string.Empty;
            XRMHelper account = new XRMHelper(service, "account");
            XRMHelper contact = new XRMHelper(service, "contact");
            XRMHelper property = new XRMHelper(service, "mvh_properties");
            XRMHelper mvh_tenancybasic = new XRMHelper(service, "mvh_tenancybasic");

            account.Retrieve(primaryentity.Value("mvh_accountid"), "accountnumber");
            property.Retrieve(primaryentity.Value("mvh_propertyid"), "mvh_propertyreference,mvh_address1");

            //if (property.Value("mvh_address1").Contains("*"))
            //    warning = "** warning is in place for this property **";

            StringBuilder xml = new StringBuilder("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">");
            string name = string.Empty;
            string tel = string.Empty;

            xml.Append("<entity name=\"mvh_tenancybasic\">");
            xml.Append("<attribute name=\"mvh_personlookup\" />");
            xml.Append("<filter type=\"and\">");
            xml.AppendFormat("<condition attribute=\"mvh_address\" operator=\"eq\" uitype=\"mvh_properties\" value=\"{0}\" />", "{" + primaryentity.Value("mvh_propertyid") + "}");
            xml.Append("<condition attribute=\"mvh_tenancystatus\" operator=\"eq\" value=\"1\" />");
            xml.Append("</filter>");
            xml.Append("</entity>");
            xml.Append("</fetch>");

            if (mvh_tenancybasic.FetchEntityCollection(xml.ToString()))
            {
                if (mvh_tenancybasic.Results.Entities.Count > 0)
                {
                    mvh_tenancybasic.Retrieve(mvh_tenancybasic.Results.Entities[0]);
                    contact.Retrieve(mvh_tenancybasic.Value("mvh_personlookup"), "mvh_title,fullname,mobilephone,fax");
                    name = (contact.FormattedValue("mvh_title") == string.Empty ? string.Empty : contact.FormattedValue("mvh_title") + " ") + contact.Value("fullname");
                    tel = contact.Value("fax");
                }
            }

            // Map the priority from CRM to Opti
            string priority = "1";
            switch (primaryentity.Value("mvh_priority"))
            {
                case "23":
                    priority = "0";
                    break;
                case "24":
                    priority = "1";
                    break;
                case "27":
                    priority = "2";
                    break;
                case "19":
                    priority = "3";
                    break;
                case "18":
                    priority = "4";
                    break;
                case "20":
                    priority = "5";
                    break;
                case "21":
                    priority = "6";
                    break;
                case "22":
                    priority = "7";
                    break;
                case "25":
                    priority = "8";
                    break;
                case "26":
                    priority = "9";
                    break;
            }

            return string.Format("'{10}','0000','{0}','{1}','{2}','{3}','{4}','','{5}','{6}','{7}','','{8}','{9}','','{11}','{12}','','{13}','{14}'",
                primaryentity.Value("mvh_name"),
                property.Value("mvh_propertyreference"),
                priority,
                DateTime.Now.ToString("dd-MMM-yyyy HH:mm").ToUpper(),
                primaryentity["mvh_currenttargetdate"] == null ? string.Empty : primaryentity.Date("mvh_currenttargetdate").ToString("dd-MMM-yyyy HH:mm").ToUpper(),
                primaryentity.Value("mvh_description").Substring(0, primaryentity.Value("mvh_description").Length > 250 ? 250 : primaryentity.Value("mvh_description").Length),
                primaryentity.FormattedValue("ownerid"),
                primaryentity["mvh_originaltargetdate"] == null ? string.Empty : primaryentity.Date("mvh_originaltargetdate").ToString("dd-MMM-yyyy HH:mm").ToUpper(),
                trans,
                account.Value("accountnumber"),
                type,
                name,
                tel,
                primaryentity.Value("mvh_specialinstructions"),
                warning);

                //Transaction Type = type
                //Workflow Type = '0000'
                //Primary Order Number = primaryentity.Value("mvh_name")
                //Location Identifier = property.Value("mvh_propertyreference")
                //Priority = primaryentity.Value("mvh_priority")
                //Planning window start date and time = DateTime.Now.ToString("dd-MMM-yyyy HH:mm").ToUpper()
                //Planning window end date and time = primaryentity["mvh_currenttargetdate"]
                //***Estimated duration
                //Order Comments = primaryentity.Value("mvh_description")
                //User Id = primaryentity.FormattedValue("ownerid")
                //Target Date = primaryentity["mvh_originaltargetdate"]
                //***Secondary Order Number
                //Transaction Serial Number = trans
                //Contract Identifier = account.Value("accountnumber")
                //***Subcontract Identifier / DSO
                //Tenant Name = name
                //Tenant Phone No = tel
                //***Reason Code
                //Additional text = primaryentity.Value("mvh_specialinstructions")
                //Message = warning
        }

        private string TransFileScheduledItem(Entity ent, string repairnumber, int sequence, int transaction)
        {
            XRMHelper wol = new XRMHelper(service);

            wol.Retrieve(ent);

            return string.Format("'SCHEDULED-ITEMS','0000','{0}','','','{1}','{2}','','{3}','{4}'",
                repairnumber,
                wol.FormattedValue("mvh_sor"),
                wol.Value("mvh_qty"),
                sequence.ToString(),
                transaction);
        }
    }
}
